import React from "react";

import { Button, List, Text } from "components";

const SingleProductSpecificationsColumnTwo = (props) => {
  return (
    <>
      <div className={props.className}>
        <div className="bg-gray-100 flex flex-col items-start justify-center max-w-[1238px] p-5 rounded-[20px] w-full">
          <div className="flex flex-row items-start justify-start w-auto">
            <div className="flex flex-col items-start justify-start px-5 py-3 w-auto">
              <Text
                className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-auto"
                size="txtRobotoRomanBold24"
              >
                {props?.description}
              </Text>
            </div>
            <Button
              className="!text-gray-800_01 cursor-pointer font-bold font-roboto leading-[normal] min-w-[182px] rounded-tl-[20px] rounded-tr-[20px] text-2xl md:text-[22px] text-center sm:text-xl"
              color="white_A700"
              size="sm"
              variant="fill"
            >
              {props?.specification}
            </Button>
          </div>
          <div className="bg-white-A700 flex flex-col gap-10 items-start justify-start p-10 sm:px-5 rounded-bl-[20px] rounded-br-[20px] rounded-tr-[20px] w-full">
            <List
              className="flex flex-col gap-[38px] w-[91%]"
              orientation="vertical"
            >
              <div className="flex flex-col gap-3 items-start justify-start w-auto md:w-full">
                <Text
                  className="text-gray-800_01 text-xl w-auto"
                  size="txtRobotoRomanBold20"
                >
                  {props?.keyattributes}
                </Text>
                <div className="flex flex-col items-start justify-start w-auto md:w-full">
                  <div className="flex sm:flex-col flex-row sm:gap-5 items-start justify-start max-w-[994px] w-full">
                    <Text
                      className="bg-gray-100 justify-center pl-5 sm:pr-5 pr-[35px] py-[3px] text-gray-800_01 text-xl w-auto"
                      size="txtCardoBold20Gray80001"
                    >
                      {props?.size}
                    </Text>
                    <Text
                      className="bg-white-A700 justify-center pl-2.5 sm:pr-5 pr-[35px] py-[3px] text-gray-800_01 text-xl w-auto"
                      size="txtCardoBold20Gray80001"
                    >
                      {props?.size1}
                    </Text>
                  </div>
                  <div className="flex sm:flex-col flex-row sm:gap-5 items-start justify-start max-w-[994px] w-full">
                    <Text
                      className="bg-gray-100 justify-center pl-5 sm:pr-5 pr-[35px] py-[3px] text-gray-800_01 text-xl w-auto"
                      size="txtCardoBold20Gray80001"
                    >
                      {props?.feature}
                    </Text>
                    <Text
                      className="bg-white-A700 justify-center pl-2.5 sm:pr-5 pr-[35px] pt-[5px] text-gray-800_01 text-xl w-auto"
                      size="txtCardoBold20Gray80001"
                    >
                      {props?.feature1}
                    </Text>
                  </div>
                </div>
              </div>
              <div className="flex flex-col gap-3 items-start justify-start w-auto md:w-full">
                <Text
                  className="text-gray-800_01 text-xl w-auto"
                  size="txtRobotoRomanBold20"
                >
                  {props?.otherattributes}
                </Text>
                <div className="flex flex-col items-start justify-start w-auto md:w-full">
                  <div className="flex sm:flex-col flex-row sm:gap-5 items-start justify-start max-w-[994px] w-full">
                    <Text
                      className="bg-gray-100 justify-center pl-5 sm:pr-5 pr-[35px] py-[3px] text-gray-800_01 text-xl w-auto"
                      size="txtCardoBold20Gray80001"
                    >
                      {props?.size2}
                    </Text>
                    <Text
                      className="bg-white-A700 justify-center pl-2.5 sm:pr-5 pr-[35px] py-[3px] text-gray-800_01 text-xl w-auto"
                      size="txtCardoBold20Gray80001"
                    >
                      {props?.size3}
                    </Text>
                  </div>
                  <div className="flex sm:flex-col flex-row sm:gap-5 items-start justify-start max-w-[994px] w-full">
                    <Text
                      className="bg-gray-100 justify-center pl-5 sm:pr-5 pr-[35px] py-[3px] text-gray-800_01 text-xl w-auto"
                      size="txtCardoBold20Gray80001"
                    >
                      {props?.feature2}
                    </Text>
                    <Text
                      className="bg-white-A700 justify-center pl-2.5 sm:pr-5 pr-[35px] pt-[5px] text-gray-800_01 text-xl w-auto"
                      size="txtCardoBold20Gray80001"
                    >
                      {props?.feature3}
                    </Text>
                  </div>
                </div>
              </div>
            </List>
            <Text
              className="text-gray-800_01 text-xl w-auto"
              size="txtCardoBold20Gray80001"
            >
              {props?.keyattributes1}
            </Text>
            <Text
              className="max-w-[1014px] md:max-w-full text-gray-800_01 text-xl"
              size="txtCardoRegular20Gray80001"
            >
              {props?.description1}
            </Text>
          </div>
        </div>
      </div>
    </>
  );
};

SingleProductSpecificationsColumnTwo.defaultProps = {
  description: "Description",
  specification: "Specification",
  keyattributes: "Key Attributes",
  size: "Size",
  size1: "1.2m*3.2m*1.2m",
  feature: "Feature",
  feature1: "Modern, Revolving",
  otherattributes: "Other Attributes",
  size2: "Size",
  size3: "1.2m*3.2m*1.2m",
  feature2: "Feature",
  feature3: "Modern, Revolving",
  keyattributes1: "Key Attributes",
  description1:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
};

export default SingleProductSpecificationsColumnTwo;
