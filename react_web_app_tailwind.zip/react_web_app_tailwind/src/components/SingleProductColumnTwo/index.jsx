import React from "react";

import { Button, Text } from "components";

const SingleProductColumnTwo = (props) => {
  return (
    <>
      <div className={props.className}>
        <div className="bg-gray-100 flex flex-col items-start justify-center max-w-[1238px] p-5 rounded-[20px] w-full">
          <div className="flex flex-row items-start justify-start w-auto">
            <Button
              className="!text-gray-800_01 cursor-pointer font-bold font-roboto leading-[normal] min-w-[164px] rounded-tl-[20px] rounded-tr-[20px] text-2xl md:text-[22px] text-center sm:text-xl"
              color="white_A700"
              size="sm"
              variant="fill"
            >
              {props?.dynamicbutton}
            </Button>
            <div className="flex flex-col items-start justify-start px-5 py-3 w-auto">
              <Text
                className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-auto"
                size="txtRobotoRomanBold24"
              >
                {props?.dynamictext}
              </Text>
            </div>
          </div>
          <div className="bg-white-A700 flex flex-col gap-10 items-start justify-start p-10 sm:px-5 rounded-bl-[20px] rounded-br-[20px] rounded-tr-[20px] w-full">
            <Text
              className="max-w-[1014px] md:max-w-full text-gray-800_01 text-xl"
              size="txtCardoRegular20Gray80001"
            >
              {props?.dynamictext1}
            </Text>
            <Text
              className="max-w-[1014px] md:max-w-full text-gray-800_01 text-xl"
              size="txtCardoRegular20Gray80001"
            >
              {props?.dynamictext2}
            </Text>
            <Text
              className="max-w-[1014px] md:max-w-full text-gray-800_01 text-xl"
              size="txtCardoRegular20Gray80001"
            >
              {props?.dynamictext3}
            </Text>
            <Text
              className="max-w-[1014px] md:max-w-full text-gray-800_01 text-xl"
              size="txtCardoRegular20Gray80001"
            >
              {props?.dynamictext4}
            </Text>
          </div>
        </div>
      </div>
    </>
  );
};

SingleProductColumnTwo.defaultProps = {
  dynamicbutton: "Description",
  dynamictext: "Specification",
  dynamictext1:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
  dynamictext2:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
  dynamictext3:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
  dynamictext4:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
};

export default SingleProductColumnTwo;
