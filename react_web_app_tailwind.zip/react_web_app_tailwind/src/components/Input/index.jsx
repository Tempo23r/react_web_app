import React from "react";
import PropTypes from "prop-types";
import { ErrorMessage } from "../../components/ErrorMessage";

const variants = {
  fill: {
    white_A700: "bg-white-A700",
    white_A700_23: "bg-white-A700_23",
    blue_gray_900_23: "bg-blue_gray-900_23",
    light_blue_400_1e: "bg-light_blue-400_1e",
    gray_50_03: "bg-gray-50_03",
  },
  outline: { light_blue_700: "border-2 border-light_blue-700 border-solid" },
  underline: { black_900: "border-b border-black-900" },
};
const shapes = { round: "rounded", square: "rounded-none" };
const sizes = {
  xs: "pb-1.5 pr-px pt-px",
  md: "pb-[9px]",
  lg: "pb-[7px] pt-2.5 px-[7px]",
  xl: "pb-2.5 pt-[11px] px-2.5",
};

const Input = React.forwardRef(
  (
    {
      wrapClassName = "",
      className = "",
      name = "",
      placeholder = "",
      type = "text",
      children,
      errors = [],
      label = "",
      prefix,
      suffix,
      onChange,
      shape = "",
      size = "",
      variant = "",
      color = "",
      ...restProps
    },
    ref,
  ) => {
    const handleChange = (e) => {
      if (onChange) onChange(e?.target?.value);
    };

    return (
      <>
        <div
          className={`${wrapClassName} 
              ${shapes[shape] || ""} 
              ${variants[variant]?.[color] || ""} 
              ${sizes[size] || ""}`}
        >
          {!!label && label}
          {!!prefix && prefix}
          <input
            ref={ref}
            className={`${className} bg-transparent border-0`}
            type={type}
            name={name}
            onChange={handleChange}
            placeholder={placeholder}
            {...restProps}
          />
          {!!suffix && suffix}
        </div>
        {!!errors && <ErrorMessage errors={errors} />}
      </>
    );
  },
);

Input.propTypes = {
  wrapClassName: PropTypes.string,
  className: PropTypes.string,
  name: PropTypes.string,
  placeholder: PropTypes.string,
  type: PropTypes.string,
  shape: PropTypes.oneOf(["round", "square"]),
  size: PropTypes.oneOf(["xs", "md", "lg", "xl"]),
  variant: PropTypes.oneOf(["fill", "outline", "underline"]),
  color: PropTypes.oneOf([
    "white_A700",
    "white_A700_23",
    "blue_gray_900_23",
    "light_blue_400_1e",
    "gray_50_03",
    "light_blue_700",
    "black_900",
  ]),
};

export { Input };
