import React from "react";

import { Button, Img, Input, Text } from "components";

const Footer2 = (props) => {
  return (
    <>
      <footer className={props.className}>
        <ul className="flex flex-col gap-[19px] items-center justify-center w-full common-column-list">
          <li>
            <div className="flex md:flex-col flex-row md:gap-10 items-start justify-between md:w-full">
              <div className="flex flex-col gap-[39px] h-60 md:h-auto items-start justify-start w-auto sm:w-full">
                <div className="flex flex-col gap-3 items-start justify-center w-[545px] sm:w-full">
                  <Text
                    className="sm:text-4xl md:text-[38px] text-[40px] text-gray-800"
                    size="txtCardoBold40Gray800"
                  >
                    <>
                      Let’s Get 50% Discount For <br />
                      All Products
                    </>
                  </Text>
                  <Text
                    className="max-w-[505px] md:max-w-full text-base text-gray-800_02"
                    size="txtRalewayRomanMedium16Gray80002"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua.
                  </Text>
                </div>
                <div className="flex sm:flex-col flex-row gap-1 items-center justify-center w-full">
                  <Input
                    name="frame205"
                    placeholder="Email"
                    className="!placeholder:text-gray-800_c1 !text-gray-800_c1 font-bold font-raleway leading-[normal] p-0 text-left text-sm w-full"
                    wrapClassName="border border-gray-800_87 border-solid flex-1 sm:flex-1 rounded-[12px] w-[83%] sm:w-full"
                    color="white_A700"
                    size="xl"
                    variant="fill"
                  ></Input>
                  <Button
                    className="cursor-pointer font-bold font-raleway leading-[normal] rounded-[12px] text-base text-center w-[90px]"
                    color="gray_800"
                    size="md"
                    variant="fill"
                  >
                    Send
                  </Button>
                </div>
              </div>
              <div className="flex sm:flex-col flex-row gap-3 items-start justify-between w-[594px] sm:w-full">
                <div className="flex flex-col gap-3 items-start justify-start w-auto">
                  <Text
                    className="text-2xl md:text-[22px] text-center text-gray-800 sm:text-xl w-auto"
                    size="txtRalewayRomanBold24Gray800"
                  >
                    Quick Links
                  </Text>
                  <ul className="flex flex-col gap-[11px] items-start justify-start md:w-full common-column-list">
                    <li>
                      <Text
                        className="text-base text-gray-500"
                        size="txtRalewayRomanSemiBold16"
                      >
                        Home
                      </Text>
                    </li>
                    <li>
                      <Text
                        className="text-base text-gray-500"
                        size="txtRalewayRomanSemiBold16"
                      >
                        About us
                      </Text>
                    </li>
                    <li>
                      <Text
                        className="text-base text-gray-500"
                        size="txtRalewayRomanSemiBold16"
                      >
                        Our Services
                      </Text>
                    </li>
                    <li>
                      <Text
                        className="text-base text-gray-500"
                        size="txtRalewayRomanSemiBold16"
                      >
                        Contact us
                      </Text>
                    </li>
                  </ul>
                </div>
                <div className="flex flex-col gap-3 items-start justify-start w-auto">
                  <Text
                    className="text-2xl md:text-[22px] text-center text-gray-800 sm:text-xl w-auto"
                    size="txtRalewayRomanBold24Gray800"
                  >
                    Sections
                  </Text>
                  <ul className="flex flex-col gap-[13px] items-start justify-start md:w-full common-column-list">
                    <li>
                      <Text
                        className="text-base text-gray-500"
                        size="txtRalewayRomanSemiBold16"
                      >
                        Products
                      </Text>
                    </li>
                    <li>
                      <Text
                        className="text-base text-gray-500"
                        size="txtRalewayRomanSemiBold16"
                      >
                        Categories
                      </Text>
                    </li>
                    <li>
                      <Text
                        className="text-base text-gray-500"
                        size="txtRalewayRomanSemiBold16"
                      >
                        Repairing
                      </Text>
                    </li>
                    <li>
                      <Text
                        className="text-base text-gray-500"
                        size="txtRalewayRomanSemiBold16"
                      >
                        Delivery
                      </Text>
                    </li>
                  </ul>
                </div>
                <div className="flex flex-col gap-3 items-start justify-start w-auto">
                  <Text
                    className="text-2xl md:text-[22px] text-center text-gray-800 sm:text-xl w-auto"
                    size="txtRalewayRomanBold24Gray800"
                  >
                    Customer Service
                  </Text>
                  <Text
                    className="text-base text-gray-500 w-auto"
                    size="txtRalewayRomanSemiBold16"
                  >
                    contact@moa.com
                  </Text>
                  <Text
                    className="text-base text-gray-500 w-auto"
                    size="txtRalewayRomanSemiBold16"
                  >
                    011 701 2343
                  </Text>
                  <Text
                    className="text-base text-gray-500 w-auto"
                    size="txtRalewayRomanSemiBold16"
                  >
                    +94 77 143 2007 - Hotline
                  </Text>
                  <Text
                    className="text-base text-gray-500 w-auto"
                    size="txtRalewayRomanSemiBold16"
                  >
                    +94 77 298 5099 - Hotline
                  </Text>
                  <Text
                    className="text-base text-gray-500"
                    size="txtRalewayRomanSemiBold16"
                  >
                    <>
                      No. 501A,
                      <br />
                      Level #1, Thimbirigasyaya Road, Colombo 05,
                      <br />
                      Sri Lanka.
                    </>
                  </Text>
                </div>
              </div>
            </div>
          </li>
          <li>
            <div className="flex sm:flex-col flex-row gap-5 items-start justify-start md:ml-[0] ml-[839px] sm:w-full">
              <Text
                className="text-base text-gray-800 w-auto"
                size="txtRalewayRomanSemiBold16Gray800"
              >
                Your Privacy Choices
              </Text>
              <Text
                className="text-base text-gray-800 w-auto"
                size="txtRalewayRomanSemiBold16Gray800"
              >
                Privacy Policy
              </Text>
              <Text
                className="text-base text-gray-800 w-auto"
                size="txtRalewayRomanSemiBold16Gray800"
              >
                Terms of Use
              </Text>
            </div>
          </li>
          <li>
            <div className="border-gray-800 border-solid border-t flex md:flex-col flex-row md:gap-10 items-end justify-between pt-5 md:w-full">
              <div className="flex md:flex-col flex-row gap-3 items-start justify-start max-w-[812px] w-full">
                <Img
                  className="sm:flex-1 h-[35px] md:h-auto object-cover w-[88px] sm:w-full"
                  src="images/img_rectangle59.png"
                  alt="rectangleSixtyFour"
                />
                <div className="flex sm:flex-1 flex-col gap-3 items-start justify-start w-[554px] sm:w-full">
                  <Text
                    className="sm:text-4xl md:text-[38px] text-[40px] text-gray-800"
                    size="txtRalewayRomanBold40"
                  >
                    <span className="md:text-[22px] sm:text-xl text-gray-800 font-cardo text-left text-2xl font-bold">
                      <>
                        MODERN OFFICE AUTOMATION (PVT) LTD
                        <br />
                      </>
                    </span>
                    <span className="text-gray-800 font-cardo text-left text-base font-normal">
                      ( Member of Modern Group of Companies )
                    </span>
                  </Text>
                  <Text
                    className="text-base text-gray-800 w-auto"
                    size="txtCardoRegular16Gray800"
                  >
                    © 2022 Modern Office Automation. All Rights Reserved.
                  </Text>
                </div>
              </div>
              <div className="flex flex-col gap-1 items-start justify-start w-auto">
                <Text
                  className="text-base text-gray-800 w-auto"
                  size="txtRalewayRomanSemiBold16Gray800"
                >
                  Official Technology Partner
                </Text>
                <Img
                  className="h-[54px] md:h-auto object-cover w-[257px] sm:w-full"
                  src="images/img_rectangle64.png"
                  alt="rectangleSixtyFour_One"
                />
              </div>
            </div>
          </li>
        </ul>
      </footer>
    </>
  );
};

Footer2.defaultProps = {};

export default Footer2;
