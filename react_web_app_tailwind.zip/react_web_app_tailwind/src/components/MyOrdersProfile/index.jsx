import React from "react";

import { Button, Img, Input, Line, List, Text } from "components";

import { CloseSVG } from "../../assets/images";

const MyOrdersProfile = (props) => {
  const [frame456value, setFrame456value] = React.useState("");

  return (
    <>
      <div className={props.className}>
        <div className="flex flex-col gap-7 items-start justify-start w-auto sm:w-full">
          <Input
            name="frame456"
            placeholder="Profile"
            value={frame456value}
            onChange={(e) => setFrame456value(e)}
            className="!placeholder:text-gray-900_02 !text-gray-900_02 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <Img
                className="mt-[3px] mb-px cursor-pointer h-6 mr-3"
                src="images/img_search_gray_900_02.svg"
                alt="search"
              />
            }
            suffix={
              <CloseSVG
                fillColor="#1d1d1f"
                className="cursor-pointer h-6 my-auto"
                onClick={() => setFrame456value("")}
                style={{
                  visibility: frame456value?.length <= 0 ? "hidden" : "visible",
                }}
                height={24}
                width={24}
                viewBox="0 0 24 24"
              />
            }
            shape="square"
            color="white_A700"
            size="lg"
            variant="fill"
          ></Input>
          <Input
            name="frame457"
            placeholder="Company"
            className="!placeholder:text-gray-900_02 !text-gray-900_02 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <Img
                className="mt-px mb-1 h-6 mr-3"
                src="images/img_thumbsup_gray_900_02.svg"
                alt="thumbs_up"
              />
            }
            shape="square"
            color="white_A700"
            size="lg"
            variant="fill"
          ></Input>
          <Input
            name="frame458"
            placeholder="Orders"
            className="!placeholder:text-light_blue-700 !text-light_blue-700 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <div className="h-6 mt-[3px] mb-px mr-3 w-6 outline-light_blue-700 outline-[1px] outline">
                <Img
                  className="h-6 my-auto"
                  src="images/img_lock_light_blue_700.svg"
                  alt="lock"
                />
              </div>
            }
            shape="square"
            color="light_blue_400_1e"
            size="lg"
            variant="fill"
          ></Input>
        </div>
        <div className="bg-white-A700 flex flex-col gap-6 items-start justify-start max-w-[987px] p-6 sm:px-5 rounded-[12px] shadow-bs w-full">
          <div className="flex flex-col items-start justify-start w-full">
            <Text
              className="border-b border-black-900 border-solid pb-[5px] sm:pr-5 pr-[35px] text-2xl md:text-[22px] text-gray-800 sm:text-xl w-full"
              size="txtInterBold24Gray800"
            >
              {props?.textmyordersprops}
            </Text>
          </div>
          <div className="flex flex-col gap-3 items-start justify-start w-full">
            <div className="flex md:flex-col flex-row md:gap-[53px] items-end justify-between w-full">
              <div className="border-b border-light_blue-700 border-solid flex flex-col items-center justify-center pb-[7px] px-3 w-auto">
                <div className="flex flex-row gap-1.5 items-center justify-center w-auto">
                  <Button
                    className="cursor-pointer font-bold font-cardo leading-[normal] min-w-[37px] rounded-[18px] text-center text-xl"
                    color="light_blue_700"
                    size="xs"
                    variant="fill"
                  >
                    {props?.buttonlbl122props}
                  </Button>
                  <Text
                    className="text-black-900 text-center text-xl"
                    size="txtInterSemiBold20Black900"
                  >
                    {props?.textallprops}
                  </Text>
                </div>
              </div>
              <List
                className="md:flex-1 sm:flex-col flex-row md:gap-10 gap-[137px] grid sm:grid-cols-1 grid-cols-2 w-[44%] md:w-full"
                orientation="horizontal"
              >
                <div className="flex flex-col items-center justify-center pb-[7px] px-3 w-auto">
                  <div className="flex flex-row gap-1.5 items-center justify-center w-auto">
                    <Button
                      className="cursor-pointer font-bold font-cardo h-[39px] leading-[normal] rounded-[18px] text-center text-xl w-[37px]"
                      color="light_blue_700"
                      size="xs"
                      variant="fill"
                    >
                      {props?.buttonlbl2props}
                    </Button>
                    <Text
                      className="text-black-900 text-center text-xl w-auto"
                      size="txtInterSemiBold20Black900"
                    >
                      {props?.texttopayprops}
                    </Text>
                  </div>
                </div>
                <div className="flex flex-col items-center justify-center pb-[7px] px-3 w-auto">
                  <div className="flex flex-row gap-1.5 items-center justify-center w-auto">
                    <Button
                      className="cursor-pointer font-bold font-cardo h-[39px] leading-[normal] rounded-[18px] text-center text-xl w-[37px]"
                      color="light_blue_700"
                      size="xs"
                      variant="fill"
                    >
                      {props?.buttonlbl2props1}
                    </Button>
                    <Text
                      className="text-black-900 text-center text-xl w-auto"
                      size="txtInterSemiBold20Black900"
                    >
                      {props?.texttoshipprops}
                    </Text>
                  </div>
                </div>
              </List>
              <div className="flex flex-col items-center justify-center pb-[7px] px-3 w-auto">
                <div className="flex flex-row gap-1.5 items-center justify-center w-auto">
                  <Button
                    className="cursor-pointer font-bold font-cardo h-[39px] leading-[normal] rounded-[18px] text-center text-xl w-[37px]"
                    color="light_blue_700"
                    size="xs"
                    variant="fill"
                  >
                    {props?.buttonlbl2props2}
                  </Button>
                  <Text
                    className="text-black-900 text-center text-xl w-auto"
                    size="txtInterSemiBold20Black900"
                  >
                    {props?.texttodeliverprops}
                  </Text>
                </div>
              </div>
            </div>
            <div className="flex flex-col items-start justify-start w-auto md:w-full">
              <div className="border-b border-black-900_19 border-solid flex flex-col items-start justify-start max-w-[939px] py-4 w-full">
                <div className="flex md:flex-col flex-row gap-2.5 h-[225px] md:h-auto items-center justify-center px-2 py-3 w-full">
                  <Img
                    className="md:h-auto h-full max-h-[201px] object-cover sm:w-[] md:w-[]"
                    src="images/img_rectangle1244.png"
                    alt="rectangle1244"
                  />
                  <div className="flex flex-1 flex-col gap-[22px] h-full items-start justify-start w-full">
                    <div className="flex flex-col gap-[15px] items-start justify-start w-full">
                      <Text
                        className="text-center text-gray-800_04 text-xl w-auto"
                        size="txtRobotoRomanMedium20Gray80004"
                      >
                        {props?.textloremipsumdoloroneprops}
                      </Text>
                      <Text
                        className="text-black-900 text-center text-xl w-auto"
                        size="txtRobotoRomanBold20Black900"
                      >
                        {props?.textpriceprops}
                      </Text>
                    </div>
                    <div className="flex flex-col gap-0.5 items-start justify-start w-auto">
                      {props?.textorderid01235props}
                      <Text
                        className="text-base text-black-900 text-center w-auto"
                        size="txtRobotoRomanRegular16Black900"
                      >
                        {props?.textstatusshippedprops}
                      </Text>
                      {props?.textestimateddeliveryshippedprops}
                    </div>
                    <Text
                      className="text-base text-center text-light_blue-700 w-auto"
                      size="txtRobotoRomanBold16Lightblue700"
                    >
                      {props?.texttrackorderprops}
                    </Text>
                  </div>
                </div>
              </div>
              <div className="border-b border-black-900_19 border-solid flex flex-col items-start justify-start max-w-[939px] w-full">
                <div className="flex flex-col items-start justify-start px-2 py-4 w-full">
                  <div className="flex md:flex-col flex-row gap-2.5 h-full items-start justify-start w-full">
                    <Img
                      className="h-[201px] md:h-auto max-h-[201px] object-cover sm:w-[] md:w-[]"
                      src="images/img_rectangle1244.png"
                      alt="rectangle1244_One"
                    />
                    <div className="flex flex-1 flex-col gap-[22px] items-start justify-start w-full">
                      <div className="flex flex-col gap-[15px] items-start justify-start w-full">
                        <Text
                          className="text-center text-gray-800_04 text-xl w-auto"
                          size="txtRobotoRomanMedium20Gray80004"
                        >
                          {props?.textloremipsumdolorthreeprops}
                        </Text>
                        <Text
                          className="text-center text-gray-900 text-xl w-auto"
                          size="txtRobotoRomanBold20Gray900"
                        >
                          {props?.textpriceoneprops}
                        </Text>
                      </div>
                      <div className="flex flex-col gap-0.5 items-start justify-start w-auto">
                        {props?.textorderid01235oneprops}
                        {props?.textstatusdeliveredprops}
                        <Text
                          className="text-base text-center text-gray-800 w-auto"
                          size="txtRobotoRomanRegular16"
                        >
                          {props?.textexchangesreturnsprops}
                        </Text>
                      </div>
                      <div className="flex flex-row gap-3 items-center justify-start w-auto">
                        <Button
                          className="cursor-pointer font-bold font-roboto leading-[normal] outline-[1px] text-center text-xl w-[140px]"
                          shape="square"
                          color="light_blue_700"
                          size="xs"
                          variant="outline"
                        >
                          {props?.buttonlblreturnprops}
                        </Button>
                        <Button
                          className="cursor-pointer font-bold font-roboto leading-[normal] outline-[1px] text-center text-xl w-[140px]"
                          shape="square"
                          color="light_blue_700"
                          size="xs"
                          variant="outline"
                        >
                          {props?.buttonlblexchangeprops}
                        </Button>
                      </div>
                      <div className="flex sm:flex-col flex-row gap-3 items-center justify-start w-auto sm:w-full">
                        <div className="flex flex-row gap-3 items-center justify-start w-auto">
                          <Text
                            className="text-center text-gray-800 text-xl w-auto"
                            size="txtRobotoRomanBold20Gray800"
                          >
                            {props?.textratethisitemprops}
                          </Text>
                          <div className="flex flex-row gap-3 items-center justify-start w-auto">
                            <Img
                              className="h-6 w-6"
                              src="images/img_signal.svg"
                              alt="signal"
                            />
                            <Img
                              className="h-6 w-6"
                              src="images/img_signal.svg"
                              alt="signal_One"
                            />
                            <Img
                              className="h-6 w-6"
                              src="images/img_signal.svg"
                              alt="signal_Two"
                            />
                            <Img
                              className="h-6 w-6"
                              src="images/img_signal.svg"
                              alt="signal_Three"
                            />
                            <Img
                              className="h-6 w-6"
                              src="images/img_signal.svg"
                              alt="signal_Four"
                            />
                          </div>
                        </div>
                        <Line className="bg-black-900 h-px w-px" />
                        <Text
                          className="text-center text-light_blue-700 text-xl w-auto"
                          size="txtRobotoRomanBold20Lightblue700"
                        >
                          {props?.textwriteareviewprops}
                        </Text>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

MyOrdersProfile.defaultProps = {
  textmyordersprops: "My Orders",
  buttonlbl122props: "12",
  textallprops: "All",
  buttonlbl2props: "2",
  texttopayprops: "To Pay",
  buttonlbl2props1: "2",
  texttoshipprops: "To Ship",
  buttonlbl2props2: "2",
  texttodeliverprops: "To Deliver",
  textloremipsumdoloroneprops: "Lorem ipsum dolor sit amet",
  textpriceprops: "12,500.00 LKR",
  textorderid01235props: (
    <Text
      className="text-base text-black-900 text-center w-auto"
      size="txtRobotoRomanRegular16Black900"
    >
      <span className="text-gray-800 font-roboto font-normal">Order Id </span>
      <span className="text-black-900 font-roboto font-normal">- #</span>
      <span className="text-gray-900_02 font-roboto font-medium">01235</span>
    </Text>
  ),
  textstatusshippedprops: "Status - Shipped",
  textestimateddeliveryshippedprops: (
    <Text
      className="text-base text-black-900 text-center w-auto"
      size="txtRobotoRomanRegular16Black900"
    >
      <span className="text-gray-800 font-roboto uppercase font-normal">e</span>
      <span className="text-gray-800 font-roboto font-normal">stimated D</span>
      <span className="text-gray-800 font-roboto lowercase font-normal">
        ELIVERY
      </span>
      <span className="text-gray-800 font-roboto font-normal"> </span>
      <span className="text-black-900 font-roboto font-normal">- Shipped</span>
    </Text>
  ),
  texttrackorderprops: "TRACK ORDER",
  textloremipsumdolorthreeprops: "Lorem ipsum dolor sit amet",
  textpriceoneprops: "12,500.00 LKR",
  textorderid01235oneprops: (
    <Text
      className="text-base text-black-900 text-center w-auto"
      size="txtRobotoRomanRegular16Black900"
    >
      <span className="text-gray-800 font-roboto font-normal">Order Id </span>
      <span className="text-black-900 font-roboto font-normal">- #</span>
      <span className="text-gray-900_02 font-roboto font-medium">01235</span>
    </Text>
  ),
  textstatusdeliveredprops: (
    <Text
      className="text-base text-black-900 text-center w-auto"
      size="txtRobotoRomanRegular16Black900"
    >
      <span className="text-gray-800 font-roboto font-normal">Status </span>
      <span className="text-black-900 font-roboto font-normal">- </span>
      <span className="text-light_blue-700 font-roboto font-medium">
        Delivered
      </span>
      <span className="text-light_blue-700 font-roboto font-normal"> </span>
      <span className="text-gray-800 font-roboto font-normal">
        ( 25th Dec 2023 )
      </span>
    </Text>
  ),
  textexchangesreturnsprops: "Exchanges/Returns available till 30th December.",
  buttonlblreturnprops: "Return",
  buttonlblexchangeprops: "Exchange",
  textratethisitemprops: "Rate this Item :",
  textwriteareviewprops: "Write a Review",
};

export default MyOrdersProfile;
