import React from "react";

import { Img, Input, Text } from "components";
import { CloseSVG } from "../../assets/images";

const Frame = () => {
  
  const [frame115value, setFrame115value] = React.useState("");
  return (
    <div className="relative bg-gray-100 w-full flex flex-col items-start justify-start pt-0 px-0 pb-1 box-border text-left text-xl text-black font-raleway">
      <div className="w-[1440px] flex flex-row items-center justify-between pt-5 px-[100px] pb-2.5 box-border">
        <img
            className="sm:flex-1 h-[55px] md:h-auto object-cover w-[133px] sm:w-full"
            src="images/img_rectangle59.png"
            alt="rectangleFiftyNine"
        />
        <div className="flex flex-row items-center justify-center gap-[20px]">
          <div className="flex flex-row items-center justify-center">
            <div className="relative font-semibold">Home</div>
          </div>
          <div className="flex flex-row items-center justify-center">
            <div className="relative font-semibold">|</div>
          </div>
          <div className="flex flex-row items-center justify-center">
            <div className="relative font-semibold">About us</div>
          </div>
          <div className="flex flex-row items-center justify-center">
            <div className="relative font-semibold">|</div>
          </div>
          <div className="flex flex-row items-center justify-center">
            <div className="relative font-semibold">Our Services</div>
          </div>
          <div className="flex flex-row items-center justify-center">
            <div className="relative font-semibold">|</div>
          </div>
          <div className="flex flex-row items-center justify-center">
            <div className="relative font-semibold">Contact us</div>
          </div>
        </div>
        <div className="flex flex-row items-end justify-center gap-[12px]">
          <img
              className="h-6 w-6"
              src="images/img_user01_gray_900.svg"
              alt="userOne"
          />
          <div className="flex flex-row items-center justify-center">
            <div className="relative font-semibold">|</div>
          </div>
          <img
              className="h-6 w-6"
              src="images/img_thumbsup.svg"
              alt="thumbsup"
          />
        </div>
      </div>
      <div className="w-[1440px] flex flex-row items-center justify-between py-0.5 px-[100px] box-border">
        <div className="self-stretch flex flex-row items-center justify-start gap-[40px]">
          <div className="flex flex-row items-center justify-start">
            <div className="flex flex-row items-center justify-start py-2.5 px-0 gap-[20px]">
              <div className="relative font-semibold">Shop By Category</div>
              <img
                  className="h-1.5 w-3"
                  src="images/img_arrowdown_gray_900.svg"
                  alt="arrowdown"
              />
            </div>
          </div>
<>
<Input
              name="frame115"
              placeholder="Search..."
              value={frame115value}
              onChange={(e) => setFrame115value(e)}
              className="!placeholder:text-gray-900 !text-gray-900 font-raleway font-semibold leading-[normal] p-0 text-base text-left w-full"
              wrapClassName="flex w-[465px] md:w-full"
              suffix={
                frame115value?.length > 0 ? (
                  <CloseSVG
                    className="cursor-pointer h-[18px] ml-[35px] my-px"
                    onClick={() => setFrame115value("")}
                    fillColor="#1d1d1e"
                    height={18}
                    width={18}
                    viewBox="0 0 18 18"
                  />
                ) : (
                  <Img
                    className="cursor-pointer h-[18px] ml-[35px] my-px"
                    src="images/img_search_gray_900.svg"
                    alt="search"
                  />
                )
              }
              shape="square"
              color="blue_gray_900_23"
              size="xl"
              variant="fill"
            ></Input>
</>
        </div>
        <div className="flex flex-row items-center justify-start gap-[12px]">
          <div className="flex flex-row items-center justify-center">
            <div className="relative font-semibold">New Arrivals</div>
          </div>
          <div className="flex flex-row items-center justify-center">
            <div className="relative font-semibold">|</div>
          </div>
          <div className="flex flex-row items-center justify-center">
            <div className="relative font-semibold">Offers</div>
          </div>
        </div>
        <div className="hidden" />
      </div>
    </div>
  );
};

export default Frame;
