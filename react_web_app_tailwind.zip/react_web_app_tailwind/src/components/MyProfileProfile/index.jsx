import React from "react";

import { Button, Img, Input, Line, Text } from "components";

import { CloseSVG } from "../../assets/images";

const MyProfileProfile = (props) => {
  const [frame456value, setFrame456value] = React.useState("");

  return (
    <>
      <div className={props.className}>
        <div className="flex flex-col gap-7 items-start justify-start w-auto sm:w-full">
          <Input
            name="frame456"
            placeholder="Profile"
            value={frame456value}
            onChange={(e) => setFrame456value(e)}
            className="!placeholder:text-light_blue-700 !text-light_blue-700 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <Img
                className="mt-[3px] mb-px cursor-pointer h-6 mr-3"
                src="images/img_search_light_blue_700.svg"
                alt="search"
              />
            }
            suffix={
              <CloseSVG
                fillColor="#1690be"
                className="cursor-pointer h-6 my-auto"
                onClick={() => setFrame456value("")}
                style={{
                  visibility: frame456value?.length <= 0 ? "hidden" : "visible",
                }}
                height={24}
                width={24}
                viewBox="0 0 24 24"
              />
            }
            shape="square"
            color="light_blue_400_1e"
            size="lg"
            variant="fill"
          ></Input>
          <Input
            name="frame457"
            placeholder="Company"
            className="!placeholder:text-gray-900_02 !text-gray-900_02 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <Img
                className="mt-px mb-1 h-6 mr-3"
                src="images/img_thumbsup_gray_900_02.svg"
                alt="thumbs_up"
              />
            }
            shape="square"
            color="white_A700"
            size="lg"
            variant="fill"
          ></Input>
          <Input
            name="frame458"
            placeholder="Orders"
            className="!placeholder:text-gray-900_02 !text-gray-900_02 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <div className="h-6 mt-[3px] mb-px mr-3 w-6 outline-gray-900_02 outline-[1px] outline">
                <Img
                  className="h-6 my-auto"
                  src="images/img_bag.svg"
                  alt="bag"
                />
              </div>
            }
            shape="square"
            color="white_A700"
            size="lg"
            variant="fill"
          ></Input>
        </div>
        <div className="bg-white-A700 flex flex-col gap-6 items-start justify-start max-w-[987px] p-6 sm:px-5 rounded-[12px] shadow-bs w-full">
          <div className="flex flex-col gap-[30px] items-start justify-start w-full">
            <Text
              className="text-2xl md:text-[22px] text-gray-800 sm:text-xl w-auto"
              size="txtInterBold24Gray800"
            >
              {props?.myprofiletextprops}
            </Text>
            <div className="md:h-[33px] h-[35px] pb-3 relative w-full">
              <div className="absolute border-b border-black-900 border-solid flex-1 h-[33px] inset-[0] m-auto w-full"></div>
              <Text
                className="absolute left-[0] text-gray-800 text-xl top-[0] w-auto"
                size="txtRobotoRomanMedium20Gray800"
              >
                {props?.personaldetailsOne}
              </Text>
            </div>
          </div>
          <div className="flex md:flex-col flex-row md:gap-10 items-start justify-between max-w-[851px] w-full">
            <div className="flex flex-col gap-3 items-center justify-center md:pl-10 sm:pl-5 pl-[70px] w-auto">
              <Img
                className="h-[220px] md:h-auto rounded-[50%] w-[220px]"
                src="images/img_rectangle1243.png"
                alt="rectangle1243"
              />
              <Button
                className="cursor-pointer flex items-center justify-center min-w-[220px] rounded-[20px]"
                leftIcon={
                  <Img
                    className="h-5 mb-px mr-2.5"
                    src="images/img_settings.svg"
                    alt="settings"
                  />
                }
                color="light_blue_700"
                size="sm"
                variant="outline"
              >
                <div className="font-raleway font-semibold leading-[normal] text-base text-left">
                  {props?.updateprofilebuttonprops}
                </div>
              </Button>
            </div>
            <div className="h-[215px] md:h-[216px] sm:h-[292px] relative w-[457px] sm:w-full">
              <div className="absolute bg-white-A700 h-[215px] inset-[0] m-auto w-full"></div>
              <div className="absolute flex flex-col gap-5 h-full inset-[0] items-start justify-start m-auto w-[457px] sm:w-full">
                <div className="flex flex-col gap-5 items-start justify-start w-full">
                  <div className="flex sm:flex-col flex-row gap-4 items-start justify-start w-full">
                    <div className="flex flex-col gap-0.5 items-start justify-start w-56">
                      <Text
                        className="text-base text-black-900 w-auto"
                        size="txtRobotoRomanSemiBold16Black900"
                      >
                        {props?.firstnametextprops}
                      </Text>
                      <Input
                        name="frame512"
                        placeholder="Lorem"
                        className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
                        wrapClassName="border border-black-900_7f border-solid w-full"
                        shape="round"
                        color="gray_50_03"
                        size="xl"
                        variant="fill"
                      ></Input>
                    </div>
                    <div className="flex flex-1 flex-col gap-0.5 items-start justify-start w-full">
                      <Text
                        className="text-base text-black-900 w-auto"
                        size="txtRobotoRomanSemiBold16Black900"
                      >
                        {props?.lastnametextprops}
                      </Text>
                      <Input
                        name="frame506"
                        placeholder="Lorem"
                        className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
                        wrapClassName="border border-black-900_7f border-solid w-full"
                        shape="round"
                        color="gray_50_03"
                        size="xl"
                        variant="fill"
                      ></Input>
                    </div>
                  </div>
                  <div className="flex flex-col gap-0.5 items-start justify-start w-[457px] sm:w-full">
                    <Text
                      className="text-base text-black-900 w-auto"
                      size="txtRobotoRomanSemiBold16Black900"
                    >
                      {props?.mobiletextprops}
                    </Text>
                    <Input
                      name="frame511"
                      placeholder="Lorem"
                      className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
                      wrapClassName="border border-black-900_7f border-solid w-full"
                      shape="round"
                      color="gray_50_03"
                      size="xl"
                      variant="fill"
                    ></Input>
                    <Text
                      className="text-black-900 text-xs w-auto"
                      size="txtRobotoRomanRegular12Black900"
                    >
                      {props?.loremipsumdolorOne}
                    </Text>
                  </div>
                </div>
                <Button
                  className="cursor-pointer font-raleway font-semibold h-[39px] leading-[normal] rounded text-base text-center w-[94px]"
                  color="light_blue_700"
                  size="sm"
                  variant="fill"
                >
                  {props?.savebuttonprops}
                </Button>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-5 items-end justify-center max-w-[851px] w-full">
            <div className="flex flex-col gap-2 items-start justify-center w-full">
              <Text
                className="text-black-900 text-xl w-auto"
                size="txtRobotoRomanMedium20Black900"
              >
                {props?.emailaddresstextprops}
              </Text>
              <Line className="bg-black-900_7f h-px w-full" />
            </div>
            <div className="flex flex-col gap-5 items-start justify-start w-[457px] sm:w-full">
              <div className="flex flex-col gap-0.5 items-start justify-start w-[457px] sm:w-full">
                <Text
                  className="text-base text-black-900 w-auto"
                  size="txtRobotoRomanSemiBold16Black900"
                >
                  {props?.emailtextprops}
                </Text>
                <Input
                  name="frame510"
                  placeholder="Lorem"
                  className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
                  wrapClassName="border border-black-900_7f border-solid w-full"
                  shape="round"
                  color="gray_50_03"
                  size="xl"
                  variant="fill"
                ></Input>
              </div>
              <Button
                className="cursor-pointer font-raleway font-semibold h-[39px] leading-[normal] rounded text-base text-center w-[94px]"
                color="light_blue_700"
                size="sm"
                variant="fill"
              >
                {props?.savebuttonprops1}
              </Button>
            </div>
          </div>
          <div className="flex flex-col gap-5 items-end justify-start max-w-[851px] w-full">
            <div className="flex flex-col gap-2 items-start justify-center w-full">
              <Text
                className="text-black-900 text-xl w-auto"
                size="txtRobotoRomanMedium20Black900"
              >
                {props?.passwordtextprops}
              </Text>
              <Line className="bg-black-900_7f h-px w-full" />
            </div>
            <div className="flex flex-col gap-5 items-start justify-start w-auto sm:w-full">
              <div className="flex flex-col gap-0.5 items-start justify-start w-[457px] sm:w-full">
                <Text
                  className="text-base text-black-900 w-auto"
                  size="txtRobotoRomanSemiBold16Black900"
                >
                  {props?.currentpasswordtextprops}
                </Text>
                <Input
                  name="frame508"
                  placeholder="Lorem"
                  className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
                  wrapClassName="border border-black-900_7f border-solid w-full"
                  shape="round"
                  color="gray_50_03"
                  size="xl"
                  variant="fill"
                ></Input>
              </div>
              <div className="flex flex-col gap-0.5 items-start justify-start w-[457px] sm:w-full">
                <Text
                  className="text-base text-black-900 w-auto"
                  size="txtRobotoRomanSemiBold16Black900"
                >
                  {props?.newpasswordtextprops}
                </Text>
                <Input
                  name="frame507"
                  placeholder="Lorem"
                  className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
                  wrapClassName="border border-black-900_7f border-solid w-full"
                  shape="round"
                  color="gray_50_03"
                  size="xl"
                  variant="fill"
                ></Input>
                <div className="flex flex-col items-start justify-start w-full">
                  <Text
                    className="text-black-900 text-xs w-auto"
                    size="txtRobotoRomanRegular12Black900"
                  >
                    {props?.makesureyourpasOne}
                  </Text>
                </div>
              </div>
              <div className="flex flex-col gap-0.5 items-start justify-start w-[457px] sm:w-full">
                <Text
                  className="text-base text-black-900 w-auto"
                  size="txtRobotoRomanSemiBold16Black900"
                >
                  {props?.confirmpasswordtextprops}
                </Text>
                <Input
                  name="frame506_One"
                  placeholder="Lorem"
                  className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
                  wrapClassName="border border-black-900_7f border-solid w-full"
                  shape="round"
                  color="gray_50_03"
                  size="xl"
                  variant="fill"
                ></Input>
              </div>
              <Button
                className="cursor-pointer font-raleway font-semibold h-[39px] leading-[normal] rounded text-base text-center w-[94px]"
                color="light_blue_700"
                size="sm"
                variant="fill"
              >
                {props?.savebuttonprops2}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

MyProfileProfile.defaultProps = {
  myprofiletextprops: "My Profile",
  personaldetailsOne: "Personal Details",
  updateprofilebuttonprops: "Update Profile Image",
  firstnametextprops: "First Name",
  lastnametextprops: "Last Name",
  mobiletextprops: "Mobile",
  loremipsumdolorOne: "*lorem ipsum dolor sit amet",
  savebuttonprops: "Save",
  emailaddresstextprops: "Email Address",
  emailtextprops: "Email",
  savebuttonprops1: "Save",
  passwordtextprops: "Password",
  currentpasswordtextprops: "Current Password",
  newpasswordtextprops: "New Password",
  makesureyourpasOne:
    "Make Sure Your Password is 8 Characters Long and Contain Numbers.",
  confirmpasswordtextprops: "Confirm Password",
  savebuttonprops2: "Save",
};

export default MyProfileProfile;
