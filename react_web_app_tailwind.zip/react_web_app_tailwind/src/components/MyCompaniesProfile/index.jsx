import React from "react";

import { createColumnHelper } from "@tanstack/react-table";

import { Button, Img, Input, ReactTable, Text } from "components";

import { CloseSVG } from "../../assets/images";

const MyCompaniesProfile = (props) => {
  const table1Data = React.useRef([
    {
      rowcompany: "Company Id - 01235",
      rowemail: "4",
      rowtelephone: "12/10/2023",
      rowframe400: "No. 101/A, Abc Road, Abc 001, ABC",
    },
    {
      rowcompany: "Lorem ipsum dolor",
      rowemail: "4",
      rowtelephone: "12/10/2023",
      rowframe400: "2",
    },
    {
      rowcompany: "Company Id - 01235",
      rowemail: "4",
      rowtelephone: "12/10/2023",
      rowframe400: "2",
    },
    {
      rowcompany: "Lorem ipsum dolor",
      rowemail: "4",
      rowtelephone: "12/10/2023",
      rowframe400: "2",
    },
  ]);
  const table1Columns = React.useMemo(() => {
    const table1ColumnHelper = createColumnHelper();
    return [
      table1ColumnHelper.accessor("rowcompany", {
        cell: (info) => {
          info?.getValue();
        },
        header: (info) => (
          <div className="flex flex-row items-center justify-center min-w-[290px]">
            <Button
              className="cursor-pointer font-bold font-cardo leading-[normal] min-w-[289px] text-center text-xl"
              shape="square"
              color="light_blue_700"
              size="sm"
              variant="fill"
            >
              {props?.companybutton}
            </Button>
          </div>
        ),
      }),
      table1ColumnHelper.accessor("rowemail", {
        cell: (info) => (
          <Text
            className="md:mt-0 mt-[68px] pb-[35px] pt-[-151px] text-black-900 text-right text-xl"
            size="txtRobotoRomanMedium20Black900"
          >
            {info?.getValue()}
          </Text>
        ),
        header: (info) => (
          <div className="flex flex-row items-center justify-end min-w-[130px]">
            <Button
              className="cursor-pointer font-bold font-cardo leading-[normal] min-w-[130px] text-center text-xl"
              shape="square"
              color="light_blue_700"
              size="sm"
              variant="fill"
            >
              {props?.emailbutton}
            </Button>
          </div>
        ),
      }),
      table1ColumnHelper.accessor("rowtelephone", {
        cell: (info) => (
          <Text
            className="md:mt-0 mt-[68px] pb-[35px] pt-[-151px] text-black-900 text-center text-xl"
            size="txtRobotoRomanRegular20Black900"
          >
            {info?.getValue()}
          </Text>
        ),
        header: (info) => (
          <div className="flex flex-row items-center justify-center min-w-[169px]">
            <Button
              className="cursor-pointer font-bold font-cardo leading-[normal] min-w-[169px] text-center text-xl"
              shape="square"
              color="light_blue_700"
              size="sm"
              variant="fill"
            >
              {props?.telephonebutton}
            </Button>
          </div>
        ),
      }),
      table1ColumnHelper.accessor("rowframe400", {
        cell: (info) => (
          <Text
            className="flex-1 pb-8 pl-1 pt-[-51px] text-black-900 text-xl w-full"
            size="txtRobotoRomanRegular20Black900"
          >
            {info?.getValue()}
          </Text>
        ),
        header: (info) => (
          <div className="flex flex-row items-center justify-start min-w-[350px]">
            <Text
              className="px-[3px] py-[11px] text-center text-white-A700 text-xl"
              size="txtCardoBold20WhiteA700"
            >
              {props?.addresstext}
            </Text>
            <Button
              className="cursor-pointer font-bold font-cardo leading-[normal] min-w-[123px] text-center text-xl"
              shape="square"
              color="light_blue_700"
              size="sm"
              variant="fill"
            >
              {props?.branchesbutton}
            </Button>
          </div>
        ),
      }),
    ];
  }, []);

  const [frame456value, setFrame456value] = React.useState("");

  return (
    <>
      <div className={props.className}>
        <div className="flex flex-col gap-7 items-start justify-start w-auto sm:w-full">
          <Input
            name="frame456"
            placeholder="Profile"
            value={frame456value}
            onChange={(e) => setFrame456value(e)}
            className="!placeholder:text-gray-900_02 !text-gray-900_02 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <Img
                className="mt-[3px] mb-px cursor-pointer h-6 mr-3"
                src="images/img_search_gray_900_02.svg"
                alt="search"
              />
            }
            suffix={
              <CloseSVG
                fillColor="#1d1d1f"
                className="cursor-pointer h-6 my-auto"
                onClick={() => setFrame456value("")}
                style={{
                  visibility: frame456value?.length <= 0 ? "hidden" : "visible",
                }}
                height={24}
                width={24}
                viewBox="0 0 24 24"
              />
            }
            shape="square"
            color="white_A700"
            size="lg"
            variant="fill"
          ></Input>
          <Input
            name="frame457"
            placeholder="Company"
            className="!placeholder:text-light_blue-700 !text-light_blue-700 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <Img
                className="mt-px mb-1 h-6 mr-3"
                src="images/img_thumbsup_light_blue_700_24x24.svg"
                alt="thumbs_up"
              />
            }
            shape="square"
            color="light_blue_400_1e"
            size="lg"
            variant="fill"
          ></Input>
          <Input
            name="frame458"
            placeholder="Orders"
            className="!placeholder:text-gray-900_02 !text-gray-900_02 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <div className="h-6 mt-[3px] mb-px mr-3 w-6 outline-gray-900_02 outline-[1px] outline">
                <Img
                  className="h-6 my-auto"
                  src="images/img_bag.svg"
                  alt="bag"
                />
              </div>
            }
            shape="square"
            color="white_A700"
            size="lg"
            variant="fill"
          ></Input>
        </div>
        <div className="bg-white-A700 flex flex-col gap-6 items-start justify-start max-w-[987px] p-6 sm:px-5 rounded-[12px] shadow-bs w-full">
          <div className="flex flex-col gap-3 items-start justify-start w-full">
            <Text
              className="text-2xl md:text-[22px] text-gray-800 sm:text-xl w-auto"
              size="txtInterBold24Gray800"
            >
              {props?.mycompaniestext}
            </Text>
            <div className="border-b border-black-900 border-solid flex sm:flex-col flex-row gap-2.5 items-center justify-between pb-2.5 w-full">
              <Text
                className="text-gray-800 text-xl w-auto"
                size="txtInterRegular20Gray800"
              >
                {props?.companydetailstext}
              </Text>
              <Button
                className="border-2 border-light_blue-700 border-solid cursor-pointer flex items-center justify-center min-w-[216px] rounded-[20px]"
                leftIcon={
                  <Img
                    className="h-6 mr-3"
                    src="images/img_plus.svg"
                    alt="plus"
                  />
                }
                color="white_A700"
                size="sm"
                variant="fill"
              >
                <div className="!text-light_blue-700 font-inter font-semibold leading-[normal] text-base text-left">
                  {props?.addnewcompanybutton}
                </div>
              </Button>
            </div>
          </div>
          <div className="overflow-auto w-full">
            <ReactTable
              columns={table1Columns}
              data={table1Data.current}
              rowClass={""}
              headerClass="bg-light_blue-700"
            />
          </div>
        </div>
      </div>
    </>
  );
};

MyCompaniesProfile.defaultProps = {
  mycompaniestext: "My Companies",
  companydetailstext: "Company Details",
  addnewcompanybutton: "Add New Company",
  companybutton: "Company",
  emailbutton: "Email",
  telephonebutton: "Telephone",
  addresstext: "Address ( Main Branch )",
  branchesbutton: "Branches",
  companyidtext: (
    <Text
      className="pl-[18px] pt-[13px] text-base text-black-900 text-center"
      size="txtRobotoRomanRegular16Black900"
    >
      <span className="text-black-900 font-inter font-normal">
        Company Id -{" "}
      </span>
      <span className="text-black-900 font-inter font-medium">01235</span>
    </Text>
  ),
  fourtext: "4",
  datetext: "12/10/2023",
  addresstext1: "No. 101/A, Abc Road, Abc 001, ABC",
  loremipsumdolortext: "Lorem ipsum dolor",
  fourtext1: "4",
  datetext1: "12/10/2023",
  addresstext2: "No. 101/A, Abc Road, Abc 001, ABC",
  twotext: "2",
  companyidtext1: (
    <Text
      className="pb-[-11px] pl-[18px] pt-[21px] text-base text-black-900 text-center"
      size="txtRobotoRomanRegular16Black900"
    >
      <span className="text-black-900 font-inter font-normal">
        Company Id -{" "}
      </span>
      <span className="text-black-900 font-inter font-medium">01235</span>
    </Text>
  ),
  fourtext2: "4",
  datetext2: "12/10/2023",
  twotext1: "2",
  loremipsumdolortext1: "Lorem ipsum dolor",
  fourtext3: "4",
  datetext3: "12/10/2023",
  addresstext3: "No. 101/A, Abc Road, Abc 001, ABC",
  twotext2: "2",
};

export default MyCompaniesProfile;
