import React from "react";

import { Button, Img, List, Text } from "components";

const AddCompanyFooter = (props) => {
  return (
    <>
      <div className={props.className}>
        <div className="flex flex-col gap-[19px] items-start justify-start w-full">
          <div className="flex md:flex-col flex-row md:gap-10 items-start justify-between max-w-[1240px] w-full">
            <div className="flex sm:flex-1 flex-col gap-[39px] h-60 md:h-auto items-start justify-start w-auto sm:w-full">
              <div className="flex flex-col gap-3 items-start justify-center w-[545px] sm:w-full">
                <Text
                  className="max-w-[545px] md:max-w-full sm:text-4xl md:text-[38px] text-[40px] text-gray-800"
                  size="txtCardoBold40Gray800"
                >
                  {props?.offer}
                </Text>
                <Text
                  className="max-w-[505px] md:max-w-full text-base text-gray-800_02"
                  size="txtRalewayRomanMedium16Gray80002"
                >
                  {props?.description}
                </Text>
              </div>
              <div className="flex sm:flex-col flex-row gap-1 items-center justify-center w-full">
                <Text
                  className="bg-white-A700 border border-gray-800_87 border-solid flex-1 justify-center pl-5 sm:pr-5 pr-[35px] py-3 rounded-[12px] text-gray-800_c1 text-sm w-full"
                  size="txtRalewayRomanBold14"
                >
                  {props?.frame205}
                </Text>
                <Button
                  className="!text-white-A700 cursor-pointer font-bold font-raleway leading-[normal] rounded-[12px] text-base text-center w-[90px]"
                  color="light_blue_800"
                  size="md"
                  variant="fill"
                >
                  {props?.send}
                </Button>
              </div>
            </div>
            <div className="flex sm:flex-1 sm:flex-col flex-row gap-3 items-start justify-between w-[594px] sm:w-full">
              <List
                className="sm:flex-col flex-row gap-[49px] grid grid-cols-2 w-[51%] sm:w-full"
                orientation="horizontal"
              >
                <div className="flex flex-col gap-3 items-start justify-start w-auto">
                  <Text
                    className="text-2xl md:text-[22px] text-center text-gray-800 sm:text-xl w-auto"
                    size="txtRalewayRomanBold24Gray800"
                  >
                    {props?.quicklinks}
                  </Text>
                  <Text
                    className="text-base text-gray-500 w-auto"
                    size="txtRalewayRomanSemiBold16"
                  >
                    {props?.home}
                  </Text>
                  <Text
                    className="text-base text-gray-500 w-auto"
                    size="txtRalewayRomanSemiBold16"
                  >
                    {props?.aboutus}
                  </Text>
                  <Text
                    className="text-base text-gray-500 w-auto"
                    size="txtRalewayRomanSemiBold16"
                  >
                    {props?.ourservices}
                  </Text>
                  <Text
                    className="text-base text-gray-500 w-auto"
                    size="txtRalewayRomanSemiBold16"
                  >
                    {props?.contactus}
                  </Text>
                </div>
                <div className="flex flex-col gap-3 items-start justify-start w-auto">
                  <Text
                    className="text-2xl md:text-[22px] text-center text-gray-800 sm:text-xl w-auto"
                    size="txtRalewayRomanBold24Gray800"
                  >
                    {props?.sections}
                  </Text>
                  <Text
                    className="text-base text-gray-500 w-auto"
                    size="txtRalewayRomanSemiBold16"
                  >
                    {props?.products}
                  </Text>
                  <Text
                    className="text-base text-gray-500 w-auto"
                    size="txtRalewayRomanSemiBold16"
                  >
                    {props?.categories}
                  </Text>
                  <Text
                    className="text-base text-gray-500 w-auto"
                    size="txtRalewayRomanSemiBold16"
                  >
                    {props?.repairing}
                  </Text>
                  <Text
                    className="text-base text-gray-500 w-auto"
                    size="txtRalewayRomanSemiBold16"
                  >
                    {props?.delivery}
                  </Text>
                </div>
              </List>
              <div className="flex flex-col gap-3 items-start justify-start w-auto">
                <Text
                  className="text-2xl md:text-[22px] text-center text-gray-800 sm:text-xl w-auto"
                  size="txtRalewayRomanBold24Gray800"
                >
                  {props?.customerserviceOne}
                </Text>
                <Text
                  className="text-base text-gray-500 w-auto"
                  size="txtRalewayRomanSemiBold16"
                >
                  {props?.emailOne}
                </Text>
                <Text
                  className="text-base text-gray-500 w-auto"
                  size="txtRalewayRomanSemiBold16"
                >
                  {props?.p0117012343}
                </Text>
                <Text
                  className="text-base text-gray-500 w-auto"
                  size="txtRalewayRomanSemiBold16"
                >
                  {props?.p94771432007}
                </Text>
                <Text
                  className="text-base text-gray-500 w-auto"
                  size="txtRalewayRomanSemiBold16"
                >
                  {props?.p94772985099}
                </Text>
                <Text
                  className="max-w-[245px] md:max-w-full text-base text-gray-500"
                  size="txtRalewayRomanSemiBold16"
                >
                  {props?.descriptionOne}
                </Text>
              </div>
            </div>
          </div>
          <div className="flex sm:flex-col flex-row gap-5 items-start justify-start md:ml-[0] ml-[839px] w-auto sm:w-full">
            <Text
              className="text-base text-gray-800 w-auto"
              size="txtRalewayRomanSemiBold16Gray800"
            >
              {props?.yourprivacychoiOne}
            </Text>
            <Text
              className="text-base text-gray-800 w-auto"
              size="txtRalewayRomanSemiBold16Gray800"
            >
              {props?.privacypolicy}
            </Text>
            <Text
              className="text-base text-gray-800 w-auto"
              size="txtRalewayRomanSemiBold16Gray800"
            >
              {props?.termsofuse}
            </Text>
          </div>
          <div className="border-gray-800 border-solid border-t flex md:flex-col flex-row md:gap-10 items-end justify-between max-w-[1240px] pt-5 w-full">
            <div className="flex flex-1 md:flex-col flex-row gap-3 items-start justify-start max-w-[812px] w-full">
              <Img
                className="sm:flex-1 h-[35px] md:h-auto object-cover w-[88px] sm:w-full"
                src="images/img_rectangle59.png"
                alt="rectangleSixtyFour"
              />
              <div className="flex sm:flex-1 flex-col gap-3 items-start justify-start w-[554px] sm:w-full">
                {props?.price}
                <Text
                  className="text-base text-gray-800 w-auto"
                  size="txtCardoRegular16Gray800"
                >
                  {props?.p2022modernofficone}
                </Text>
              </div>
            </div>
            <div className="flex flex-col gap-1 items-start justify-start w-auto">
              <Text
                className="text-base text-gray-800 w-auto"
                size="txtRalewayRomanSemiBold16Gray800"
              >
                {props?.officialtechnolOne}
              </Text>
              <Img
                className="h-[54px] md:h-auto object-cover w-[257px] sm:w-full"
                src="images/img_rectangle64.png"
                alt="rectangleSixtyFour_One"
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

AddCompanyFooter.defaultProps = {
  offer: (
    <>
      Let’s Get 50% Discount For <br />
      All Products
    </>
  ),
  description:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
  frame205: "Email",
  send: "Send",
  quicklinks: "Quick Links",
  home: "Home",
  aboutus: "About us",
  ourservices: "Our Services",
  contactus: "Contact us",
  sections: "Sections",
  products: "Products",
  categories: "Categories",
  repairing: "Repairing",
  delivery: "Delivery",
  customerserviceOne: "Customer Service",
  emailOne: "contact@moa.com",
  p0117012343: "011 701 2343",
  p94771432007: "+94 77 143 2007 - Hotline",
  p94772985099: "+94 77 298 5099 - Hotline",
  descriptionOne: (
    <>
      No. 501A,
      <br />
      Level #1, Thimbirigasyaya Road, Colombo 05,
      <br />
      Sri Lanka.
    </>
  ),
  yourprivacychoiOne: "Your Privacy Choices",
  privacypolicy: "Privacy Policy",
  termsofuse: "Terms of Use",
  price: (
    <Text
      className="max-w-[543px] md:max-w-full sm:text-4xl md:text-[38px] text-[40px] text-gray-800"
      size="txtRalewayRomanBold40"
    >
      <span className="md:text-[22px] sm:text-xl text-gray-800 font-cardo text-left text-2xl font-bold">
        <>
          MODERN OFFICE AUTOMATION (PVT) LTD
          <br />
        </>
      </span>
      <span className="text-gray-800 font-cardo text-left text-base font-normal">
        ( Member of Modern Group of Companies )
      </span>
    </Text>
  ),
  p2022modernofficone: "© 2022 Modern Office Automation. All Rights Reserved.",
  officialtechnolOne: "Official Technology Partner",
};

export default AddCompanyFooter;
