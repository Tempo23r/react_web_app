import React from "react";

import { Button, Img, Input, Line, Text } from "components";

import { CloseSVG } from "../../assets/images";

const AddCompanyProfile = (props) => {
  const [frame456value, setFrame456value] = React.useState("");

  return (
    <>
      <div className={props.className}>
        <div className="flex flex-col gap-7 items-start justify-start w-auto sm:w-full">
          <Input
            name="frame456"
            placeholder="Profile"
            value={frame456value}
            onChange={(e) => setFrame456value(e)}
            className="!placeholder:text-gray-900_02 !text-gray-900_02 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <Img
                className="mt-[3px] mb-px cursor-pointer h-6 mr-3"
                src="images/img_search_gray_900_02.svg"
                alt="search"
              />
            }
            suffix={
              <CloseSVG
                fillColor="#1d1d1f"
                className="cursor-pointer h-6 my-auto"
                onClick={() => setFrame456value("")}
                style={{
                  visibility: frame456value?.length <= 0 ? "hidden" : "visible",
                }}
                height={24}
                width={24}
                viewBox="0 0 24 24"
              />
            }
            shape="square"
            color="white_A700"
            size="lg"
            variant="fill"
          ></Input>
          <Input
            name="frame457"
            placeholder="Company"
            className="!placeholder:text-light_blue-700 !text-light_blue-700 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <Img
                className="mt-px mb-1 h-6 mr-3"
                src="images/img_thumbsup_light_blue_700_24x24.svg"
                alt="thumbs_up"
              />
            }
            shape="square"
            color="light_blue_400_1e"
            size="lg"
            variant="fill"
          ></Input>
          <Input
            name="frame458"
            placeholder="Orders"
            className="!placeholder:text-gray-900_02 !text-gray-900_02 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <div className="h-6 mt-[3px] mb-px mr-3 w-6 outline-gray-900_02 outline-[1px] outline">
                <Img
                  className="h-6 my-auto"
                  src="images/img_bag.svg"
                  alt="bag"
                />
              </div>
            }
            shape="square"
            color="white_A700"
            size="lg"
            variant="fill"
          ></Input>
        </div>
        <div className="bg-white-A700 flex flex-col gap-6 items-start justify-start max-w-[987px] p-6 sm:px-5 rounded-[12px] shadow-bs w-full">
          <div className="flex flex-col gap-[30px] items-start justify-start w-full">
            <Text
              className="text-2xl md:text-[22px] text-gray-800 sm:text-xl w-auto"
              size="txtInterBold24Gray800"
            >
              {props?.addcompanytext}
            </Text>
            <Text
              className="border-b border-black-900 border-solid pb-2.5 sm:pr-5 pr-[35px] text-gray-800 text-xl w-full"
              size="txtRobotoRomanMedium20Gray800"
            >
              {props?.companydetailstext}
            </Text>
          </div>
          <div className="flex md:flex-col flex-row md:gap-10 items-start justify-between max-w-[851px] w-full">
            <div className="flex flex-col gap-3 items-start justify-center md:pl-10 sm:pl-5 pl-[70px] w-auto">
              <Text
                className="text-base text-black-900 w-auto"
                size="txtInterBold16"
              >
                {props?.addcompanylogo}
              </Text>
              <Input
                name="frame234"
                placeholder="Add Logo"
                className="!placeholder:text-light_blue-700 !text-light_blue-700 font-inter font-semibold leading-[normal] p-0 text-base text-left w-full"
                wrapClassName="flex rounded-[20px] w-4/5"
                prefix={
                  <Img
                    className="h-6 mr-2.5 my-auto"
                    src="images/img_plus.svg"
                    alt="plus"
                  />
                }
                color="light_blue_700"
                size="xl"
                variant="outline"
              ></Input>
            </div>
            <div className="bg-white-A700 flex sm:flex-1 flex-col items-end justify-start w-auto sm:w-full">
              <div className="flex flex-col gap-5 items-start justify-start w-[457px] sm:w-full">
                <div className="flex flex-col gap-5 items-start justify-start w-full">
                  <div className="flex flex-col gap-0.5 items-start justify-start w-[457px] sm:w-full">
                    <Text
                      className="text-base text-black-900 w-auto"
                      size="txtRobotoRomanSemiBold16Black900"
                    >
                      {props?.companyname}
                    </Text>
                    <Input
                      name="frame511"
                      placeholder="Lorem"
                      className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
                      wrapClassName="border border-black-900_7f border-solid w-full"
                      shape="round"
                      color="gray_50_03"
                      size="xl"
                      variant="fill"
                    ></Input>
                  </div>
                  <div className="flex flex-col gap-0.5 items-start justify-start w-[457px] sm:w-full">
                    <Text
                      className="text-base text-black-900 w-auto"
                      size="txtRobotoRomanSemiBold16Black900"
                    >
                      {props?.companytype}
                    </Text>
                    <Input
                      name="frame511_One"
                      placeholder="Lorem"
                      className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] p-0 text-left text-sm w-full"
                      wrapClassName="border border-black-900_7f border-solid flex md:h-auto w-[457px] sm:w-full"
                      suffix={
                        <div className="ml-[35px] sm:w-full sm:mx-0 w-[3%] outline-black-900 outline-[1px] outline my-[5px]">
                          <Img
                            className="my-auto"
                            src="images/img_arrowdown_black_900.svg"
                            alt="arrow_down"
                          />
                        </div>
                      }
                      shape="round"
                      color="gray_50_03"
                      size="xl"
                      variant="fill"
                    ></Input>
                  </div>
                  <div className="flex flex-col gap-0.5 items-start justify-start w-[457px] sm:w-full">
                    <Text
                      className="text-base text-black-900 w-auto"
                      size="txtRobotoRomanSemiBold16Black900"
                    >
                      {props?.brnumber}
                    </Text>
                    <Input
                      name="frame511_Two"
                      placeholder="Lorem"
                      className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
                      wrapClassName="border border-black-900_7f border-solid w-full"
                      shape="round"
                      color="gray_50_03"
                      size="xl"
                      variant="fill"
                    ></Input>
                    <Text
                      className="text-black-900 text-xs w-auto"
                      size="txtRobotoRomanRegular12Black900"
                    >
                      {props?.loremipsumdolorOne}
                    </Text>
                  </div>
                </div>
                <Button
                  className="cursor-pointer font-raleway font-semibold h-[39px] leading-[normal] rounded text-base text-center w-[94px]"
                  color="light_blue_700"
                  size="sm"
                  variant="fill"
                >
                  {props?.savebutton}
                </Button>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-5 items-end justify-center max-w-[851px] w-full">
            <div className="flex flex-col gap-2 items-start justify-center w-full">
              <div className="flex flex-col items-center justify-start w-full">
                <Text
                  className="text-black-900 text-xl w-auto"
                  size="txtRobotoRomanMedium20Black900"
                >
                  {props?.branch}
                </Text>
              </div>
              <Line className="bg-black-900_7f h-px w-full" />
            </div>
            <div className="flex flex-col gap-5 sm:h-auto items-start justify-start w-[457px] sm:w-full">
              <div className="flex flex-col gap-0.5 items-start justify-start w-[457px] sm:w-full">
                <Text
                  className="text-base text-black-900 w-auto"
                  size="txtRobotoRomanSemiBold16Black900"
                >
                  {props?.branchnametext}
                </Text>
                <Input
                  name="frame510"
                  placeholder="Lorem"
                  className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
                  wrapClassName="border border-black-900_7f border-solid w-full"
                  shape="round"
                  color="gray_50_03"
                  size="xl"
                  variant="fill"
                ></Input>
              </div>
              <div className="flex flex-col gap-0.5 items-start justify-start w-[457px] sm:w-full">
                <Text
                  className="text-base text-black-900 w-auto"
                  size="txtRobotoRomanSemiBold16Black900"
                >
                  {props?.emailTwo}
                </Text>
                <Input
                  name="frame510_One"
                  placeholder="Lorem"
                  className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
                  wrapClassName="border border-black-900_7f border-solid w-full"
                  shape="round"
                  color="gray_50_03"
                  size="xl"
                  variant="fill"
                ></Input>
              </div>
              <div className="flex flex-col gap-0.5 items-start justify-start w-[457px] sm:w-full">
                <Text
                  className="text-base text-black-900 w-auto"
                  size="txtRobotoRomanSemiBold16Black900"
                >
                  {props?.branchtelephoneOne}
                </Text>
                <Input
                  name="frame511_Three"
                  placeholder="Lorem"
                  className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
                  wrapClassName="border border-black-900_7f border-solid w-full"
                  shape="round"
                  color="gray_50_03"
                  size="xl"
                  variant="fill"
                ></Input>
                <Text
                  className="text-black-900 text-xs w-auto"
                  size="txtRobotoRomanRegular12Black900"
                >
                  {props?.loremipsumdolorThree}
                </Text>
              </div>
              <div className="flex flex-col gap-0.5 items-start justify-start w-[457px] sm:w-full">
                <Text
                  className="text-base text-black-900 w-auto"
                  size="txtRobotoRomanSemiBold16Black900"
                >
                  {props?.address}
                </Text>
                <Input
                  name="frame509"
                  placeholder="Lorem"
                  className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
                  wrapClassName="border border-black-900_7f border-solid w-full"
                  shape="round"
                  color="gray_50_03"
                  size="xl"
                  variant="fill"
                ></Input>
                <Text
                  className="bg-gray-50_03 border border-black-900_7f border-solid h-[39px] justify-center pl-5 sm:pr-5 pr-[35px] py-2.5 rounded text-black-900_cc text-sm w-[457px]"
                  size="txtRobotoRomanMedium14"
                >
                  {props?.frame510two}
                </Text>
                <Text
                  className="bg-gray-50_03 border border-black-900_7f border-solid h-[39px] justify-center pl-5 sm:pr-5 pr-[35px] py-2.5 rounded text-black-900_cc text-sm w-[457px]"
                  size="txtRobotoRomanMedium14"
                >
                  {props?.frame511four}
                </Text>
              </div>
              <Button
                className="cursor-pointer font-raleway font-semibold h-[39px] leading-[normal] rounded text-base text-center w-[94px]"
                color="light_blue_700"
                size="sm"
                variant="fill"
              >
                {props?.savebuttonone}
              </Button>
            </div>
          </div>
          <div className="flex flex-col items-start justify-center w-full">
            <div className="flex flex-col items-center justify-start w-full">
              <Button
                className="cursor-pointer flex items-center justify-center min-w-[165px] rounded-[20px]"
                leftIcon={
                  <Img
                    className="h-6 mr-2.5"
                    src="images/img_plus.svg"
                    alt="plus"
                  />
                }
                color="light_blue_700"
                size="sm"
                variant="outline"
              >
                <div className="font-inter font-semibold leading-[normal] text-base text-left">
                  {props?.addbranchbutton}
                </div>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

AddCompanyProfile.defaultProps = {
  addcompanytext: "Add Company",
  companydetailstext: "Company Details",
  addcompanylogo: "Add Company Logo :",
  companyname: "Company Name",
  companytype: "Company Type",
  brnumber: "BR Number",
  loremipsumdolorOne: "*lorem ipsum dolor sit amet",
  savebutton: "Save",
  branch: "Branch",
  branchnametext: "Branch Name",
  emailTwo: "Email",
  branchtelephoneOne: "Branch Telephone Number",
  loremipsumdolorThree: "*lorem ipsum dolor sit amet",
  address: "Address",
  frame510two: "Lorem",
  frame511four: "Lorem",
  savebuttonone: "Save",
  addbranchbutton: "Add Branch",
};

export default AddCompanyProfile;
