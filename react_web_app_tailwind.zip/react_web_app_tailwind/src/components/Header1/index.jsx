import React from "react";

import { Img, Input, Text } from "components";

import { CloseSVG } from "../../assets/images";

const Header1 = (props) => {
  const [frame115value, setFrame115value] = React.useState("");

  return (
    <>
      <header className={props.className}>
        <div className="bg-white-A700_84 flex md:flex-col flex-row md:gap-5 items-center justify-start p-[5px] w-full">
          <Text
            className="md:ml-[0] ml-[94px] text-gray-900 text-xs"
            size="txtCardoBold12"
          >
            011 2345 678
          </Text>
          <Text
            className="mb-0.5 md:ml-[0] ml-[180px] text-gray-900 text-xs"
            size="txtCardoBold12"
          >
            ISLAND WIDE DELIVERY AVAILABLE | 1-2 DAYS WITHIN COLOMBO AND CLOSE
            SUBURBS | 1-3 DAYS ALL OTHER AREAS
          </Text>
          <Img
            className="h-3.5 md:ml-[0] ml-[214px] w-[34px]"
            src="images/img_television.svg"
            alt="television"
          />
        </div>
        <div className="flex md:flex-col flex-row md:gap-10 items-center justify-between max-w-[1440px] md:px-10 sm:px-5 px-[100px] py-1.5 w-full">
          <Img
            className="sm:flex-1 h-[55px] md:h-auto object-cover w-[133px] sm:w-full"
            src="images/img_rectangle59.png"
            alt="rectangleFiftyNine"
          />
          <div className="flex sm:flex-1 sm:flex-col flex-row gap-5 items-center justify-center w-auto sm:w-full">
            <div className="flex flex-col items-center justify-center w-auto">
              <Text
                className="text-white-A700 text-xl w-auto"
                size="txtRalewayRomanSemiBold20WhiteA700"
              >
                Home
              </Text>
            </div>
            <div className="flex flex-col items-center justify-center w-auto">
              <Text
                className="text-white-A700 text-xl w-auto"
                size="txtRalewayRomanSemiBold20WhiteA700"
              >
                |
              </Text>
            </div>
            <div className="flex flex-col items-center justify-center w-auto">
              <Text
                className="text-white-A700 text-xl w-auto"
                size="txtRalewayRomanSemiBold20WhiteA700"
              >
                About us
              </Text>
            </div>
            <div className="flex flex-col items-center justify-center w-auto">
              <Text
                className="text-white-A700 text-xl w-auto"
                size="txtRalewayRomanSemiBold20WhiteA700"
              >
                |
              </Text>
            </div>
            <div className="flex flex-col items-center justify-center w-auto">
              <Text
                className="text-white-A700 text-xl w-auto"
                size="txtRalewayRomanSemiBold20WhiteA700"
              >
                Our Services
              </Text>
            </div>
            <div className="flex flex-col items-center justify-center w-auto">
              <Text
                className="text-white-A700 text-xl w-auto"
                size="txtRalewayRomanSemiBold20WhiteA700"
              >
                |
              </Text>
            </div>
            <div className="flex flex-col items-center justify-center w-auto">
              <Text
                className="text-white-A700 text-xl w-auto"
                size="txtRalewayRomanSemiBold20WhiteA700"
              >
                Contact us
              </Text>
            </div>
          </div>
          <div className="flex flex-row gap-3 items-end justify-center w-auto">
            <Img
              className="h-6 w-6"
              src="images/img_user01.svg"
              alt="userOne"
            />
            <div className="flex flex-col items-center justify-center w-auto">
              <Text
                className="text-white-A700 text-xl w-auto"
                size="txtRalewayRomanSemiBold20WhiteA700"
              >
                |
              </Text>
            </div>
            <Img className="h-6 w-6" src="images/img_cart.svg" alt="cart" />
          </div>
        </div>
        <div className="flex md:flex-col flex-row md:gap-10 items-center justify-between max-w-[1440px] mb-4 md:px-10 sm:px-5 px-[100px] py-0.5 w-full">
          <div className="flex md:flex-col flex-row gap-10 h-[43px] md:h-auto items-center justify-start">
            <div className="flex flex-col items-center justify-start w-auto">
              <div className="flex flex-row gap-5 items-center justify-start py-2.5 w-auto">
                <Text
                  className="text-white-A700 text-xl w-auto"
                  size="txtRalewayRomanSemiBold20WhiteA700"
                >
                  Shop By Category
                </Text>
                <Img
                  className="h-1.5 w-3"
                  src="images/img_arrowdown.svg"
                  alt="arrowdown"
                />
              </div>
            </div>
            <Input
              name="frame115"
              placeholder="Search..."
              value={frame115value}
              onChange={(e) => setFrame115value(e)}
              className="!placeholder:text-white-A700 !text-white-A700 font-raleway font-semibold leading-[normal] p-0 text-base text-left w-full"
              wrapClassName="flex w-[465px] md:w-full"
              suffix={
                frame115value?.length > 0 ? (
                  <CloseSVG
                    className="cursor-pointer h-[18px] ml-[35px] my-px"
                    onClick={() => setFrame115value("")}
                    fillColor="#ffffff"
                    height={18}
                    width={18}
                    viewBox="0 0 18 18"
                  />
                ) : (
                  <Img
                    className="cursor-pointer h-[18px] ml-[35px] my-px"
                    src="images/img_search.svg"
                    alt="search"
                  />
                )
              }
              shape="square"
              color="white_A700_23"
              size="xl"
              variant="fill"
            ></Input>
          </div>
          <div className="flex flex-row gap-3 items-center justify-start w-auto">
            <div className="flex flex-col items-center justify-center w-auto">
              <Text
                className="text-white-A700 text-xl w-auto"
                size="txtRalewayRomanSemiBold20WhiteA700"
              >
                New Arrivals
              </Text>
            </div>
            <div className="flex flex-col items-center justify-center w-auto">
              <Text
                className="text-white-A700 text-xl w-auto"
                size="txtRalewayRomanSemiBold20WhiteA700"
              >
                |
              </Text>
            </div>
            <div className="flex flex-col items-center justify-center w-auto">
              <Text
                className="text-white-A700 text-xl w-auto"
                size="txtRalewayRomanSemiBold20WhiteA700"
              >
                Offers
              </Text>
            </div>
          </div>
        </div>
      </header>
    </>
  );
};

Header1.defaultProps = {};

export default Header1;
