import React from "react";

import { Button, Img, Input, Line, Text } from "components";

import { CloseSVG } from "../../assets/images";

const MyOrdersReviewsProfile = (props) => {
  const [frame456value, setFrame456value] = React.useState("");

  return (
    <>
      <div className={props.className}>
        <div className="flex flex-col gap-7 items-start justify-start w-auto sm:w-full">
          <Input
            name="frame456"
            placeholder="Profile"
            value={frame456value}
            onChange={(e) => setFrame456value(e)}
            className="!placeholder:text-gray-900_02 !text-gray-900_02 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <Img
                className="mt-[3px] mb-px cursor-pointer h-6 mr-3"
                src="images/img_search_gray_900_02.svg"
                alt="search"
              />
            }
            suffix={
              <CloseSVG
                fillColor="#1d1d1f"
                className="cursor-pointer h-6 my-auto"
                onClick={() => setFrame456value("")}
                style={{
                  visibility: frame456value?.length <= 0 ? "hidden" : "visible",
                }}
                height={24}
                width={24}
                viewBox="0 0 24 24"
              />
            }
            shape="square"
            color="white_A700"
            size="lg"
            variant="fill"
          ></Input>
          <Input
            name="frame457"
            placeholder="Company"
            className="!placeholder:text-gray-900_02 !text-gray-900_02 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <Img
                className="mt-px mb-1 h-6 mr-3"
                src="images/img_thumbsup_gray_900_02.svg"
                alt="thumbs_up"
              />
            }
            shape="square"
            color="white_A700"
            size="lg"
            variant="fill"
          ></Input>
          <Input
            name="frame458"
            placeholder="Orders"
            className="!placeholder:text-gray-900_02 !text-gray-900_02 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <div className="h-6 mt-[3px] mb-px mr-3 w-6 outline-gray-900_02 outline-[1px] outline">
                <Img
                  className="h-6 my-auto"
                  src="images/img_bag.svg"
                  alt="bag"
                />
              </div>
            }
            shape="square"
            color="white_A700"
            size="lg"
            variant="fill"
          ></Input>
        </div>
        <div className="bg-white-A700 flex flex-col gap-6 items-start justify-start max-w-[987px] p-6 sm:px-5 rounded-[12px] shadow-bs w-full">
          <div className="flex flex-col items-start justify-start w-full">
            <div className="md:h-[31px] h-[33px] pb-1 relative w-full">
              <div className="absolute border-b border-black-900 border-solid flex-1 h-[31px] inset-[0] m-auto w-full"></div>
              <Text
                className="absolute left-[0] text-2xl md:text-[22px] text-gray-800 sm:text-xl top-[0] w-auto"
                size="txtInterBold24Gray800"
              >
                {props?.addreviewprops}
              </Text>
            </div>
          </div>
          <div className="bg-white-A700 flex flex-col gap-5 h-[198px] md:h-auto items-start justify-start max-w-[939px] sm:px-5 px-6 py-4 shadow-bs1 w-full">
            <div className="flex flex-col gap-2 items-start justify-start w-full">
              <Text
                className="text-black-900 text-center text-xl w-auto"
                size="txtRobotoRomanMedium20Black900"
              >
                {props?.orderdetailsprops}
              </Text>
              <Line className="bg-black-900 h-px w-full" />
            </div>
            <div className="flex md:flex-col flex-row gap-5 items-start justify-start w-auto md:w-full">
              <div className="flex flex-col h-28 md:h-auto items-start justify-start w-[120px]">
                <Img
                  className="md:h-auto h-full object-cover w-full"
                  src="images/img_rectangle1250.png"
                  alt="rectangle1250"
                />
              </div>
              <div className="flex flex-col gap-3 items-start justify-start w-auto">
                <Text
                  className="text-base text-center text-gray-900 w-auto"
                  size="txtRobotoRomanBold16Gray900"
                >
                  {props?.loremipsumdoloroneprops}
                </Text>
                <Text
                  className="text-base text-center text-gray-900 w-auto"
                  size="txtRobotoRomanBold16Gray900"
                >
                  {props?.priceprops}
                </Text>
                <Text
                  className="text-base text-center text-gray-800_ef w-auto"
                  size="txtRobotoRomanMedium16Gray800ef"
                >
                  {props?.languageprops}
                </Text>
                <Text
                  className="text-base text-center text-gray-800_ef w-auto"
                  size="txtRobotoRomanMedium16Gray800ef"
                >
                  {props?.quantity1234props}
                </Text>
              </div>
              <Line className="bg-black-900 h-28 md:h-px md:w-full w-px" />
              <div className="flex flex-col gap-3 items-start justify-start w-auto">
                <Text
                  className="text-base text-center text-gray-800_ef w-auto"
                  size="txtRobotoRomanMedium16Gray800ef"
                >
                  {props?.languageoneprops}
                </Text>
                <Text
                  className="text-base text-center text-gray-800_ef w-auto"
                  size="txtRobotoRomanMedium16Gray800ef"
                >
                  {props?.languagetwoprops}
                </Text>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-2.5 items-start justify-start w-auto">
            {props?.reviewnooneprops}
            <Text
              className="text-2xl md:text-[22px] text-center text-gray-900_01 sm:text-xl w-auto"
              size="txtRobotoRomanSemiBold24Gray90001"
            >
              {props?.loremipsumdolorthreeprops}
            </Text>
          </div>
          <div className="flex sm:flex-col flex-row gap-6 items-center justify-start w-[472px] sm:w-full">
            <Img
              className="h-[121px] md:h-auto object-cover w-[166px] sm:w-full"
              src="images/img_rectangle1245.png"
              alt="rectangle1245"
            />
            <Img
              className="h-[121px] md:h-auto object-cover w-[166px] sm:w-full"
              src="images/img_rectangle1245.png"
              alt="rectangle1244"
            />
            <div className="flex flex-col gap-0.5 items-center justify-start w-auto">
              <Img
                className="h-[58px] w-16"
                src="images/img_user_black_900.svg"
                alt="user"
              />
              <Text
                className="text-base text-black-900 text-center underline w-auto"
                size="txtRobotoRomanRegular16Black900"
              >
                {props?.addimage}
              </Text>
            </div>
          </div>
          <div className="flex flex-col gap-2 items-start justify-start w-full">
            <Text
              className="text-base text-black-900 w-auto"
              size="txtRobotoRomanSemiBold16Black900"
            >
              {props?.articletitleprops}
            </Text>
            <Input
              name="frame506"
              placeholder="Lorem"
              className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
              wrapClassName="border border-black-900_7f border-solid w-full"
              shape="round"
              color="gray_50_03"
              size="xl"
              variant="fill"
            ></Input>
          </div>
          <div className="flex flex-col gap-2 items-start justify-start w-full">
            <Text
              className="text-base text-black-900 w-auto"
              size="txtRobotoRomanSemiBold16Black900"
            >
              {props?.articletextprops}
            </Text>
            <Input
              name="frame507"
              placeholder="Lorem"
              className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] md:h-auto p-0 sm:h-auto text-left text-sm w-full"
              wrapClassName="border border-black-900_7f border-solid w-full"
              shape="round"
              color="gray_50_03"
              size="xl"
              variant="fill"
            ></Input>
          </div>
          <div className="flex flex-col gap-2 items-start justify-start w-full">
            <Text
              className="text-base text-black-900 w-auto"
              size="txtRobotoRomanSemiBold16Black900"
            >
              {props?.selectyourcompanyprops}
            </Text>
            <Input
              name="frame506_One"
              placeholder="Lorem"
              className="!placeholder:text-black-900_cc !text-black-900_cc font-medium font-roboto leading-[normal] p-0 text-left text-sm w-full"
              wrapClassName="border border-black-900_7f border-solid flex md:h-auto w-full"
              suffix={
                <div className="ml-[35px] sm:w-full sm:mx-0 w-[2%] outline-black-900 outline-[1px] outline my-[5px]">
                  <Img
                    className="my-auto"
                    src="images/img_arrowdown_black_900.svg"
                    alt="arrow_down"
                  />
                </div>
              }
              shape="round"
              color="gray_50_03"
              size="xl"
              variant="fill"
            ></Input>
          </div>
          <div className="flex sm:flex-col flex-row gap-10 items-start justify-start w-auto sm:w-full">
            <Button
              className="cursor-pointer font-raleway font-semibold leading-[normal] rounded-[24px] text-2xl md:text-[22px] text-center sm:text-xl w-[207px]"
              color="light_blue_700"
              size="sm"
              variant="outline"
            >
              {props?.cancelbuttonprops}
            </Button>
            <Button
              className="cursor-pointer font-raleway font-semibold leading-[normal] rounded-[24px] text-2xl md:text-[22px] text-center sm:text-xl w-[207px]"
              color="light_blue_700"
              size="sm"
              variant="fill"
            >
              {props?.savebuttonprops}
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

MyOrdersReviewsProfile.defaultProps = {
  addreviewprops: "Add Review",
  orderdetailsprops: "Order Details",
  loremipsumdoloroneprops: "Lorem Ipsum dolor sit amet",
  priceprops: "12,500.00 LKR",
  languageprops: "Order Id :  #1234",
  quantity1234props: "Quantity : 1234",
  languageoneprops: "Order Date :  12th Dec 2023",
  languagetwoprops: "Delivered Date :  12th Dec 2023",
  reviewnooneprops: (
    <Text
      className="text-base text-black-900 text-center w-auto"
      size="txtRobotoRomanRegular16Black900"
    >
      <span className="text-black-900 font-cardo font-normal">Review No</span>
      <span className="text-black-900 font-roboto font-normal"> - </span>
      <span className="text-black-900 font-roboto font-medium">01</span>
    </Text>
  ),
  loremipsumdolorthreeprops: "Lorem ipsum dolor sit amet",
  addimage: "Add Image",
  articletitleprops: "Article Title",
  articletextprops: "Article Text",
  selectyourcompanyprops: "Select Your Company",
  cancelbuttonprops: "Cancel",
  savebuttonprops: "Save",
};

export default MyOrdersReviewsProfile;
