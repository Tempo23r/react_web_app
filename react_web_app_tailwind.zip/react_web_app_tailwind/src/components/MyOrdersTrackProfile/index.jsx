import React from "react";

import { Img, Input, Line, List, Text } from "components";

import { CloseSVG } from "../../assets/images";

const MyOrdersTrackProfile = (props) => {
  const [frame456value, setFrame456value] = React.useState("");

  return (
    <>
      <div className={props.className}>
        <div className="flex flex-col gap-7 items-start justify-start w-auto sm:w-full">
          <Input
            name="frame456"
            placeholder="Profile"
            value={frame456value}
            onChange={(e) => setFrame456value(e)}
            className="!placeholder:text-gray-900_02 !text-gray-900_02 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <Img
                className="mt-[3px] mb-px cursor-pointer h-6 mr-3"
                src="images/img_search_gray_900_02.svg"
                alt="search"
              />
            }
            suffix={
              <CloseSVG
                fillColor="#1d1d1f"
                className="cursor-pointer h-6 my-auto"
                onClick={() => setFrame456value("")}
                style={{
                  visibility: frame456value?.length <= 0 ? "hidden" : "visible",
                }}
                height={24}
                width={24}
                viewBox="0 0 24 24"
              />
            }
            shape="square"
            color="white_A700"
            size="lg"
            variant="fill"
          ></Input>
          <Input
            name="frame457"
            placeholder="Company"
            className="!placeholder:text-gray-900_02 !text-gray-900_02 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <Img
                className="mt-px mb-1 h-6 mr-3"
                src="images/img_thumbsup_gray_900_02.svg"
                alt="thumbs_up"
              />
            }
            shape="square"
            color="white_A700"
            size="lg"
            variant="fill"
          ></Input>
          <Input
            name="frame458"
            placeholder="Orders"
            className="!placeholder:text-light_blue-700 !text-light_blue-700 font-roboto font-semibold leading-[normal] md:text-[22px] p-0 sm:text-xl text-2xl text-left w-full"
            wrapClassName="flex w-full"
            prefix={
              <div className="h-6 mt-[3px] mb-px mr-3 w-6 outline-light_blue-700 outline-[1px] outline">
                <Img
                  className="h-6 my-auto"
                  src="images/img_lock_light_blue_700.svg"
                  alt="lock"
                />
              </div>
            }
            shape="square"
            color="light_blue_400_1e"
            size="lg"
            variant="fill"
          ></Input>
        </div>
        <div className="bg-white-A700 flex flex-col gap-6 h-[1036px] md:h-auto items-center justify-start max-w-[987px] p-6 sm:px-5 rounded-[12px] shadow-bs w-full">
          <div className="flex flex-col items-start justify-start w-full">
            <div className="md:h-8 h-[33px] pb-1 relative w-full">
              <div className="absolute border-b border-black-900 border-solid flex-1 h-8 inset-[0] m-auto w-full"></div>
              <Text
                className="absolute left-[0] text-2xl md:text-[22px] text-gray-800 sm:text-xl top-[0] w-auto"
                size="txtInterBold24Gray800"
              >
                {props?.trackorderprops}
              </Text>
            </div>
          </div>
          <div className="bg-white-A700 flex flex-col gap-7 items-center justify-center w-auto md:w-full">
            <Text
              className="md:text-3xl sm:text-[28px] text-[32px] text-gray-800 w-auto"
              size="txtCardoBold32Gray800"
            >
              {props?.yourorderisprocessingprops}
            </Text>
            <Text
              className="max-w-[863px] md:max-w-full text-center text-gray-900_01 text-xl"
              size="txtRobotoRomanRegular20"
            >
              {props?.descriptionprops}
            </Text>
            <div className="bg-blue_gray-100_01 h-[336px] w-[53%]"></div>
            <div className="flex flex-col gap-[3px] items-center justify-start w-auto md:w-full">
              <div className="flex md:flex-col flex-row gap-[50px] items-center justify-center w-auto md:w-full">
                <Img
                  className="h-9 w-9"
                  src="images/img_close_light_blue_700.svg"
                  alt="close"
                />
                <Line className="bg-black-900 h-px w-[16%]" />
                <div className="bg-light_blue-700_5e h-[30px] rounded-[50%] w-[30px]"></div>
                <Line className="bg-black-900 h-px w-[16%]" />
                <div className="bg-light_blue-700_5e h-[30px] rounded-[50%] w-[30px]"></div>
                <Line className="bg-black-900 h-px w-[16%]" />
                <div className="bg-light_blue-700_5e h-[30px] rounded-[50%] w-[30px]"></div>
              </div>
              <List
                className="sm:flex-col flex-row md:gap-10 grid sm:grid-cols-1 md:grid-cols-2 grid-cols-4 justify-between max-w-[964px] w-full"
                orientation="horizontal"
              >
                <div className="flex flex-1 flex-col items-center justify-end w-full">
                  <Text
                    className="mt-1 text-2xl md:text-[22px] text-black-900 text-center sm:text-xl"
                    size="txtInterBold24"
                  >
                    {props?.paymentpendingprops}
                  </Text>
                </div>
                <div className="flex flex-1 flex-col items-center justify-end w-full">
                  <Text
                    className="mt-[5px] text-2xl md:text-[22px] text-center text-cyan-800 sm:text-xl"
                    size="txtInterRegular24"
                  >
                    {props?.processingprops}
                  </Text>
                </div>
                <div className="flex flex-1 flex-col items-center justify-end w-full">
                  <Text
                    className="mt-1 text-2xl md:text-[22px] text-center text-cyan-800 sm:text-xl"
                    size="txtInterRegular24"
                  >
                    {props?.shippedprops}
                  </Text>
                </div>
                <div className="flex flex-1 flex-col items-center justify-end p-[3px] w-full">
                  <Text
                    className="text-2xl md:text-[22px] text-center text-cyan-800 sm:text-xl"
                    size="txtInterRegular24"
                  >
                    {props?.deliveredprops}
                  </Text>
                </div>
              </List>
            </div>
          </div>
          <div className="flex flex-col items-start justify-start p-1.5 w-full">
            <div className="flex md:flex-col flex-row md:gap-10 items-end justify-between max-w-[818px] mb-[90px] mt-[19px] w-full">
              <div className="bg-white-A700 flex flex-col gap-5 h-[198px] md:h-auto items-start justify-start sm:px-5 px-6 py-4 shadow-bs1 w-auto">
                <Input
                  name="frame521"
                  placeholder="Order Details"
                  className="!placeholder:text-black-900 !text-black-900 font-medium font-roboto leading-[normal] p-0 sm:pr-5 text-center text-xl w-full"
                  wrapClassName="pr-[35px] w-full"
                  color="black_900"
                  size="md"
                  variant="underline"
                ></Input>
                <div className="flex flex-col gap-3 items-start justify-start w-auto">
                  <Text
                    className="text-base text-center text-gray-800_ef w-auto"
                    size="txtRobotoRomanMedium16Gray800ef"
                  >
                    {props?.loremipsumprops}
                  </Text>
                  <Text
                    className="text-base text-center text-gray-800_ef w-auto"
                    size="txtRobotoRomanMedium16Gray800ef"
                  >
                    {props?.orderidprops}
                  </Text>
                  <Text
                    className="text-base text-center text-gray-800_ef w-auto"
                    size="txtRobotoRomanMedium16Gray800ef"
                  >
                    {props?.quantityprops}
                  </Text>
                  <Text
                    className="text-base text-center text-gray-800_ef w-auto"
                    size="txtRobotoRomanMedium16Gray800ef"
                  >
                    {props?.orderdateprops}
                  </Text>
                </div>
              </div>
              <div className="bg-white-A700 flex flex-col gap-5 items-start justify-start sm:px-5 px-6 py-4 shadow-bs1 w-[246px]">
                <div className="flex flex-col gap-5 items-start justify-start w-auto">
                  <Input
                    name="frame523"
                    placeholder="Pick-up Location"
                    className="!placeholder:text-black-900 !text-black-900 font-medium font-roboto leading-[normal] p-0 text-center text-xl w-full"
                    wrapClassName="w-full"
                    color="black_900"
                    size="xs"
                    variant="underline"
                  ></Input>
                  <div className="flex flex-row gap-2 items-start justify-start w-auto">
                    <Img
                      className="h-6 w-6"
                      src="images/img_markerpin01.svg"
                      alt="markerpinOne"
                    />
                    <Text
                      className="max-w-[95px] md:max-w-full text-base text-black-900"
                      size="txtRobotoRomanRegular16Black900"
                    >
                      {props?.addressprops}
                    </Text>
                  </div>
                </div>
                <div className="flex flex-row gap-2 items-center justify-center w-auto">
                  <Img
                    className="h-4 w-4"
                    src="images/img_save.svg"
                    alt="save"
                  />
                  <Text
                    className="text-base text-black-900 text-center underline w-auto"
                    size="txtRobotoRomanRegular16Black900"
                  >
                    {props?.viewonmapprops}
                  </Text>
                </div>
              </div>
              <div className="bg-white-A700 flex flex-col gap-5 h-[195px] md:h-auto items-start justify-start sm:px-5 px-6 py-4 shadow-bs1 w-[246px]">
                <Input
                  name="frame522"
                  placeholder="Pick-up 
Date & Time Est."
                  className="!placeholder:text-black-900 !text-black-900 font-medium font-roboto leading-[normal] p-0 sm:pr-5 text-left text-xl w-full"
                  wrapClassName="max-w-[198px] pr-[35px]"
                  color="black_900"
                  size="md"
                  variant="underline"
                ></Input>
                <div className="flex flex-row gap-2 items-center justify-start w-auto">
                  <Img
                    className="h-6 w-6"
                    src="images/img_clock_black_900.svg"
                    alt="clock"
                  />
                  <Text
                    className="text-base text-black-900 w-auto"
                    size="txtRobotoRomanRegular16Black900"
                  >
                    {props?.timeprops}
                  </Text>
                </div>
                <div className="flex flex-row gap-2 items-center justify-center w-auto">
                  <Img
                    className="h-6 w-6"
                    src="images/img_bag_black_900.svg"
                    alt="bag"
                  />
                  <Text
                    className="text-base text-black-900 w-auto"
                    size="txtRobotoRomanRegular16Black900"
                  >
                    {props?.deliverydateprops}
                  </Text>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

MyOrdersTrackProfile.defaultProps = {
  trackorderprops: "Track Order",
  yourorderisprocessingprops: "Your Order Is Processing",
  descriptionprops:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
  paymentpendingprops: "Payment Pending",
  processingprops: "Processing",
  shippedprops: "Shipped",
  deliveredprops: "Delivered",
  loremipsumprops: "Lorem Ipsum",
  orderidprops: "Order Id :  #1234",
  quantityprops: "Quantity : 12",
  orderdateprops: "Order Date :  12th Dec 2023",
  addressprops: (
    <>
      No. 141/A,
      <br />
      ABC Road,
      <br />
      Lorem Street,
      <br />
      Lorem.
    </>
  ),
  viewonmapprops: "View on Map",
  timeprops: "12.30 pm",
  deliverydateprops: "21st December 2023.",
};

export default MyOrdersTrackProfile;
