import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "pages/Home";
import NotFound from "pages/NotFound";
const Frame505 = React.lazy(() => import("pages/Frame505"));
const Myordersreviews = React.lazy(() => import("pages/Myordersreviews"));
const Singleproductspecifications = React.lazy(
  () => import("pages/Singleproductspecifications"),
);
const Myorderstrack = React.lazy(() => import("pages/Myorderstrack"));
const Addcompany = React.lazy(() => import("pages/Addcompany"));
const Wishlist = React.lazy(() => import("pages/Wishlist"));
const Cart = React.lazy(() => import("pages/Cart"));
const Termsandconditions = React.lazy(() => import("pages/Termsandconditions"));
const Aboutus = React.lazy(() => import("pages/Aboutus"));
const Myorders = React.lazy(() => import("pages/Myorders"));
const Mycompanies = React.lazy(() => import("pages/Mycompanies"));
const Myprofile = React.lazy(() => import("pages/Myprofile"));
const Orderfailed = React.lazy(() => import("pages/Orderfailed"));
const Ordersuccess = React.lazy(() => import("pages/Ordersuccess"));
const Testimonial = React.lazy(() => import("pages/Testimonial"));
const Ourservices = React.lazy(() => import("pages/Ourservices"));
const Contactus = React.lazy(() => import("pages/Contactus"));
const Singleproduct = React.lazy(() => import("pages/Singleproduct"));
const Shopwobanner = React.lazy(() => import("pages/Shopwobanner"));
const Shopwbanner = React.lazy(() => import("pages/Shopwbanner"));
const Home1 = React.lazy(() => import("pages/Home1"));
const ProjectRoutes = () => {
  return (
    <React.Suspense fallback={<>Loading...</>}>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="*" element={<NotFound />} />
          <Route path="/home1" element={<Home1 />} />
          <Route path="/shopwbanner" element={<Shopwbanner />} />
          <Route path="/shopwobanner" element={<Shopwobanner />} />
          <Route path="/singleproduct" element={<Singleproduct />} />
          <Route path="/contactus" element={<Contactus />} />
          <Route path="/ourservices" element={<Ourservices />} />
          <Route path="/testimonial" element={<Testimonial />} />
          <Route path="/ordersuccess" element={<Ordersuccess />} />
          <Route path="/orderfailed" element={<Orderfailed />} />
          <Route path="/myprofile" element={<Myprofile />} />
          <Route path="/mycompanies" element={<Mycompanies />} />
          <Route path="/myorders" element={<Myorders />} />
          <Route path="/aboutus" element={<Aboutus />} />
          <Route path="/termsandconditions" element={<Termsandconditions />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/wishlist" element={<Wishlist />} />
          <Route path="/addcompany" element={<Addcompany />} />
          <Route path="/myorderstrack" element={<Myorderstrack />} />
          <Route
            path="/singleproductspecifications"
            element={<Singleproductspecifications />}
          />
          <Route path="/myordersreviews" element={<Myordersreviews />} />
          <Route path="/frame505" element={<Frame505 />} />
        </Routes>
      </Router>
    </React.Suspense>
  );
};
export default ProjectRoutes;
