import React from "react";

import { Button, Img, Input, Line, List, Text } from "components";
import Footer from "components/Footer";
import Header1 from "components/Header1";

import { CloseSVG } from "../../assets/images";

const WishlistPage = () => {
  const [frame115value, setFrame115value] = React.useState("");

  return (
    <>
      <div className="bg-white-A700 flex flex-col font-inter items-start justify-start mx-auto w-full">
        <div className="flex flex-col items-center w-full">
          <div
            className="bg-cover bg-no-repeat flex flex-col h-[800px] items-center justify-start pb-[181px] w-full"
            style={{ backgroundImage: "url('images/img_frame188.png')" }}
          >
            <Header1 className="flex flex-col font-cardo items-center justify-center md:px-5 w-full" />
            <div className="font-raleway h-[154px] mt-[177px] md:px-5 relative w-[56%] md:w-full">
              <div className="flex flex-col font-cardo items-center justify-center mb-[-16.21px] mx-auto w-auto z-[1]">
                <Text
                  className="md:text-5xl text-7xl text-center text-white-A700 tracking-[2.16px] uppercase w-auto"
                  size="txtCardoBold72"
                >
                  Wishlist
                </Text>
              </div>
              <div className="flex flex-col gap-3.5 items-center justify-start mt-auto mx-auto md:px-10 sm:px-5 px-[63px] w-full">
                <a
                  href="www.modernoffice.online"
                  className="text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl"
                  target="_blank"
                  rel="noreferrer"
                >
                  <Text size="txtRalewayRomanBold24">
                    www.modernoffice.online
                  </Text>
                </a>
                <Text
                  className="capitalize text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl"
                  size="txtRalewayRomanMedium24"
                >
                  Largest and Best online office automation store in sri lanka
                </Text>
              </div>
            </div>
            <Button
              className="cursor-pointer flex items-center justify-center min-w-[214px] mt-[67px] rounded-[21px]"
              leftIcon={
                <Img
                  className="h-6 mt-px mb-1 mr-3"
                  src="images/img_thumbsup.svg"
                  alt="thumbs_up"
                />
              }
              color="white_A700"
              size="md"
              variant="fill"
            >
              <div className="font-bold font-raleway leading-[normal] md:text-[22px] sm:text-xl text-2xl text-center">
                Shop Now
              </div>
            </Button>
          </div>
          <div className="flex flex-col gap-3 items-start justify-center max-w-[1440px] md:px-10 sm:px-5 px-[100px] py-5 w-full">
            <Text
              className="text-2xl md:text-[22px] text-black-900 sm:text-xl w-auto"
              size="txtInterBold24"
            >
              WishList
            </Text>
            <Line className="bg-black-900 h-px max-w-[1240px] mx-auto w-full" />
          </div>
        </div>
        <div className="flex md:flex-col flex-row font-roboto md:gap-10 gap-[90px] items-start justify-center max-w-[1179px] mt-[11px] mx-auto md:px-5 w-full">
          <List
            className="flex flex-col gap-[34px] items-start w-auto"
            orientation="vertical"
          >
            <div className="bg-white-A700 border-b border-black-900_33 border-solid flex md:flex-col flex-row gap-2.5 items-center justify-start max-w-[771px] my-0 pb-[15px] pt-3 px-2 w-full">
              <Img
                className="sm:flex-1 md:h-auto h-full object-cover w-[150px] sm:w-full"
                src="images/img_rectangle1244.png"
                alt="rectangle1244"
              />
              <div className="flex md:flex-1 flex-col gap-[22px] items-start justify-start w-[603px] md:w-full">
                <div className="flex flex-col gap-[15px] items-start justify-start w-full">
                  <Text
                    className="text-center text-gray-800_04 text-xl w-auto"
                    size="txtRobotoRomanMedium20Gray80004"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                  <Text
                    className="text-black-900 text-center text-xl w-auto"
                    size="txtRobotoRomanBold20Black900"
                  >
                    12,500.00 LKR
                  </Text>
                </div>
                <Text
                  className="text-base text-center text-gray-800_04 w-auto"
                  size="txtRobotoRomanRegular16Gray80004"
                >
                  *Lorem ipsum dolor sit amet
                </Text>
                <div className="flex flex-row gap-[22px] items-start justify-start w-auto">
                  <Button
                    className="cursor-pointer flex items-center justify-center min-w-[140px] outline-[1px] rounded"
                    leftIcon={
                      <Img
                        className="h-6 mr-2.5"
                        src="images/img_cart_light_blue_700.svg"
                        alt="cart"
                      />
                    }
                    color="light_blue_700"
                    size="sm"
                    variant="outline"
                  >
                    <div className="font-bold leading-[normal] text-base text-center">
                      Add to Cart
                    </div>
                  </Button>
                  <div className="border border-gray-800 border-solid flex flex-col h-10 md:h-auto items-center justify-center p-2 rounded w-auto">
                    <Img
                      className="h-[19px] w-[19px]"
                      src="images/img_trash01.svg"
                      alt="trashOne"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-white-A700 border-b border-black-900_33 border-solid flex md:flex-col flex-row gap-2.5 items-center justify-start max-w-[771px] my-0 pb-[15px] pt-3 px-2 w-full">
              <Img
                className="sm:flex-1 md:h-auto h-full object-cover w-[150px] sm:w-full"
                src="images/img_rectangle1244.png"
                alt="rectangle1244"
              />
              <div className="flex md:flex-1 flex-col gap-[22px] items-start justify-start w-[603px] md:w-full">
                <div className="flex flex-col gap-[15px] items-start justify-start w-full">
                  <Text
                    className="text-center text-gray-800_04 text-xl w-auto"
                    size="txtRobotoRomanMedium20Gray80004"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                  <Text
                    className="text-black-900 text-center text-xl w-auto"
                    size="txtRobotoRomanBold20Black900"
                  >
                    12,500.00 LKR
                  </Text>
                </div>
                <Text
                  className="text-base text-center text-gray-800_04 w-auto"
                  size="txtRobotoRomanRegular16Gray80004"
                >
                  *Lorem ipsum dolor sit amet
                </Text>
                <div className="flex flex-row gap-[22px] items-start justify-start w-auto">
                  <Button
                    className="cursor-pointer flex items-center justify-center min-w-[140px] outline-[1px] rounded"
                    leftIcon={
                      <Img
                        className="h-6 mr-2.5"
                        src="images/img_cart_light_blue_700.svg"
                        alt="cart"
                      />
                    }
                    color="light_blue_700"
                    size="sm"
                    variant="outline"
                  >
                    <div className="font-bold leading-[normal] text-base text-center">
                      Add to Cart
                    </div>
                  </Button>
                  <div className="border border-gray-800 border-solid flex flex-col h-10 md:h-auto items-center justify-center p-2 rounded w-auto">
                    <Img
                      className="h-[19px] w-[19px]"
                      src="images/img_trash01.svg"
                      alt="trashOne"
                    />
                  </div>
                </div>
              </div>
            </div>
          </List>
          <div className="bg-gray-100_02 flex flex-col items-center justify-center p-4 w-auto">
            <div className="flex flex-col gap-5 items-start justify-start w-full">
              <div className="flex flex-col gap-5 items-start justify-start w-full">
                <div className="flex flex-row items-center justify-between w-full">
                  <Text
                    className="text-base text-black-900 w-auto"
                    size="txtRobotoRomanRegular16Black900"
                  >
                    Cat_name
                  </Text>
                  <Text
                    className="text-base text-black-900 text-right w-auto"
                    size="txtRobotoRomanMedium16Black900"
                  >
                    *count
                  </Text>
                </div>
                <div className="flex flex-row items-center justify-between w-full">
                  <Text
                    className="text-base text-black-900 w-auto"
                    size="txtRobotoRomanRegular16Black900"
                  >
                    Cat_name
                  </Text>
                  <Text
                    className="text-base text-black-900 text-right w-auto"
                    size="txtRobotoRomanMedium16Black900"
                  >
                    2
                  </Text>
                </div>
                <div className="flex flex-row items-center justify-between w-full">
                  <Text
                    className="text-base text-black-900 w-auto"
                    size="txtRobotoRomanRegular16Black900"
                  >
                    cat_name
                  </Text>
                  <Text
                    className="text-base text-black-900 text-right w-auto"
                    size="txtRobotoRomanMedium16Black900"
                  >
                    3
                  </Text>
                </div>
              </div>
              <div className="flex flex-col gap-4 items-start justify-start w-full">
                <div className="border-black-900_33 border-solid border-t flex flex-row items-start justify-between pt-5 w-full">
                  <Text
                    className="text-base text-black-900 w-auto"
                    size="txtRobotoRomanMedium16Black900"
                  >
                    Total Items
                  </Text>
                  <Text
                    className="text-base text-black-900 text-right w-auto"
                    size="txtRobotoRomanBold16"
                  >
                    5
                  </Text>
                </div>
                <Button
                  className="border border-solid border-white-A700 capitalize cursor-pointer font-bold leading-[normal] rounded text-base text-center w-full"
                  color="light_blue_700"
                  size="md"
                  variant="fill"
                >
                  Add All Items to cart
                </Button>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col font-raleway items-center mt-[51px] w-full">
          <Footer className="bg-white-A700 border-gray-400_01 border-solid border-t flex gap-5 items-center justify-center md:px-5 px-[100px] py-10 w-full" />
        </div>
      </div>
    </>
  );
};

export default WishlistPage;
