import React from "react";

import { createColumnHelper } from "@tanstack/react-table";

import { Button, Img, Input, ReactTable, Text } from "components";
import Footer from "components/Footer";
import Header from "components/Header";
import MyCompaniesProfile from "components/MyCompaniesProfile";


const MycompaniesPage = () => {
  const tableData = React.useRef([
    {
      rowcompany: "Company Id - 01235",
      rowemail: "4",
      rowtelephone: "12/10/2023",
      rowframe400: "No. 101/A, Abc Road, Abc 001, ABC",
    },
    {
      rowcompany: "Lorem ipsum dolor",
      rowemail: "4",
      rowtelephone: "12/10/2023",
      rowframe400: "2",
    },
    {
      rowcompany: "Company Id - 01235",
      rowemail: "4",
      rowtelephone: "12/10/2023",
      rowframe400: "2",
    },
    {
      rowcompany: "Lorem ipsum dolor",
      rowemail: "4",
      rowtelephone: "12/10/2023",
      rowframe400: "2",
    },
  ]);
  const tableColumns = React.useMemo(() => {
    const tableColumnHelper = createColumnHelper();
    return [
      tableColumnHelper.accessor("rowcompany", {
        cell: (info) => (
          <Text className="pl-[18px] pt-[13px] text-base text-black-900 text-center">
            {info?.getValue()}
          </Text>
        ),
        header: (info) => (
          <div className="flex flex-row items-center justify-center min-w-[290px]">
            <Button className="bg-light_blue-700 cursor-pointer font-bold leading-[normal] min-w-[289px] py-[11px] text-center text-white-A700 text-xl">
              Company
            </Button>
          </div>
        ),
      }),
      tableColumnHelper.accessor("rowemail", {
        cell: (info) => (
          <Text className="font-medium md:mt-0 mt-[68px] pb-[35px] pt-[-151px] text-black-900 text-right text-xl">
            {info?.getValue()}
          </Text>
        ),
        header: (info) => (
          <div className="flex flex-row items-center justify-end min-w-[130px]">
            <Button className="cursor-pointer font-bold leading-[normal] min-w-[130px] py-[11px] text-center text-white-A700 text-xl">
              Email
            </Button>
          </div>
        ),
      }),
      tableColumnHelper.accessor("rowtelephone", {
        cell: (info) => (
          <Text className="md:mt-0 mt-[68px] pb-[35px] pt-[-151px] text-black-900 text-center text-xl">
            {info?.getValue()}
          </Text>
        ),
        header: (info) => (
          <div className="flex flex-row items-center justify-center min-w-[169px]">
            <Button className="cursor-pointer font-bold leading-[normal] min-w-[169px] py-[11px] text-center text-white-A700 text-xl">
              Telephone
            </Button>
          </div>
        ),
      }),
      tableColumnHelper.accessor("rowframe400", {
        cell: (info) => (
          <Text className="flex-1 pb-8 pl-1 pt-[-51px] text-black-900 text-xl w-full">
            {info?.getValue()}
          </Text>
        ),
        header: (info) => (
          <div className="flex flex-row items-center justify-start min-w-[350px]">
            <Text className="font-bold px-[3px] py-[11px] text-center text-white-A700 text-xl">
              Address ( Main Branch )
            </Text>
            <Button className="cursor-pointer font-bold leading-[normal] min-w-[123px] py-[11px] text-center text-white-A700 text-xl">
              Branches
            </Button>
          </div>
        ),
      }),
    ];
  }, []);

  const [frame115value, setFrame115value] = React.useState("");
  const [frame456value, setFrame456value] = React.useState("");

  return (
    <>
      <div className="bg-gray-100_01 flex flex-col items-start justify-start mx-auto w-full">
        <div className="flex flex-col font-raleway items-center w-full">
          <Header className="bg-gray-50_01 flex md:flex-col md:gap-5 items-center justify-center md:px-5 shadow-bs5 w-full" />
        </div>
        <Text
          className="md:ml-[0] ml-[100px] mt-[50px] md:text-5xl text-7xl text-gray-800"
          size="txtCardoBold72Gray800"
        >
          <span className="text-gray-800 font-inter text-left text-xl font-medium">
            Modern Office Automation /{" "}
          </span>
          <span className="text-light_blue-700 font-inter text-left text-xl font-medium">
            <>
              My Companies
              <br />
            </>
          </span>
          <span className="text-gray-800 font-inter text-left font-bold">
            My{" "}
          </span>
          <span className="text-gray-800 font-inter text-left font-bold">
            Company
          </span>
        </Text>
        <div className="flex flex-col font-roboto md:gap-10 gap-16 items-center mt-2.5 w-full">
          <MyCompaniesProfile
            className="bg-gray-100_01 flex md:flex-col flex-row md:gap-10 h-[546px] md:h-auto items-start justify-between max-w-[1440px] md:px-10 sm:px-5 px-[100px] py-10 w-full"
            companyidtext={
              <Text className="pl-[18px] pt-[13px] text-base text-black-900 text-center">
                <span className="text-black-900 font-inter font-normal">
                  Company Id -{" "}
                </span>
                <span className="text-black-900 font-inter font-medium">
                  01235
                </span>
              </Text>
            }
            companyidtext1={
              <Text className="pb-[-11px] pl-[18px] pt-[21px] text-base text-black-900 text-center">
                <span className="text-black-900 font-inter font-normal">
                  Company Id -{" "}
                </span>
                <span className="text-black-900 font-inter font-medium">
                  01235
                </span>
              </Text>
            }
          />
          <Footer className="bg-white-A700 flex font-raleway gap-5 items-center justify-center outline outline-gray-400_01 md:px-5 px-[100px] py-10 w-full" />
        </div>
      </div>
    </>
  );
};

export default MycompaniesPage;
