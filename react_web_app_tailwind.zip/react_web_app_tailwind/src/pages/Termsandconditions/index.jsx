import React from "react";

import { Button, Img, Input, Text } from "components";
import Footer from "components/Footer";
import Header1 from "components/Header1";


const TermsandconditionsPage = () => {
  const [frame115value, setFrame115value] = React.useState("");

  return (
    <>
      <div className="bg-white-A700 flex flex-col font-cardo items-center justify-start mx-auto w-full">
        <div
          className="bg-cover bg-no-repeat flex flex-col h-[800px] items-center justify-start pb-[181px] w-full"
          style={{ backgroundImage: "url('images/img_frame188.png')" }}
        >
          <Header1 className="flex flex-col font-cardo items-center justify-center md:px-5 w-full" />
          <div className="flex flex-col font-cardo items-center justify-center max-w-[1036px] mt-[148px] mx-auto md:px-5 w-full">
            <Text
              className="md:text-5xl text-7xl text-center text-white-A700 tracking-[2.16px] uppercase w-auto"
              size="txtCardoBold70"
            >
              terms and conditions
            </Text>
          </div>
          <a
            href="www.modernoffice.online"
            className="mt-4 text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl"
            target="_blank"
            rel="noreferrer"
          >
            <Text size="txtRalewayRomanBold24">www.modernoffice.online</Text>
          </a>
          <Text
            className="capitalize mt-3.5 text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl"
            size="txtRalewayRomanMedium24"
          >
            Largest and Best online office automation store in sri lanka
          </Text>
          <Button
            className="cursor-pointer flex items-center justify-center min-w-[214px] mt-[63px] rounded-[21px]"
            leftIcon={
              <Img
                className="h-6 mt-px mb-1 mr-3"
                src="images/img_thumbsup.svg"
                alt="thumbs_up"
              />
            }
            color="white_A700"
            size="md"
            variant="fill"
          >
            <div className="font-bold font-raleway leading-[normal] md:text-[22px] sm:text-xl text-2xl text-center">
              Shop Now
            </div>
          </Button>
        </div>
        <div className="bg-gray-100 flex flex-col items-center justify-start max-w-[1439px] pb-[30px] pt-[60px] md:px-10 sm:px-5 px-[100px] w-full">
          <div className="flex flex-col items-start justify-start max-w-[1233px] mx-auto w-full">
            <div className="flex flex-col gap-2 items-start justify-start w-full">
            <Text 
                className="md:text-xl text-gray-830 w-max inset-x-[0]"
                size="txtCardoBold20"
              >
                <>
                Modern Office Automation
                </>
              </Text>
              <Text
                className="md:text-5xl text-7xl text-gray-800"
                size="txtCardoBold72Gray800"
              >
                <>
                  Terms and Conditions
                </>
              </Text>
              <div className="relative w-full">
                <div className="absolute bottom-[1%] flex flex-col justify-start right-[1%] w-[154px]">
                  <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                  <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                  <div className="bg-light_blue-700 h-[15px] mr-[139px] mt-[71px] rounded-[3px] w-[15px]"></div>
                </div>
                <div className="flex flex-col items-center justify-start max-w-[1233px] mx-auto pb-5 relative w-full">
                  <Text
                    className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                    size="txtCardoRegular24Gray80001"
                  >
                    <span className="text-gray-800_01 font-cardo text-left font-normal">
                      {" "}
                      Welcome to{" "}
                    </span>
                    <a
                      href="javascript:"
                      className="text-gray-800_01 font-cardo text-left font-normal underline"
                    >
                      www.modernoffice.online
                    </a>
                    <span className="text-gray-800_01 font-cardo text-left font-normal">
                      , the online purchasing gateway for Modern Office
                      Automation (Pvt) Ltd (Sri Lanka). The{" "}
                    </span>
                    <a
                      href="javascript:"
                      className="text-gray-800_01 font-cardo text-left font-normal underline"
                    >
                      www.modernoffice.online
                    </a>
                    <span className="text-gray-800_01 font-cardo text-left font-normal">
                      {" "}
                      provides services to its valued customers subject to the
                      following conditions. Please read and accept the under
                      mentioned conditions and guidelines carefully before you
                      use the services of the website
                    </span>
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start max-w-[1233px] mt-auto mx-auto pb-5 relative w-full">
                  <a
                    href="www.modernoffice.online"
                    className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-auto"
                    target="_blank"
                    rel="noreferrer"
                  >
                    <Text size="txtCardoRegular24Gray80001">
                      <span className="text-gray-800_01 font-cardo text-left font-normal">
                        Product information at{" "}
                      </span>
                      <a
                        href="javascript:"
                        className="text-gray-800_01 font-cardo text-left font-normal underline"
                      >
                        www.modernoffice.online
                      </a>
                      <span className="text-gray-800_01 font-cardo text-left font-normal">
                        {" "}
                        web site
                      </span>
                    </Text>
                  </a>
                </div>
              </div>
              <div className="flex flex-col items-start justify-start pb-5 w-full">
                <Text
                  className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                  size="txtCardoRegular24Gray80001"
                >
                  <span className="text-gray-800_01 font-cardo text-left font-normal">
                    {" "}
                    The{" "}
                  </span>
                  <a
                    href="javascript:"
                    className="text-gray-800_01 font-cardo text-left font-normal underline"
                  >
                    www.modernoffice.online
                  </a>
                  <span className="text-gray-800_01 font-cardo text-left font-normal">
                    {" "}
                    attempts to be as accurate as possible of information
                    displayed in the site. However,{" "}
                  </span>
                  <a
                    href="javascript:"
                    className="text-gray-800_01 font-cardo text-left font-normal underline"
                  >
                    www.modernoffice.online
                  </a>
                  <span className="text-gray-800_01 font-cardo text-left font-normal">
                    {" "}
                    does not guarantee that product descriptions or other
                    contents of this site are 100% accurate, complete, reliable
                    or completely free of errors. If a product offered by{" "}
                  </span>
                  <a
                    href="javascript:"
                    className="text-gray-800_01 font-cardo text-left font-normal underline"
                  >
                    www.modernoffice.online
                  </a>
                  <span className="text-gray-800_01 font-cardo text-left font-normal">
                    {" "}
                    is not as described on its website, a customer’s sole remedy
                    is to return it in unused condition within two days of
                    delivery. If there is any external damage to the package,
                    you should check it when the item is handed over. Any item
                    will not be accepted due to any external damages to the item
                    with package damages or dents and only for internal
                    technical in built fault. In case, the received item has
                    been defective, you should immediately be informed within
                    24Hrs in order to arrange replacement with a brand new unit.
                  </span>
                </Text>
              </div>
              <div className="flex flex-col items-start justify-start pb-5 w-full">
                <Text
                  className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                  size="txtCardoRegular24Gray80001"
                >
                  <span className="text-gray-800_01 font-cardo text-left font-normal">
                    {" "}
                    Regarding the items sold through{" "}
                  </span>
                  <a
                    href="javascript:"
                    className="text-gray-800_01 font-cardo text-left font-normal underline"
                  >
                    www.modernoffice.online
                  </a>
                  <span className="text-gray-800_01 font-cardo text-left font-normal">
                    , customer will able to negotiate about the price with us
                    &we also pay attention for your ideas until confirmed the
                    price of an item. After your confirmation of purchasing, if
                    the new price is higher than the mentioned price, we will
                    not cancel or deliver the item without your confirmation
                    about the new price, and all cancellation of items will be
                    informed.
                  </span>
                </Text>
              </div>
              <div className="flex flex-col items-start justify-start pb-5 w-full">
                <Text
                  className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                  size="txtCardoRegular24Gray80001"
                >
                  <span className="text-gray-800_01 font-cardo text-left font-normal">
                    {" "}
                    Even if delivery of the selected item is cancelled,{" "}
                  </span>
                  <a
                    href="javascript:"
                    className="text-gray-800_01 font-cardo text-left font-normal underline"
                  >
                    www.modernoffice.online
                  </a>
                  <span className="text-gray-800_01 font-cardo text-left font-normal">
                    {" "}
                    will not transfer your money back and you can buy any other
                    available product up to the value of the previous item. Any
                    item damaged during delivery, and if we do not have stocks
                    from the same item/model to arrange a replacement, the
                    particular amount will be refunded.
                  </span>
                </Text>
              </div>
              <div className="border-b-2 border-gray-800 border-solid flex flex-col items-start justify-start pb-[35px] w-full">
                <Text
                  className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                  size="txtCardoRegular24Gray80001"
                >
                  <span className="text-gray-800_01 font-cardo text-left font-normal">
                    {" "}
                    All refunds will be processed within one week. Processing
                    refunds back to your credit card/ bank account may require
                    additional time depending on the bank due to its own
                    operational time for which{" "}
                  </span>
                  <a
                    href="javascript:"
                    className="text-gray-800_01 font-cardo text-left font-normal underline"
                  >
                    www.modernoffice.online
                  </a>
                  <span className="text-gray-800_01 font-cardo text-left font-normal">
                    {" "}
                    will not be responsible.
                  </span>
                </Text>
              </div>
            </div>
          </div>
        </div>


        <div className="flex flex-col text-black md:px-5 relative w-full">
          <div className="md:h-[338px] h-[356px] mx-auto md:px-10 sm:px-5 px-[100px] py-[30px] w-[1439px] md:w-full">
            <div className="absolute bg-gray-50 h-[249px] inset-x-[0] mx-auto top-[0] w-full"></div>
            <div className="absolute bottom-[0] flex flex-col inset-x-[0] items-center justify-start max-w-[1233px] mx-auto w-full">
              <div className="flex flex-col gap-2 items-start justify-start w-full">
                <Text
                  className="md:text-5xl text-7xl text-gray-800"
                  size="txtCardoBold72Gray800"
                >
                  <span className="text-gray-800 font-cardo text-left text-xl font-bold">
                    <>
                      Modern Office Automation
                      <br />
                    </>
                  </span>
                  <span className="md:text-[34px] sm:text-[32px] text-gray-800 font-cardo text-left text-4xl font-bold">
                    Product Pricing
                  </span>
                </Text>
                <div className="border-b-2 border-gray-800 border-solid flex flex-col items-start justify-start pb-[35px] w-full">
                  <Text
                    className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                    size="txtCardoRegular24Gray80001"
                  >
                    <span className="text-gray-800_01 font-cardo text-left font-normal">
                      The price for all the items mentioned at{" "}
                    </span>
                    <a
                      href="javascript:"
                      className="text-gray-800_01 font-cardo text-left font-normal underline"
                    >
                      www.modernoffice.online
                    </a>
                    <span className="text-gray-800_01 font-cardo text-left font-normal">
                      . Is the final and last price of sale via online
                      Additional amount of will be charged for each and every
                      delivery when the particular invoice value is below 50,000
                      LKR.
                    </span>
                  </Text>
                </div>
                <div className="flex flex-col justify-start w-[13%] md:w-full">
                  <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                  <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                  <div className="bg-light_blue-700 h-px mr-[139px] mt-[71px] w-[10%]"></div>
                </div>
              </div>
            </div>
          </div>





          <div className="bg-gray-50 flex flex-col items-center justify-end max-w-[1439px] mt-[-107px] mx-auto md:px-10 sm:px-5 px-[100px] py-[30px] w-full z-[1]">
            <div className="flex flex-col items-start justify-start max-w-[1233px] w-full">
              <div className="flex flex-col gap-2 items-start justify-start w-full">
                <Text
                  className="md:text-5xl text-7xl text-gray-800"
                  size="txtCardoBold72Gray800"
                >
                  <span className="text-gray-800 font-cardo text-left text-xl font-bold">
                    <>
                      Modern Office Automation
                      <br />
                    </>
                  </span>
                  <span className="md:text-[34px] sm:text-[32px] text-gray-800 font-cardo text-left text-4xl font-bold">
                    Using accounts
                  </span>
                </Text>
                <div className="relative w-full">
                  <div className="absolute bottom-[0] flex flex-col justify-start right-[1%] w-[154px]">
                    <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                    <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                    <div className="bg-light_blue-700 h-[15px] mr-[139px] mt-[71px] rounded-[3px] w-[15px]"></div>
                  </div>
                  <div className="border-b-2 border-gray-800 border-solid flex flex-col items-center justify-start m-auto max-w-[1233px] pb-[35px] relative w-full">
                    <Text
                      className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                      size="txtCardoRegular24Gray80001"
                    >
                      <span className="text-gray-800_01 font-cardo text-left font-normal">
                        It’s a responsibility of users of this site to keep
                        their passwords and other account information about{" "}
                      </span>
                      <a
                        href="javascript:"
                        className="text-gray-800_01 font-cardo text-left font-normal underline"
                      >
                        www.modernoffice.online
                      </a>
                      <span className="text-gray-800_01 font-cardo text-left font-normal">
                        , and the computer used to log on confidentially. You
                        are solely responsible for all the activities done via
                        your{" "}
                      </span>
                      <a
                        href="javascript:"
                        className="text-gray-800_01 font-cardo text-left font-normal underline"
                      >
                        www.modernoffice.online
                      </a>
                      <span className="text-gray-800_01 font-cardo text-left font-normal">
                        <>
                          {" "}
                          account or the password.
                          <br />
                          <br />
                          Who can buy through{" "}
                        </>
                      </span>
                      <a
                        href="javascript:"
                        className="text-gray-800_01 font-cardo text-left font-normal underline"
                      >
                        www.modernoffice.online
                      </a>
                      <span className="text-gray-800_01 font-cardo text-left font-normal">
                        <>
                          ?<br />
                          The{" "}
                        </>
                      </span>
                      <a
                        href="javascript:"
                        className="text-gray-800_01 font-cardo text-left font-normal underline"
                      >
                        www.modernoffice.online
                      </a>
                      <span className="text-gray-800_01 font-cardo text-left font-normal">
                        {" "}
                        can be used by anyone with a valid credit card with the
                        payment limit sufficient enough to buy the appropriate
                        item and to buy any product available in the site.
                      </span>
                    </Text>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>





        
        <div className="bg-gray-100 flex flex-col items-center justify-start max-w-[1439px] md:px-10 sm:px-5 px-[100px] py-[30px] w-full">
          <div className="flex flex-col items-start justify-start max-w-[1233px] mx-auto w-full">
            <div className="flex flex-col gap-2 items-start justify-start w-full">
              <Text
                className="md:text-5xl text-7xl text-gray-800"
                size="txtCardoBold72Gray800"
              >
                <span className="text-gray-800 font-cardo text-left text-xl font-bold">
                  <>
                    Modern Office Automation
                    <br />
                  </>
                </span>
                <span className="md:text-[34px] sm:text-[32px] text-gray-800 font-cardo text-left text-4xl font-bold">
                  W
                </span>
                <span className="md:text-[34px] sm:text-[32px] text-gray-800 font-cardo lowercase text-left text-4xl font-bold">
                  ARRANTY
                </span>
              </Text>
              <div className="relative w-full">
                <div className="absolute bottom-[10%] flex flex-col justify-start right-[1%] w-[154px]">
                  <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                  <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                  <div className="bg-light_blue-700 h-[15px] mr-[139px] mt-[71px] rounded-[3px] w-[15px]"></div>
                </div>
                <Text
                  className="mx-auto relative text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-full"
                  size="txtCardoRegular24Gray80001"
                >
                  Modern Office Automation Warranty Section provides a customer
                  friendly service assuring the customer gets a fair experience.
                  We always try to save both your time and assets by providing a
                  fast and a reliable service. Since most of our suppliers are
                  located in the country itself, we can provide a faster
                  service. Our warranty service will be under the following
                  conditions.
                </Text>
                </div>
                </div>

                <br></br>
                <div className="flex flex-col gap-3 items-start justify-start mb-[70px] mt-auto relative">
                  <Text
                    className="text-4xl sm:text-[32px] md:text-[34px] text-gray-800_01 w-full"
                    size="txtCardoBold36Gray80001"
                  >
                    Conditions
                  </Text>

                <Text
                    className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-full"
                    size="txtCardoRegular24Gray80001"
                  >
                    1. Warranty is only applicable under the ‘Warranty Terms and
                    conditions’ of the Supplier.
                  </Text>
                <Text
                  className="mt-auto mx-auto relative text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-full"
                  size="txtCardoRegular24Gray80001"
                >
                  2. Warranty is only applicable during the time period
                  mentioned in the Invoice. Date of the Invoice will be the Date
                  of Purchase.
                </Text>
              <Text
                className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-full"
                size="txtCardoRegular24Gray80001"
              >
                3. Warranty is not applicable to the items with corrosions, burn
                marks or any physical damage.
              </Text>
              <Text
                className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                size="txtCardoRegular24Gray80001"
              >
                4. Warranty is only applicable to the extent of the proof of
                purchase produced. If no such proof exist, warranty cannot be
                claimed.
              </Text>
              <Text
                className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                size="txtCardoRegular24Gray80001"
              >
                5. Warranty covers only the manufacture defects. Damages or
                defects due to other causes, such as, negligence, misuse,
                improper operation, Power fluctuation, lightening or other
                natural disasters, sabotage or accident, etc. are not covered by
                the warranty.
              </Text>
              <Text
                className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-full"
                size="txtCardoRegular24Gray80001"
              >
                6. Warranty Does not apply for software or data lost during
                repair or replacement.
              </Text>
              <div className="border-b-2 border-gray-800 border-solid flex flex-col items-start justify-start pb-[35px] w-full">
                <Text
                  className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                  size="txtCardoRegular24Gray80001"
                >
                  7. 01M = 1 Month / 03M = 3 months / 06M += 180 Days / 01Y =
                  350 Days / 02Y = 700 Days / 03Y = 1050 Days / 05Y = 1750 Days
                  / NW = No warranty.
                </Text>
              </div>
            </div>
          </div>
        </div>





        <div className="bg-gray-50 flex flex-col items-center justify-start max-w-[1439px] md:px-10 sm:px-5 px-[100px] py-[30px] w-full">
          <div className="flex flex-col items-start justify-start max-w-[1233px] mx-auto w-full">
            <div className="flex flex-col gap-2 items-start justify-start w-full">
              <Text
                className="md:text-5xl text-7xl text-gray-800"
                size="txtCardoBold72Gray800"
              >
                <span className="text-gray-800 font-cardo text-left text-xl font-bold">
                  <>
                    Modern Office Automation
                    <br />
                  </>
                </span>
                <span className="md:text-[34px] sm:text-[32px] text-gray-800 font-cardo text-left text-4xl font-bold">
                  Pre Orders
                </span>
              </Text>
              <Text
                className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                size="txtCardoRegular24Gray80001"
              >
                In case your requirements supersede what the local market has to
                offer, we will provide you with assistance to meet these
                requirements. We will step up to cross horizons to locate and
                satisfy these requirements. Provided that the following
                conditions are met.
              </Text>
              <div className="relative w-full">
                <div className="absolute bottom-[1%] flex flex-col justify-start right-[1%] w-[154px]">
                  <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                  <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                  <div className="bg-light_blue-700 h-[15px] mr-[139px] mt-[71px] rounded-[3px] w-[15px]"></div>
                </div>
                <div className="flex flex-col gap-3 items-start justify-start relative">
                  <Text
                    className="text-4xl sm:text-[32px] md:text-[34px] text-gray-800_01 w-full"
                    size="txtCardoBold36Gray80001"
                  >
                    Conditions
                  </Text>
                  <Text
                    className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-full"
                    size="txtCardoRegular24Gray80001"
                  >
                    1. 60% minimum advance payment to proceed with a Pre Order.
                  </Text>
                </div>
                <Text
                  className="border-b-2 border-gray-800 border-solid max-w-[1233px] md:max-w-full mt-auto mx-auto pb-8 sm:pr-5 pr-[35px] relative text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-full"
                  size="txtCardoRegular24Gray80001"
                >
                  2. Any payment made in advance is non-refundable.
                </Text>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-gray-50 flex flex-col items-center justify-start max-w-[1439px] md:px-10 sm:px-5 px-[100px] py-[30px] w-full">
          <div className="flex flex-col items-start justify-start max-w-[1233px] mx-auto w-full">
            <div className="flex flex-col items-start justify-start w-full">
              <div className="flex flex-col items-start justify-start w-full">
                <Text
                  className="md:text-5xl text-7xl text-gray-800"
                  size="txtCardoBold72Gray800"
                >
                  <span className="text-gray-800 font-cardo text-left text-xl font-bold">
                    <>
                      Modern Office Automation
                      <br />
                    </>
                  </span>
                  <span className="md:text-[34px] sm:text-[32px] text-gray-800 font-cardo text-left text-4xl font-bold">
                    Home Delivery
                  </span>
                </Text>
                <Text
                  className="mt-2 text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-full"
                  size="txtCardoRegular24Gray80001"
                >
                  www.modernoffice.online offers home delivery in every corner
                  of Sri Lanka without any limitation. We deliver to your
                  doorstep within a very short time. We assure you that we
                  undertake delivery to any part of Sri Lanka provided that the
                  following conditions are met.
                </Text>
                <div className="flex md:flex-col flex-row md:gap-[55px] items-center justify-between mt-[3px] w-[99%] md:w-full">
                  <div className="flex flex-col items-start justify-start">
                    <Text
                      className="text-4xl sm:text-[32px] md:text-[34px] text-gray-800_01 w-full"
                      size="txtCardoBold36Gray80001"
                    >
                      Conditions
                    </Text>
                    <Text
                      className="mt-3 text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-full"
                      size="txtCardoRegular24Gray80001"
                    >
                      1. 100% full Payment is required.
                    </Text>
                    <Text
                      className="mt-[7px] text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-full"
                      size="txtCardoRegular24Gray80001"
                    >
                      2. Payment to be made directly into our bank account for
                      which details will be provided on request.
                    </Text>
                    <Text
                      className="mt-[7px] text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-full"
                      size="txtCardoRegular24Gray80001"
                    >
                      3. Delivery is outsourced to a dedicated courier.
                    </Text>
                  </div>
                  <div className="flex flex-col justify-start w-[154px] md:w-full">
                    <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                    <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                    <div className="bg-light_blue-700 h-[15px] mr-[139px] mt-[71px] rounded-[3px] w-[15px]"></div>
                  </div>
                </div>
                <Text
                  className="border-b-2 border-gray-800 border-solid mt-[5px] pb-8 sm:pr-5 pr-[35px] text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-full"
                  size="txtCardoRegular24Gray80001"
                >
                  4. Delivery Charge will be free only for the orders above
                  100,000LKR
                </Text>
              </div>
            </div>
          </div>
        </div>
        <Footer className="bg-white-A700 border-gray-400_01 border-solid border-t flex font-raleway gap-5 items-center justify-center md:px-5 px-[100px] py-10 w-full" />
      </div>
    </>
  );
};

export default TermsandconditionsPage;
