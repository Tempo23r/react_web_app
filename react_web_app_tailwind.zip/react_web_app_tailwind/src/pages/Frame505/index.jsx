import React from "react";

import { Img, Line, List, Text } from "components";

const Frame505Page = () => {
  return (
    <>
      <div className="bg-white-A700 flex flex-col font-roboto items-center justify-start mx-auto p-[92px] md:px-10 sm:px-5 w-full">
        <div className="flex flex-col gap-[21px] justify-start max-w-[752px] mb-[140px] mx-auto w-full">
          <Text
            className="md:ml-[0] ml-[544px] text-base text-black-900 w-[11%] sm:w-full"
            size="txtRobotoRomanSemiBold16Black900"
          >
            While Hovering
          </Text>
          <List
            className="sm:flex-col flex-row font-cardo md:gap-10 gap-[294px] grid md:grid-cols-1 grid-cols-2 justify-center w-full"
            orientation="horizontal"
          >
            <div className="bg-white-A700 border border-gray-800 border-solid flex flex-col gap-5 items-center justify-start sm:px-5 px-6 py-5 rounded-[20px] w-auto">
              <div className="flex flex-col gap-1.5 items-center justify-center w-[181px]">
                <Img
                  className="h-[146px] md:h-auto object-cover w-[156px] sm:w-full"
                  src="images/img_rectangle1249.png"
                  alt="rectangle1249"
                />
                <Text
                  className="text-2xl md:text-[22px] text-center text-gray-900_02 sm:text-xl w-auto"
                  size="txtCardoBold24Gray90002"
                >
                  Site Visiting
                </Text>
                <div className="flex flex-col font-roboto items-center justify-start w-full">
                  <Line className="bg-black-900 h-px w-full" />
                  <Text
                    className="mt-[5px] text-blue_gray-400 text-center text-xl w-full"
                    size="txtRobotoRomanRegular20Bluegray400"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit
                  </Text>
                </div>
              </div>
              <Text
                className="bg-gray-900_02 border border-solid border-white-A700 justify-center px-4 py-[3px] rounded-[16px] text-center text-lg text-white-A700 w-auto"
                size="txtCardoBold18"
              >
                Explore Now
              </Text>
            </div>
            <div className="bg-gradient3  flex flex-col gap-5 items-center justify-start sm:px-5 px-6 py-5 rounded-[20px] w-auto">
              <div className="flex flex-col gap-1.5 items-center justify-center w-[181px]">
                <Img
                  className="h-[146px] md:h-auto object-cover w-[156px] sm:w-full"
                  src="images/img_rectangle1249.png"
                  alt="rectangle1249"
                />
                <Text
                  className="text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl w-auto"
                  size="txtCardoBold24WhiteA700"
                >
                  Site Visiting
                </Text>
                <div className="flex flex-col font-roboto items-center justify-start w-full">
                  <Line className="bg-white-A700 h-px w-full" />
                  <Text
                    className="mt-[5px] text-center text-gray-50_01 text-xl w-full"
                    size="txtRobotoRomanRegular20Gray5001"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit
                  </Text>
                </div>
              </div>
              <Text
                className="bg-white-A700 border border-light_blue-700 border-solid justify-center px-4 py-[3px] rounded-[16px] text-center text-lg text-light_blue-700 w-auto"
                size="txtCardoBold18Lightblue700"
              >
                Explore Now
              </Text>
            </div>
          </List>
        </div>
      </div>
    </>
  );
};

export default Frame505Page;
