import React from "react";

import { Button, Img, Input, Text } from "components";
import Footer from "components/Footer";
import Header from "components/Header";


const OrdersuccessPage = () => {
  const [frame115value, setFrame115value] = React.useState("");

  return (
    <>
      <div className="bg-white-A700 flex flex-col font-raleway sm:gap-10 md:gap-10 gap-[63px] items-center justify-start mx-auto w-full">
        <Header className="bg-gray-50_01 flex md:flex-col md:gap-5 items-center justify-center md:px-5 w-full" />
        <div className="bg-white-A700 flex flex-col gap-10 items-start justify-start p-10 md:px-5 rounded-[60px] w-auto md:w-full">
          <div className="md:h-[292px] h-[487px] sm:h-[589px] relative w-full">
            <div className="absolute flex sm:flex-col flex-row sm:gap-5 items-center justify-start right-[0] top-[16%] w-[70%]">
              <div className="flex flex-col gap-[9px] justify-start sm:mt-0 mt-1.5 w-1/2 sm:w-full">
                <Img
                  className="h-[52px] md:ml-[0] ml-[42px] rounded-lg w-[52px]"
                  src="images/img_thumbsup_light_blue_700_52x52.svg"
                  alt="thumbsup_One"
                />
                <div className="flex flex-row gap-3.5 items-start justify-between w-full">
                  <Img
                    className="h-[19px] mt-[197px] rounded-[3px] w-[19px]"
                    src="images/img_thumbsup_light_blue_700_52x52.svg"
                    alt="thumbsup_Two"
                  />
                  <div className="md:h-[200px] h-[225px] relative w-[87%]">
                    <div className="absolute md:h-[200px] h-[218px] inset-[0] justify-center m-auto p-[5px] w-full">
                      <div className="bg-light_blue-700 h-[200px] m-auto rounded-[50%] shadow-bs4 w-[200px]"></div>
                      <Img
                        className="absolute bottom-[11%] h-[150px] inset-x-[0] mx-auto"
                        src="images/img_check.svg"
                        alt="check"
                      />
                    </div>
                    <Img
                      className="absolute bottom-[0] h-[19px] inset-x-[0] mx-auto rounded-[3px] w-[19px]"
                      src="images/img_thumbsup_light_blue_700_52x52.svg"
                      alt="thumbsup_Three"
                    />
                  </div>
                </div>
              </div>
              <div className="flex flex-col justify-start w-[35%] sm:w-full">
                <div className="flex flex-row gap-[50px] items-start justify-start w-[73%] md:w-full">
                  <Img
                    className="h-[19px] mt-6 rounded-[3px] w-[19px]"
                    src="images/img_thumbsup_light_blue_700_52x52.svg"
                    alt="thumbsup_Four"
                  />
                  <Img
                    className="h-[52px] rounded-lg w-[52px]"
                    src="images/img_thumbsup_light_blue_700_52x52.svg"
                    alt="thumbsup_Five"
                  />
                </div>
                <Img
                  className="h-[19px] md:ml-[0] ml-[111px] mt-[31px] rounded-[3px] w-[19px]"
                  src="images/img_thumbsup_light_blue_700_52x52.svg"
                  alt="thumbsup_Six"
                />
                <div className="flex flex-row gap-[83px] items-start justify-end ml-3.5 md:ml-[0] mt-[90px] w-[92%] md:w-full">
                  <Img
                    className="h-[19px] mt-[22px] rounded-[3px] w-[19px]"
                    src="images/img_thumbsup_light_blue_700_52x52.svg"
                    alt="thumbsup_Seven"
                  />
                  <Img
                    className="h-[52px] rounded-lg w-[52px]"
                    src="images/img_thumbsup_light_blue_700_52x52.svg"
                    alt="thumbsup_Eight"
                  />
                </div>
              </div>
              <Img
                className="h-[19px] sm:ml-[0] ml-[53px] rounded-[3px] w-[19px]"
                src="images/img_thumbsup_light_blue_700_52x52.svg"
                alt="thumbsup_Nine"
              />
            </div>
            <div className="absolute flex flex-col justify-start left-[10%] top-[0] w-[51%]">
              <div className="flex flex-row items-start justify-between w-full">
                <Img
                  className="h-[19px] mt-[23px] rounded-[3px] w-[19px]"
                  src="images/img_thumbsup_light_blue_700_52x52.svg"
                  alt="thumbsup_Ten"
                />
                <Img
                  className="h-[52px] rounded-lg w-[52px]"
                  src="images/img_thumbsup_light_blue_700_52x52.svg"
                  alt="thumbsup_Eleven"
                />
              </div>
              <Img
                className="h-[19px] md:ml-[0] ml-[233px] mt-[3px] rounded-[3px] w-[19px]"
                src="images/img_thumbsup_light_blue_700_52x52.svg"
                alt="thumbsup_Twelve"
              />
            </div>
            <div className="absolute bottom-[0] flex flex-col justify-start left-[1%] w-[87%]">
              <div className="flex md:flex-col flex-row md:gap-5 items-center justify-start w-full">
                <Img
                  className="h-[52px] mb-[9px] rounded-lg w-[52px]"
                  src="images/img_thumbsup_light_blue_700_52x52.svg"
                  alt="thumbsup_Thirteen"
                />
                <Img
                  className="h-[52px] md:ml-[0] ml-[239px] md:mt-0 mt-[9px] rounded-lg w-[52px]"
                  src="images/img_thumbsup_light_blue_700_52x52.svg"
                  alt="thumbsup_Fourteen"
                />
                <Img
                  className="h-[19px] md:ml-[0] ml-[132px] rounded-[3px] w-[19px]"
                  src="images/img_thumbsup_light_blue_700_52x52.svg"
                  alt="thumbsup_Fifteen"
                />
                <Img
                  className="h-[19px] md:ml-[0] ml-[85px] rounded-[3px] w-[19px]"
                  src="images/img_thumbsup_light_blue_700_52x52.svg"
                  alt="thumbsup_Sixteen"
                />
              </div>
              <Img
                className="h-[19px] md:ml-[0] ml-[204px] rounded-[3px] w-[19px]"
                src="images/img_thumbsup_light_blue_700_52x52.svg"
                alt="thumbsup_Seventeen"
              />
            </div>
            <Img
              className="absolute h-[52px] left-[0] rounded-lg top-[14%] w-[52px]"
              src="images/img_thumbsup_light_blue_700_52x52.svg"
              alt="thumbsup_Eighteen"
            />
            <div className="absolute bottom-[31%] flex flex-col md:gap-10 gap-[69px] justify-start left-[2%] w-[28%]">
              <Img
                className="h-[19px] md:ml-[0] ml-[148px] rounded-[3px] w-[19px]"
                src="images/img_thumbsup_light_blue_700_52x52.svg"
                alt="thumbsup_Nineteen"
              />
              <div className="flex flex-row items-start justify-between w-full">
                <Img
                  className="h-[19px] mt-[52px] rounded-[3px] w-[19px]"
                  src="images/img_thumbsup_light_blue_700_52x52.svg"
                  alt="thumbsup_Twenty"
                />
                <Img
                  className="h-[52px] mb-[19px] rounded-lg w-[52px]"
                  src="images/img_thumbsup_light_blue_700_52x52.svg"
                  alt="thumbsup_TwentyOne"
                />
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-10 items-center justify-start w-auto md:w-full">
            <div className="flex flex-col gap-2 items-center justify-start w-auto md:w-full">
              <Text
                className="text-4xl sm:text-[32px] md:text-[34px] text-gray-800 w-auto"
                size="txtCardoBold36"
              >
                Thank You For Ordering !
              </Text>
              <Text
                className="max-w-[701px] md:max-w-full text-center text-gray-900_01 text-xl"
                size="txtRobotoRomanRegular20"
              >
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua
              </Text>
            </div>
            <div className="flex md:flex-col flex-row gap-10 items-start justify-start w-auto md:w-full">
              <Button
                className="cursor-pointer font-semibold leading-[normal] rounded-[24px] text-2xl md:text-[22px] text-center sm:text-xl w-[280px]"
                color="light_blue_700"
                size="sm"
                variant="outline"
              >
                View Orders
              </Button>
              <Button
                className="cursor-pointer font-semibold leading-[normal] rounded-[24px] text-2xl md:text-[22px] text-center sm:text-xl w-[302px]"
                color="light_blue_700"
                size="sm"
                variant="fill"
              >
                Back To Shop
              </Button>
            </div>
          </div>
        </div>
        <Footer className="bg-white-A700 border-gray-400_01 border-solid border-t flex gap-5 items-center justify-center md:px-5 px-[100px] py-10 w-full" />
      </div>
    </>
  );
};

export default OrdersuccessPage;
