import React from "react";

import { Button, Img, Input, Line, Text } from "components";
import Footer2 from "components/Footer2";
import Header2 from "components/Header2";
import MyOrdersReviewsProfile from "components/MyOrdersReviewsProfile";

import { CloseSVG } from "../../assets/images";

const MyordersreviewsPage = () => {
  const [frame115value, setFrame115value] = React.useState("");
  const [frame456value, setFrame456value] = React.useState("");

  return (
    <>
      <div className="bg-gray-100_01 flex flex-col items-start justify-start mx-auto w-full">
        <div className="flex flex-col font-raleway items-center w-full">
          <Header2 className="bg-gray-50_01 flex md:flex-col md:gap-5 items-center justify-center md:px-5 shadow-bs5 w-full" />
        </div>
        <Text
          className="md:ml-[0] ml-[100px] mt-[49px] md:text-5xl text-7xl text-gray-800"
          size="txtCardoBold72Gray800"
        >
          <span className="text-gray-800 font-inter text-left text-xl font-medium">
            Modern Office Automation /{" "}
          </span>
          <span className="text-light_blue-700 font-inter text-left text-xl font-medium">
            <>
              My Orders
              <br />
            </>
          </span>
          <span className="text-gray-800 font-inter text-left font-bold">
            My{" "}
          </span>
          <span className="text-gray-800 font-inter text-left font-bold">
            Orders
          </span>
        </Text>
        <div className="flex flex-col font-roboto gap-[9px] items-center mt-[11px] w-[1440px] md:w-full">
          <MyOrdersReviewsProfile
            className="bg-gray-100_01 flex md:flex-col flex-row md:gap-10 items-start justify-between max-w-[1440px] md:px-10 sm:px-5 px-[100px] py-10 w-full"
            reviewnooneprops={
              <Text className="text-base text-black-900 text-center w-auto">
                <span className="text-black-900 font-cardo font-normal">
                  Review No
                </span>
                <span className="text-black-900 font-roboto font-normal">
                  {" "}
                  -{" "}
                </span>
                <span className="text-black-900 font-roboto font-medium">
                  01
                </span>
              </Text>
            }
          />
          <Footer2 className="bg-white-A700 border-gray-400_01 border-solid border-t flex font-raleway gap-5 items-center justify-center md:px-5 px-[100px] py-10 w-full" />
        </div>
      </div>
    </>
  );
};

export default MyordersreviewsPage;
