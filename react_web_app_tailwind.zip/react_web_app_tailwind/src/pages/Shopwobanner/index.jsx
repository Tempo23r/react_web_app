import React from "react";

import { Button, Img, Input, List, Switch, Text } from "components";
import Footer1 from "components/Footer1";
import Header from "components/Header";

import { CloseSVG } from "../../assets/images";

const ShopwobannerPage = () => {
  const [frame115value, setFrame115value] = React.useState("");

  return (
    <>
      <div className="bg-white-A700 flex flex-col font-raleway items-center justify-start mx-auto w-full">
        <div className="flex flex-col items-start justify-start w-full">
          <Header className="bg-gray-50_01 flex md:flex-col md:gap-5 items-center justify-center pb-1 md:px-5 w-full" />
          <div className="bg-gray-50_01 flex sm:flex-col flex-row md:gap-10 items-center justify-between max-w-[1439px] pb-4 pt-3 md:px-10 sm:px-5 px-[100px] w-full">
            <Text
              className="capitalize md:text-3xl sm:text-[28px] text-[32px] text-center text-gray-800 w-auto"
              size="txtRalewayRomanBold32"
            >
              Shop
            </Text>
            <div className="flex sm:flex-1 sm:flex-col flex-row sm:gap-10 gap-[60px] items-center justify-center w-auto sm:w-full">
              <div className="flex flex-row gap-3 items-center justify-start w-auto">
                <Text
                  className="capitalize text-base text-center text-gray-600_49 w-auto"
                  size="txtRalewayRomanMedium16"
                >
                  Clear Filter
                </Text>
                <Img
                  className="h-[22px] w-[19px]"
                  src="images/img_close.svg"
                  alt="close"
                />
              </div>
              <div className="flex flex-row gap-3 items-center justify-start w-auto">
                <Text
                  className="capitalize text-base text-center text-gray-800 w-auto"
                  size="txtRalewayRomanMedium16Gray800"
                >
                  Hide Filter
                </Text>
                <Img className="h-4 w-5" src="images/img_eye.svg" alt="eye" />
              </div>
              <div className="flex flex-row gap-3 items-center justify-start w-auto">
                <Text
                  className="capitalize text-base text-center text-gray-800 w-auto"
                  size="txtRalewayRomanMedium16Gray800"
                >
                  sort by
                </Text>
                <Img
                  className="h-1.5 w-[11px]"
                  src="images/img_arrowdown_gray_800.svg"
                  alt="arrowdown_One"
                />
              </div>
            </div>
          </div>
          <div className="flex md:flex-col flex-row font-roboto md:gap-5 items-start justify-start md:px-5 w-[93%] md:w-full">
            <div className="bg-gray-50_01 flex flex-col gap-5 items-start justify-start pb-5 md:pl-10 sm:pl-5 pl-[100px] pr-5 pt-4 w-auto">
              <div className="flex flex-row gap-3 items-start justify-start w-[242px]">
              <Button
                    className="capitalize cursor-pointer font-medium leading-[normal] text-base text-center w-full"
                    shape="round"
                    color="gray_800"
                    size="xs"
                    variant="outline"
                  >
                    New Arrivals
                  </Button>
                <Button
                  className="capitalize cursor-pointer font-medium leading-[normal] text-base text-center w-full"
                  shape="round"
                  color="gray_800"
                  size="xs"
                  variant="outline"
                >
                  Offers
                </Button>
              </div>
              <div className="flex flex-col gap-3 items-start justify-start w-auto">
                <div className="flex flex-row items-center justify-between w-[242px]">
                  <Text
                    className="capitalize text-2xl md:text-[22px] text-center text-gray-800 sm:text-xl w-auto"
                    size="txtRobotoRomanMedium24"
                  >
                    Categories
                  </Text>
                  <a
                    href="javascript:"
                    className="capitalize text-base text-center text-gray-800 underline w-auto"
                  >
                    <Text size="txtRobotoRomanLight16">See All</Text>
                  </a>
                </div>
                <Button
                  className="capitalize cursor-pointer leading-[normal] min-w-[105px] text-base text-center"
                  shape="round"
                  color="gray_800"
                  size="xs"
                  variant="outline"
                >
                  Category_1
                </Button>
                <div className="flex flex-col items-center justify-start w-full">
                  <div className="flex flex-col gap-2.5 items-start justify-start w-full">
                    <div className="flex flex-row gap-1.5 items-center justify-between w-full">
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[105px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Category_1
                      </Button>
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[65px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Cat_1
                      </Button>
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[65px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Cat_2
                      </Button>
                    </div>
                    <div className="flex flex-row gap-1.5 items-center justify-start w-[88%] md:w-full">
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[105px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Category_1
                      </Button>
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[105px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Category_1
                      </Button>
                    </div>
                    <div className="flex flex-row gap-1.5 items-center justify-between w-full">
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[105px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Category_2
                      </Button>
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[65px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Cat_2
                      </Button>
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[65px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Cat_1
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex flex-row items-center justify-between w-[242px]">
                <Text
                  className="capitalize text-2xl md:text-[22px] text-center text-gray-800 sm:text-xl w-auto"
                  size="txtRobotoRomanMedium24"
                >
                  In Stock
                </Text>
                <Switch
                  onColor="#1d1d1e"
                  offColor="#a2d0e1"
                  onHandleColor="#46494c"
                  offHandleColor="#1690be"
                  value={false}
                  className=""
                />
              </div>
              <div className="flex flex-row items-center justify-between w-[242px]">
                <Text
                  className="capitalize text-2xl md:text-[22px] text-center text-gray-800 sm:text-xl w-auto"
                  size="txtRobotoRomanMedium24"
                >
                  Coming Soon
                </Text>
                <Switch
                  onColor="#1d1d1e"
                  offColor="#a2d0e1"
                  onHandleColor="#46494c"
                  offHandleColor="#1690be"
                  value={true}
                  className=""
                />
              </div>
              <List
                className="flex flex-col gap-[18px] w-[98%]"
                orientation="vertical"
              >
                <div className="flex flex-col gap-2 items-start justify-start w-auto">
                  <div className="flex flex-col items-center justify-start w-[242px]">
                    <Text
                      className="capitalize text-2xl md:text-[22px] text-center text-gray-800 sm:text-xl w-auto"
                      size="txtRobotoRomanMedium24"
                    >
                      Price
                    </Text>
                  </div>
                  <div className="flex flex-row gap-3 items-start justify-start w-auto">
                    <div className="flex flex-col gap-0.5 items-start justify-start w-auto">
                      <div className="flex flex-col items-center justify-start w-7">
                        <Text
                          className="capitalize text-center text-gray-800 text-xs w-auto"
                          size="txtRobotoRomanRegular12"
                        >
                          From
                        </Text>
                      </div>
                      <Text
                        className="border border-gray-800 border-solid capitalize pl-3 sm:pr-5 pr-[35px] py-[5px] rounded-[10px] text-base text-center text-gray-800 w-[115px]"
                        size="txtRobotoRomanRegular16"
                      >
                        0
                      </Text>
                    </div>
                    <div className="flex flex-col gap-0.5 items-start justify-start w-auto">
                      <div className="flex flex-col items-center justify-start w-3.5">
                        <Text
                          className="capitalize text-center text-gray-800 text-xs"
                          size="txtRobotoRomanRegular12"
                        >
                          To
                        </Text>
                      </div>
                      <Text
                        className="border border-gray-800 border-solid capitalize pl-3 sm:pr-5 pr-[35px] py-[5px] rounded-[10px] text-base text-center text-gray-800 w-[115px]"
                        size="txtRobotoRomanRegular16"
                      >
                        0
                      </Text>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col gap-2 items-start justify-start w-auto">
                  <div className="flex flex-col items-center justify-start w-[242px]">
                    <Text
                      className="capitalize text-2xl md:text-[22px] text-center text-gray-800 sm:text-xl w-auto"
                      size="txtRobotoRomanMedium24"
                    >
                      Manufactured Year
                    </Text>
                  </div>
                  <div className="flex flex-row gap-3 items-start justify-start w-auto">
                    <div className="flex flex-col gap-0.5 items-start justify-start w-auto">
                      <div className="flex flex-col items-center justify-start w-7">
                        <Text
                          className="capitalize text-center text-gray-800 text-xs w-auto"
                          size="txtRobotoRomanRegular12"
                        >
                          From
                        </Text>
                      </div>
                      <Text
                        className="border border-gray-800 border-solid lowercase pb-[3px] pl-3 sm:pr-5 pr-[35px] pt-2 rounded-[10px] text-base text-center text-gray-800 w-[115px]"
                        size="txtRobotoRomanRegular16"
                      >
                        yyyy
                      </Text>
                    </div>
                    <div className="flex flex-col gap-0.5 items-start justify-start w-auto">
                      <div className="flex flex-col items-center justify-start w-3.5">
                        <Text
                          className="capitalize text-center text-gray-800 text-xs"
                          size="txtRobotoRomanRegular12"
                        >
                          To
                        </Text>
                      </div>
                      <Text
                        className="border border-gray-800 border-solid lowercase pb-[3px] pl-3 sm:pr-5 pr-[35px] pt-2 rounded-[10px] text-base text-center text-gray-800 w-[115px]"
                        size="txtRobotoRomanRegular16"
                      >
                        yyyy
                      </Text>
                    </div>
                  </div>
                </div>
              </List>
              <div className="flex flex-col gap-3 items-start justify-start w-auto">
                <div className="flex flex-row items-center justify-between w-[242px]">
                  <Text
                    className="capitalize text-2xl md:text-[22px] text-center text-gray-800 sm:text-xl w-auto"
                    size="txtRobotoRomanMedium24"
                  >
                    Brand
                  </Text>
                  <a
                    href="javascript:"
                    className="capitalize text-base text-center text-gray-800 underline w-auto"
                  >
                    <Text size="txtRobotoRomanLight16">See All</Text>
                  </a>
                </div>
                <div className="flex flex-col items-center justify-start w-full">
                  <div className="flex flex-col gap-2.5 items-start justify-start w-[99%] md:w-full">
                    <div className="flex flex-row items-center justify-evenly w-full">
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[82px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Brand_1
                      </Button>
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[82px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Brand_2
                      </Button>
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[74px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Brnd_3
                      </Button>
                    </div>
                    <div className="flex flex-row items-center justify-start w-[69%] md:w-full">
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[82px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Brand_4
                      </Button>
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[82px] ml-[3px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Brand_5
                      </Button>
                    </div>
                    <div className="flex flex-row items-center justify-evenly w-full">
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[82px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Brand_6
                      </Button>
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[74px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Brnd_7
                      </Button>
                      <Button
                        className="capitalize cursor-pointer leading-[normal] min-w-[82px] text-base text-center"
                        shape="round"
                        color="gray_800"
                        size="xs"
                        variant="outline"
                      >
                        Brand_8
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex flex-col font-raleway items-center justify-start w-[73%] md:w-full">
              <div className="md:gap-5 gap-[22px] grid sm:grid-cols-1 md:grid-cols-2 grid-cols-3 justify-center min-h-[auto] w-full">
                <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                  <Img
                    className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                    src="images/img_rectangle87.png"
                    alt="rectangleEightySeven"
                  />
                  <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                    <Text
                      className="text-gray-800_01 text-xl w-full"
                      size="txtRalewayRomanBold20"
                    >
                      Lorem ipsum dolor sit amet
                    </Text>
                    <div className="flex flex-row font-roboto items-center justify-between w-full">
                      <div className="flex flex-row gap-2 items-center justify-start w-auto">
                        <Text
                          className="line-through text-base text-black-900_99 w-auto"
                          size="txtRobotoRomanSemiBold16"
                        >
                          $653
                        </Text>
                        <Text
                          className="text-gray-800_01 text-xl w-auto"
                          size="txtRobotoRomanSemiBold20"
                        >
                          $623
                        </Text>
                      </div>
                      <Img
                        className="h-6 w-[78px]"
                        src="images/img_user.svg"
                        alt="user"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                  <Img
                    className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                    src="images/img_rectangle87.png"
                    alt="rectangleEightySeven"
                  />
                  <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                    <Text
                      className="text-gray-800_01 text-xl w-full"
                      size="txtRalewayRomanBold20"
                    >
                      Lorem ipsum dolor sit amet
                    </Text>
                    <div className="flex flex-row font-roboto items-center justify-between w-full">
                      <div className="flex flex-row gap-2 items-center justify-start w-auto">
                        <Text
                          className="line-through text-base text-black-900_99 w-auto"
                          size="txtRobotoRomanSemiBold16"
                        >
                          $653
                        </Text>
                        <Text
                          className="text-gray-800_01 text-xl w-auto"
                          size="txtRobotoRomanSemiBold20"
                        >
                          $623
                        </Text>
                      </div>
                      <Img
                        className="h-6 w-[78px]"
                        src="images/img_user.svg"
                        alt="user"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                  <Img
                    className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                    src="images/img_rectangle87.png"
                    alt="rectangleEightySeven"
                  />
                  <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                    <Text
                      className="text-gray-800_01 text-xl w-full"
                      size="txtRalewayRomanBold20"
                    >
                      Lorem ipsum dolor sit amet
                    </Text>
                    <div className="flex flex-row font-roboto items-center justify-between w-full">
                      <div className="flex flex-row gap-2 items-center justify-start w-auto">
                        <Text
                          className="line-through text-base text-black-900_99 w-auto"
                          size="txtRobotoRomanSemiBold16"
                        >
                          $653
                        </Text>
                        <Text
                          className="text-gray-800_01 text-xl w-auto"
                          size="txtRobotoRomanSemiBold20"
                        >
                          $623
                        </Text>
                      </div>
                      <Img
                        className="h-6 w-[78px]"
                        src="images/img_user.svg"
                        alt="user"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                  <Img
                    className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                    src="images/img_rectangle87.png"
                    alt="rectangleEightySeven"
                  />
                  <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                    <Text
                      className="text-gray-800_01 text-xl w-full"
                      size="txtRalewayRomanBold20"
                    >
                      Lorem ipsum dolor sit amet
                    </Text>
                    <div className="flex flex-row font-roboto items-center justify-between w-full">
                      <div className="flex flex-row gap-2 items-center justify-start w-auto">
                        <Text
                          className="line-through text-base text-black-900_99 w-auto"
                          size="txtRobotoRomanSemiBold16"
                        >
                          $653
                        </Text>
                        <Text
                          className="text-gray-800_01 text-xl w-auto"
                          size="txtRobotoRomanSemiBold20"
                        >
                          $623
                        </Text>
                      </div>
                      <Img
                        className="h-6 w-[78px]"
                        src="images/img_user.svg"
                        alt="user"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                  <Img
                    className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                    src="images/img_rectangle87.png"
                    alt="rectangleEightySeven"
                  />
                  <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                    <Text
                      className="text-gray-800_01 text-xl w-full"
                      size="txtRalewayRomanBold20"
                    >
                      Lorem ipsum dolor sit amet
                    </Text>
                    <div className="flex flex-row font-roboto items-center justify-between w-full">
                      <div className="flex flex-row gap-2 items-center justify-start w-auto">
                        <Text
                          className="line-through text-base text-black-900_99 w-auto"
                          size="txtRobotoRomanSemiBold16"
                        >
                          $653
                        </Text>
                        <Text
                          className="text-gray-800_01 text-xl w-auto"
                          size="txtRobotoRomanSemiBold20"
                        >
                          $623
                        </Text>
                      </div>
                      <Img
                        className="h-6 w-[78px]"
                        src="images/img_user.svg"
                        alt="user"
                      />
                    </div>
                  </div>
                </div>
                <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                  <Img
                    className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                    src="images/img_rectangle87.png"
                    alt="rectangleEightySeven"
                  />
                  <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                    <Text
                      className="text-gray-800_01 text-xl w-full"
                      size="txtRalewayRomanBold20"
                    >
                      Lorem ipsum dolor sit amet
                    </Text>
                    <div className="flex flex-row font-roboto items-center justify-between w-full">
                      <div className="flex flex-row gap-2 items-center justify-start w-auto">
                        <Text
                          className="line-through text-base text-black-900_99 w-auto"
                          size="txtRobotoRomanSemiBold16"
                        >
                          $653
                        </Text>
                        <Text
                          className="text-gray-800_01 text-xl w-auto"
                          size="txtRobotoRomanSemiBold20"
                        >
                          $623
                        </Text>
                      </div>
                      <Img
                        className="h-6 w-[78px]"
                        src="images/img_user.svg"
                        alt="user"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Footer1 className="bg-white-A700 border-gray-400_01 border-solid border-t flex font-raleway gap-5 items-center justify-center md:px-5 px-[100px] py-10 w-full" />
        </div>
      </div>
    </>
  );
};

export default ShopwobannerPage;
