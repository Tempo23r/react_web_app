import React from "react";

import { Button, Img, Input, Line, Text } from "components";
import Footer from "components/Footer";
import Header from "components/Header";
import MyProfileProfile from "components/MyProfileProfile";


const MyprofilePage = () => {
  const [frame115value, setFrame115value] = React.useState("");
  const [frame456value, setFrame456value] = React.useState("");

  return (
    <>
      <div className="bg-gray-100_01 flex flex-col items-start justify-start mx-auto w-full">
        <div className="flex flex-col font-raleway items-center w-full">
          <Header className="bg-gray-50_01 flex md:flex-col md:gap-5 items-center justify-center md:px-5 shadow-bs5 w-full" />
        </div>
        <Text
          className="md:ml-[0] ml-[100px] mt-[38px] md:text-5xl text-7xl text-gray-800"
          size="txtCardoBold72Gray800"
        >
          <span className="text-gray-800 font-inter text-left text-xl font-medium">
            Modern Office Automation /{" "}
          </span>
          <span className="text-light_blue-700 font-inter text-left text-xl font-medium">
            <>
              My Account
              <br />
            </>
          </span>
          <span className="text-gray-800 font-inter text-left font-bold">
            My Account
          </span>
        </Text>
        <div className="flex flex-col font-roboto items-center mt-[22px] w-full">
          <MyProfileProfile className="bg-gray-100_01 flex md:flex-col flex-row md:gap-10 h-[1116px] md:h-auto items-start justify-between max-w-[1440px] md:px-10 sm:px-5 px-[100px] py-10 w-full" />
          <Footer className="bg-white-A700 border-gray-400_01 border-solid border-t flex font-raleway gap-5 items-center justify-center md:px-5 px-[100px] py-10 w-full" />
        </div>
      </div>
    </>
  );
};

export default MyprofilePage;
