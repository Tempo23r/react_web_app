import React from "react";

import { Button, Img, Input, Text } from "components";
import Footer from "components/Footer";
import Header1 from "components/Header1";

import { CloseSVG } from "../../assets/images";

const OurservicesPage = () => {
  const [frame115value, setFrame115value] = React.useState("");

  return (
    <>
      <div className="bg-white-A700 flex flex-col font-cardo items-center justify-start mx-auto w-full">
        <div
          className="bg-cover bg-no-repeat flex flex-col h-[800px] items-center justify-start pb-[181px] w-full"
          style={{ backgroundImage: "url('images/img_frame188.png')" }}
        >
          <Header1 className="flex flex-col font-cardo items-center justify-center md:px-5 w-full" />
          <Text
            className="mt-[164px] md:text-5xl text-7xl text-center text-white-A700 tracking-[2.16px] uppercase"
            size="txtCardoBold72"
          >
            Our service
          </Text>
          <div className="flex flex-col font-raleway gap-3.5 items-center justify-start md:px-5 px-[63px]">
            <a
              href="www.modernoffice.online"
              className="text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl"
              target="_blank"
              rel="noreferrer"
            >
              <Text size="txtRalewayRomanBold24">www.modernoffice.online</Text>
            </a>
            <Text
              className="capitalize text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl"
              size="txtRalewayRomanMedium24"
            >
              Largest and Best online office automation store in sri lanka
            </Text>
          </div>
          <Button
            className="cursor-pointer flex items-center justify-center min-w-[214px] mt-[67px] rounded-[21px]"
            leftIcon={
              <Img
                className="h-6 mt-px mb-1 mr-3"
                src="images/img_thumbsup.svg"
                alt="thumbs_up"
              />
            }
            color="white_A700"
            size="md"
            variant="fill"
          >
            <div className="font-bold font-raleway leading-[normal] md:text-[22px] sm:text-xl text-2xl text-center">
              Shop Now
            </div>
          </Button>
        </div>
        <div className="bg-white-A700 flex flex-col items-center justify-start max-w-[1439px] md:px-10 sm:px-5 px-[100px] py-[60px] w-full">
          <div className="flex flex-col items-start justify-start max-w-[1233px] mx-auto w-full">
            <div className="flex flex-col gap-2 items-start justify-start w-full">
              <Text
                className="md:text-5xl text-7xl text-gray-800"
                size="txtCardoBold72Gray800"
              >
                <>
                  Modern Office Automation
                  <br />
                  Our Services
                </>
              </Text>
              <div className="relative w-full">
                <div className="absolute bottom-[0] flex flex-col justify-start right-[1%] w-[13%]">
                  <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                  <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                  <div className="bg-light_blue-700 h-px mr-[139px] mt-[71px] w-[10%]"></div>
                </div>
                <div className="border-b-2 border-gray-800 border-solid flex flex-col items-center justify-start max-w-[1233px] mx-auto pb-[35px] relative w-full">
                  <Text
                    className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                    size="txtCardoRegular24Gray80001"
                  >
                    {" "}
                    Customer satisfaction is our priority. This is where our
                    technical department will play a role. They will ensure that
                    customers who want training or installation will be met from
                    start to finish. The after sales services provided are:
                  </Text>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col font-inter gap-5 items-center justify-center max-w-[1440px] md:px-10 sm:px-5 px-[100px] py-10 w-full">
          <div className="md:h-[416px] h-[421px] md:px-10 sm:px-5 px-[60px] py-[30px] relative w-[1340px] md:w-full">
            <div className="absolute bg-gradient2  flex flex-col h-max inset-y-[0] items-center justify-end left-[0] max-w-[1240px] my-auto md:px-10 sm:px-5 px-[60px] py-[30px] rounded-[20px] w-full">
              <Img
                className="h-[356px] md:h-auto object-cover w-[321px]"
                src="images/img_peopleataconstruction.png"
                alt="peopleataconstr"
              />
            </div>
            <div className="absolute bottom-[0] flex flex-col items-end justify-center right-[0] w-full">
              <div className="flex flex-col gap-2 items-end justify-center w-full">
                <div className="flex flex-col items-start justify-start w-full">
                  <Text
                    className="text-white-A700 text-xl"
                    size="txtInterBold20"
                  >
                    <span className="text-white-A700 font-inter text-left text-base font-medium">
                      <>
                        Modern Office Automation
                        <br />
                      </>
                    </span>
                    <span className="md:text-[34px] sm:text-[32px] text-white-A700 font-inter text-left text-4xl font-bold">
                      Site Visiting
                    </span>
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start pb-3 w-full">
                  <Text
                    className="max-w-[799px] md:max-w-full text-2xl md:text-[22px] text-gray-50_01 sm:text-xl"
                    size="txtInterSemiBold24"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua.
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start pb-3 w-full">
                  <Text
                    className="max-w-[799px] md:max-w-full text-2xl md:text-[22px] text-gray-50_01 sm:text-xl"
                    size="txtInterSemiBold24"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua.
                  </Text>
                </div>
              </div>
            </div>
          </div>
          <div className="font-cardo md:h-[416px] h-[417px] max-w-[1240px] mx-auto md:px-10 sm:px-5 py-[30px] relative w-full">
            <div className="md:h-[416px] h-[417px] m-auto w-full">
              <div className="absolute bg-white-A700 h-[416px] inset-[0] m-auto w-full"></div>
              <div className="absolute bottom-[0] flex flex-col items-end justify-center right-[0] w-full">
                <div className="flex flex-col items-end justify-center w-full">
                  <div className="flex flex-col gap-3 items-start justify-start w-full">
                    <div className="flex flex-col items-start justify-start w-full">
                      <Text
                        className="md:text-5xl text-7xl text-gray-800"
                        size="txtCardoBold72Gray800"
                      >
                        <span className="text-gray-800 font-inter text-left text-base font-medium">
                          <>
                            Modern Office Automation
                            <br />
                          </>
                        </span>
                        <span className="md:text-[34px] sm:text-[32px] text-gray-800 font-inter text-left text-4xl font-bold">
                          Product Training
                        </span>
                      </Text>
                    </div>
                    <div className="flex flex-col font-inter items-start justify-start pb-3 w-full">
                      <Text
                        className="max-w-[799px] md:max-w-full text-2xl md:text-[22px] text-gray-800_02 sm:text-xl"
                        size="txtInterMedium24"
                      >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore
                        magna aliqua.
                      </Text>
                    </div>
                    <div className="flex md:flex-col flex-row font-inter md:gap-10 items-start justify-between w-full">
                      <div className="flex flex-1 flex-col items-start justify-start max-w-[799px] pb-3 w-full">
                        <Text
                          className="max-w-[799px] md:max-w-full text-2xl md:text-[22px] text-gray-800_02 sm:text-xl"
                          size="txtInterMedium24"
                        >
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit, sed do eiusmod tempor incididunt ut labore et
                          dolore magna aliqua.
                        </Text>
                      </div>
                      <div className="flex md:flex-1 flex-col justify-start md:mt-0 mt-[38px] w-[10%] md:w-full">
                        <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] w-[1%]"></div>
                        <div className="bg-light_blue-700_5e h-10 mt-[9px] mx-auto rounded-lg w-10"></div>
                        <div className="bg-light_blue-700 h-px mr-[101px] mt-[71px] w-[13%]"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <Img
              className="absolute h-[356px] inset-y-[0] my-auto object-cover right-[14%] w-[321px]"
              src="images/img_manchattingon.png"
              alt="manchattingon"
            />
          </div>
          <div className="font-inter md:h-[416px] h-[421px] md:px-10 sm:px-5 px-[60px] py-[30px] relative w-[1340px] md:w-full">
            <div className="absolute bg-gradient2  flex flex-col h-max inset-y-[0] items-center justify-end left-[0] max-w-[1240px] my-auto md:px-10 sm:px-5 px-[60px] py-[30px] rounded-[20px] w-full">
              <Img
                className="h-[356px] md:h-auto object-cover w-[321px]"
                src="images/img_manrepairsthe.png"
                alt="manrepairsthe"
              />
            </div>
            <div className="absolute bottom-[0] flex flex-col items-end justify-center right-[0] w-full">
              <div className="flex flex-col gap-2 items-end justify-center w-full">
                <div className="flex flex-col items-start justify-start w-full">
                  <Text
                    className="text-white-A700 text-xl"
                    size="txtInterBold20"
                  >
                    <span className="text-white-A700 font-inter text-left text-base font-medium">
                      <>
                        Modern Office Automation
                        <br />
                      </>
                    </span>
                    <span className="md:text-[34px] sm:text-[32px] text-white-A700 font-inter text-left text-4xl font-bold">
                      Machine Repair
                    </span>
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start pb-3 w-full">
                  <Text
                    className="max-w-[799px] md:max-w-full text-2xl md:text-[22px] text-gray-50_01 sm:text-xl"
                    size="txtInterSemiBold24"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua.
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start pb-3 w-full">
                  <Text
                    className="max-w-[799px] md:max-w-full text-2xl md:text-[22px] text-gray-50_01 sm:text-xl"
                    size="txtInterSemiBold24"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua.
                  </Text>
                </div>
              </div>
            </div>
          </div>
          <div className="font-cardo md:h-[416px] h-[417px] max-w-[1240px] mx-auto md:px-10 sm:px-5 py-[30px] relative w-full">
            <div className="md:h-[416px] h-[417px] m-auto w-full">
              <div className="absolute bg-white-A700 h-[416px] inset-[0] m-auto w-full"></div>
              <div className="absolute bottom-[0] flex flex-col items-end justify-center right-[0] w-full">
                <div className="flex flex-col items-end justify-center w-full">
                  <div className="flex flex-col gap-3 items-start justify-start w-full">
                    <div className="flex flex-col items-start justify-start w-full">
                      <Text
                        className="md:text-5xl text-7xl text-gray-800"
                        size="txtCardoBold72Gray800"
                      >
                        <span className="text-gray-800 font-inter text-left text-base font-medium">
                          <>
                            Modern Office Automation
                            <br />
                          </>
                        </span>
                        <span className="md:text-[34px] sm:text-[32px] text-gray-800 font-inter text-left text-4xl font-bold">
                          Product Training
                        </span>
                      </Text>
                    </div>
                    <div className="flex flex-col font-inter items-start justify-start pb-3 w-full">
                      <Text
                        className="max-w-[799px] md:max-w-full text-2xl md:text-[22px] text-gray-800_02 sm:text-xl"
                        size="txtInterMedium24"
                      >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore
                        magna aliqua.
                      </Text>
                    </div>
                    <div className="flex md:flex-col flex-row font-inter md:gap-10 items-start justify-between w-full">
                      <div className="flex flex-1 flex-col items-start justify-start max-w-[799px] pb-3 w-full">
                        <Text
                          className="max-w-[799px] md:max-w-full text-2xl md:text-[22px] text-gray-800_02 sm:text-xl"
                          size="txtInterMedium24"
                        >
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit, sed do eiusmod tempor incididunt ut labore et
                          dolore magna aliqua.
                        </Text>
                      </div>
                      <div className="flex md:flex-1 flex-col justify-start md:mt-0 mt-[38px] w-[10%] md:w-full">
                        <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] w-[1%]"></div>
                        <div className="bg-light_blue-700_5e h-10 mt-[9px] mx-auto rounded-lg w-10"></div>
                        <div className="bg-light_blue-700 h-px mr-[101px] mt-[71px] w-[13%]"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <Img
              className="absolute h-[356px] inset-y-[0] my-auto object-cover right-[14%] w-[321px]"
              src="images/img_onlinemeetings.png"
              alt="onlinemeetings"
            />
          </div>
          <div className="font-inter md:h-[416px] h-[421px] md:px-10 sm:px-5 px-[60px] py-[30px] relative w-[1340px] md:w-full">
            <div className="absolute bg-gradient2  flex flex-col h-max inset-y-[0] items-center justify-end left-[0] max-w-[1240px] my-auto md:px-10 sm:px-5 px-[60px] py-[30px] rounded-[20px] w-full">
              <Img
                className="h-[356px] md:h-auto object-cover w-[321px]"
                src="images/img_gamingsetup.png"
                alt="gamingsetup"
              />
            </div>
            <div className="absolute bottom-[0] flex flex-col items-end justify-center right-[0] w-full">
              <div className="flex flex-col gap-2 items-end justify-center w-full">
                <div className="flex flex-col items-start justify-start w-full">
                  <Text
                    className="text-white-A700 text-xl"
                    size="txtInterBold20"
                  >
                    <span className="text-white-A700 font-inter text-left text-base font-medium">
                      <>
                        Modern Office Automation
                        <br />
                      </>
                    </span>
                    <span className="md:text-[34px] sm:text-[32px] text-white-A700 font-inter text-left text-4xl font-bold">
                      Machine Installing
                    </span>
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start pb-3 w-full">
                  <Text
                    className="max-w-[799px] md:max-w-full text-2xl md:text-[22px] text-gray-50_01 sm:text-xl"
                    size="txtInterSemiBold24"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua.
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start pb-3 w-full">
                  <Text
                    className="max-w-[799px] md:max-w-full text-2xl md:text-[22px] text-gray-50_01 sm:text-xl"
                    size="txtInterSemiBold24"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua.
                  </Text>
                </div>
              </div>
            </div>
          </div>
          <div className="font-cardo md:h-[416px] h-[417px] max-w-[1240px] mx-auto md:px-10 sm:px-5 py-[30px] relative w-full">
            <div className="md:h-[416px] h-[417px] m-auto w-full">
              <div className="absolute bg-white-A700 h-[416px] inset-[0] m-auto w-full"></div>
              <div className="absolute bottom-[0] flex flex-col items-end justify-center right-[0] w-full">
                <div className="flex flex-col items-end justify-center w-full">
                  <div className="flex flex-col gap-3 items-start justify-start w-full">
                    <div className="flex flex-col items-start justify-start w-full">
                      <Text
                        className="md:text-5xl text-7xl text-gray-800"
                        size="txtCardoBold72Gray800"
                      >
                        <span className="text-gray-800 font-inter text-left text-base font-medium">
                          <>
                            Modern Office Automation
                            <br />
                          </>
                        </span>
                        <span className="md:text-[34px] sm:text-[32px] text-gray-800 font-inter text-left text-4xl font-bold">
                          Product Training
                        </span>
                      </Text>
                    </div>
                    <div className="flex flex-col font-inter items-start justify-start pb-3 w-full">
                      <Text
                        className="max-w-[799px] md:max-w-full text-2xl md:text-[22px] text-gray-800_02 sm:text-xl"
                        size="txtInterMedium24"
                      >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore
                        magna aliqua.
                      </Text>
                    </div>
                    <div className="flex md:flex-col flex-row font-inter md:gap-10 items-start justify-between w-full">
                      <div className="flex flex-1 flex-col items-start justify-start max-w-[799px] pb-3 w-full">
                        <Text
                          className="max-w-[799px] md:max-w-full text-2xl md:text-[22px] text-gray-800_02 sm:text-xl"
                          size="txtInterMedium24"
                        >
                          Lorem ipsum dolor sit amet, consectetur adipiscing
                          elit, sed do eiusmod tempor incididunt ut labore et
                          dolore magna aliqua.
                        </Text>
                      </div>
                      <div className="flex md:flex-1 flex-col justify-start md:mt-0 mt-[38px] w-[10%] md:w-full">
                        <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] w-[1%]"></div>
                        <div className="bg-light_blue-700_5e h-10 mt-[9px] mx-auto rounded-lg w-10"></div>
                        <div className="bg-light_blue-700 h-px mr-[101px] mt-[71px] w-[13%]"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <Img
              className="absolute h-[356px] inset-y-[0] my-auto object-cover right-[14%] w-[321px]"
              src="images/img_techsupport.png"
              alt="techsupport"
            />
          </div>
        </div>
        <div className="bg-white-A700 flex flex-col font-cardo items-center justify-start max-w-[1439px] md:px-10 sm:px-5 px-[100px] py-5 w-full">
          <div className="flex flex-col items-start justify-start max-w-[1233px] mx-auto w-full">
            <div className="flex flex-col items-start justify-start w-full">
              <div className="border-b-2 border-gray-800 border-solid flex flex-col items-start justify-start pb-[35px] w-full">
                <Text
                  className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                  size="txtCardoRegular24Gray80001"
                >
                  Our experienced technical department has been well trained,
                  handled several situations that require experience and
                  knowledge to resolve. We are very proud because our technical
                  department has solved all the problems faced by customers.
                  Regardless of machine repair, software training and many more.
                  Apart from that. All encouraging feedback from customers is
                  highly appreciated, because this proves that our technical
                  department is one of the best.
                </Text>
              </div>
            </div>
          </div>
        </div>
        <Footer className="bg-white-A700 border-gray-400_01 border-solid border-t flex font-raleway gap-5 items-center justify-center md:px-5 px-[100px] py-10 w-full" />
      </div>
    </>
  );
};

export default OurservicesPage;
