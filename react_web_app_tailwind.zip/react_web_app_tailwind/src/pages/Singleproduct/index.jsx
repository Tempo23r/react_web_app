import React from "react";

import { Button, Img, Input, List, Text } from "components";
import Header from "components/Header";
import SingleProductColumnTwo from "components/SingleProductColumnTwo";
import Footer from "components/Footer";


const SingleproductPage = () => {
  const [frame115value, setFrame115value] = React.useState("");

  return (
    <>
      <div className="bg-white-A700 flex flex-col font-raleway items-center justify-start mx-auto w-full">
        <Header className="bg-gray-50_01 flex md:flex-col md:gap-5 items-center justify-center pb-1 md:px-5 w-full" />
        <div className="flex md:flex-col flex-row font-roboto gap-5 items-start justify-start mt-[35px] md:px-10 sm:px-5 px-[100px] w-auto md:w-full">
          <div className="h-[574px] relative w-1/2 md:w-full">
            <Img
              className="h-[574px] m-auto object-cover rounded-[20px] w-full"
              src="images/img_rectangle1231.png"
              alt="rectangle1231"
            />
            <div className="absolute bottom-[0] flex sm:flex-col flex-row gap-2 h-[117px] md:h-auto inset-x-[0] items-center justify-center mx-auto w-[550px] md:w-full">
              <Img
                className="h-[80px] md:h-auto object-cover rounded-[16px] w-[80px]"
                src="images/img_rectangle1232.png"
                alt="rectangle1232"
              />
              <Img
                className="h-[80px] md:h-auto object-cover rounded-[16px] w-[80px]"
                src="images/img_rectangle1233.png"
                alt="rectangle1233"
              />
              <Img
                className="h-[80px] md:h-auto object-cover rounded-[16px] w-[80px]"
                src="images/img_rectangle1232.png"
                alt="rectangle1234"
              />
              <Img
                className="h-[80px] md:h-auto object-cover rounded-[16px] w-[80px]"
                src="images/img_rectangle1235.png"
                alt="rectangle1235"
              />
              <Img
                className="h-[80px] md:h-auto object-cover rounded-[16px] w-[80px]"
                src="images/img_rectangle1233.png"
                alt="rectangle1236"
              />
            </div>
          </div>
          <div className="flex flex-col gap-3 h-[574px] md:h-auto items-start justify-start w-[609px] md:w-full">
            <div className="flex flex-col gap-2 items-start justify-start w-[609px] md:w-full">
              <Button
                className="capitalize cursor-pointer leading-[normal] min-w-[135px] text-base text-center"
                shape="round"
                color="gray_800"
                size="xs"
                variant="outline"
              >
                Category Name
              </Button>
              <Text
                className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-auto"
                size="txtRobotoRomanBold24"
              >
                Lorem ipsum dolor sit amet
              </Text>
              <div className="flex flex-row font-cardo gap-1 items-center justify-center w-auto">
                <Img
                  className="h-4 w-4"
                  src="images/img_favorite.svg"
                  alt="favorite"
                />
                <Text
                  className="text-base text-gray-800_01 w-auto"
                  size="txtCardoRegular16"
                >
                  <>\&#96;(4.9) 2.5K Reviews</>
                </Text>
              </div>
            </div>
            <div className="flex flex-col font-cardo gap-[15px] h-[318px] md:h-auto items-start justify-center w-full">
              <div className="flex flex-col items-start justify-start w-full">
                <Text
                  className="max-w-[609px] md:max-w-full text-gray-800_01 text-xl"
                  size="txtCardoRegular20Gray80001"
                >
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco
                  laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                  irure dolor in reprehenderit in voluptate velit esse cillum
                  dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                  cupidatat non proident, sunt in culpa qui officia deserunt
                  mollit anim id est laborum.
                </Text>
              </div>
              <div className="flex flex-col font-roboto gap-5 items-start justify-start w-auto">
                <Text
                  className="text-gray-800_01 text-xl w-auto"
                  size="txtRobotoRomanBold20"
                >
                  4 Color Available
                </Text>
                <Img
                  className="h-6 w-[120px]"
                  src="images/img_frame305.svg"
                  alt="frame305"
                />
              </div>
            </div>
            <div className="flex flex-col font-roboto gap-3 items-start justify-start w-full">
              <div className="flex flex-col gap-3 items-start justify-center w-auto">
                <Text
                  className="line-through text-gray-800_01 text-xl w-auto"
                  size="txtRobotoRomanBold20"
                >
                  $123
                </Text>
                <Text
                  className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-auto"
                  size="txtRobotoRomanBold24"
                >
                  $123
                </Text>
              </div>
              <div className="flex md:flex-col flex-row font-raleway gap-[9px] items-start justify-start w-full">
                <Button
                  className="cursor-pointer flex-1 font-semibold leading-[normal] rounded-[26px] text-center text-xl w-full"
                  color="gray_800_01"
                  size="md"
                  variant="fill"
                >
                  Buy Now
                </Button>
                <Button
                  className="!text-gray-800 border border-gray-800 border-solid cursor-pointer flex-1 font-semibold leading-[normal] rounded-[26px] text-center text-xl w-full"
                  color="white_A700"
                  size="md"
                  variant="fill"
                >
                  Add to Cart
                </Button>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col font-roboto items-start justify-start max-w-[1238px] mt-[41px] mx-auto md:px-5 w-full">
          <SingleProductColumnTwo className="flex flex-col items-start justify-start rounded-[20px] w-auto md:w-full" />
        </div>
        <div className="bg-gray-50_02 flex flex-col font-roboto md:gap-10 gap-[60px] items-center justify-center max-w-[1439px] mt-[41px] md:px-10 sm:px-5 px-[100px] py-[60px] w-full">
          <div className="flex flex-col gap-10 items-start justify-start max-w-[1239px] mx-auto w-full">
            <div className="md:h-[33px] h-[35px] pb-3 relative w-[939px] md:w-full">
              <div className="absolute border-b border-black-900 border-solid bottom-[2%] h-[33px] inset-x-[0] mx-auto w-full"></div>
              <Text
                className="absolute left-[0] text-gray-800 text-xl top-[0] w-auto"
                size="txtRobotoRomanSemiBold20Gray800"
              >
                Product Details
              </Text>
            </div>
            <div className="flex md:flex-col flex-row gap-10 items-center justify-start w-auto md:w-full">
              <Img
                className="h-[417px] sm:h-auto object-cover rounded-[20px] w-[310px] md:w-full"
                src="images/img_rectangle1232_417x310.png"
                alt="rectangle1232_One"
              />
              <div className="flex flex-col gap-10 items-start justify-start w-auto">
                <div className="flex flex-col gap-6 items-start justify-start w-auto">
                  <div className="flex flex-col gap-1 items-start justify-start w-auto">
                    <Text
                      className="text-5xl sm:text-[38px] md:text-[44px] text-gray-900_02 w-auto"
                      size="txtRobotoRomanSemiBold48"
                    >
                      4.5
                    </Text>
                    <Text
                      className="text-2xl md:text-[22px] text-gray-900_02 sm:text-xl w-auto"
                      size="txtRobotoRomanSemiBold24"
                    >
                      Based on 123 Reviews
                    </Text>
                  </div>
                  <div className="flex flex-row gap-3 items-center justify-start w-auto">
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal"
                    />
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal_One"
                    />
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal_Two"
                    />
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal_Three"
                    />
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal_Four"
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-3 items-center justify-start w-auto">
                  <div className="flex flex-row gap-10 items-center justify-center w-auto">
                    <Text
                      className="text-gray-700 text-xl w-auto"
                      size="txtRobotoRomanMedium20Gray700"
                    >
                      5 Star
                    </Text>
                    <Img
                      className="h-2.5 md:h-auto object-cover w-[220px]"
                      src="images/img_line15.png"
                      alt="lineFifteen"
                    />
                  </div>
                  <div className="flex flex-row gap-10 items-center justify-center w-auto">
                    <Text
                      className="text-gray-700 text-xl w-auto"
                      size="txtRobotoRomanMedium20Gray700"
                    >
                      4 Star
                    </Text>
                    <Img
                      className="h-2.5 md:h-auto object-cover w-[220px]"
                      src="images/img_line15.png"
                      alt="lineNineteen"
                    />
                  </div>
                  <div className="flex flex-row gap-10 items-center justify-center w-auto">
                    <Text
                      className="text-gray-700 text-xl w-auto"
                      size="txtRobotoRomanMedium20Gray700"
                    >
                      3 Star
                    </Text>
                    <Img
                      className="h-2.5 md:h-auto object-cover w-[220px]"
                      src="images/img_line15.png"
                      alt="lineTwenty"
                    />
                  </div>
                  <div className="flex flex-row gap-10 items-center justify-center w-auto">
                    <Text
                      className="text-gray-700 text-xl w-auto"
                      size="txtRobotoRomanMedium20Gray700"
                    >
                      2 Star
                    </Text>
                    <Img
                      className="h-2.5 md:h-auto object-cover w-[220px]"
                      src="images/img_line15.png"
                      alt="lineSeventeen"
                    />
                  </div>
                  <div className="flex flex-row gap-10 items-center justify-center w-auto">
                    <Text
                      className="text-gray-700 text-xl w-auto"
                      size="txtRobotoRomanMedium20Gray700"
                    >
                      1 Star
                    </Text>
                    <Img
                      className="h-2.5 md:h-auto object-cover w-[220px]"
                      src="images/img_line15.png"
                      alt="lineEighteen"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-10 items-end justify-start max-w-[1239px] mx-auto w-full">
            <div className="h-[35px] pb-3 relative w-full">
              <div className="absolute h-[33px] md:h-[35px] inset-[0] justify-center m-auto w-full">
                <div className="border-b border-black-900 border-solid h-[35px] m-auto w-full"></div>
                <Text
                  className="absolute left-[6%] text-gray-800 text-xl top-[0] w-auto"
                  size="txtRobotoRomanSemiBold20Gray800"
                >
                  ( 12 )
                </Text>
              </div>
              <Text
                className="absolute left-[0] text-gray-800 text-xl top-[0] w-auto"
                size="txtRobotoRomanSemiBold20Gray800"
              >
                Reviews{" "}
              </Text>
            </div>
            <List
              className="flex flex-col gap-10 items-start max-w-[1239px] w-full"
              orientation="vertical"
            >
              <div className="bg-white-A700 flex flex-1 flex-col gap-5 items-end justify-center my-0 sm:px-5 px-6 py-4 rounded-[12px] shadow-bs1 w-full">
                <div className="flex flex-row gap-5 items-center justify-start w-full">
                  <div className="flex flex-row gap-3 items-center justify-start w-auto">
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal"
                    />
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal_One"
                    />
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal_Two"
                    />
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal_Three"
                    />
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal_Four"
                    />
                  </div>
                  <Text
                    className="text-base text-black-900_99 text-center w-auto"
                    size="txtRobotoRomanRegular16Black90099"
                  >
                    2 Days Ago
                  </Text>
                </div>
                <Text
                  className="text-gray-900 text-xl w-full"
                  size="txtRobotoRomanBold20Gray900"
                >
                  Lorem Ipsum dolor sit amet
                </Text>
                <Text
                  className="max-w-[1191px] md:max-w-full text-base text-gray-600_01"
                  size="txtRobotoRomanMedium16"
                >
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco
                  laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                  irure dolor in reprehenderit in voluptate velit esse cillum
                  dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                  cupidatat non proident, sunt in culpa qui officia deserunt
                  mollit anim id est laborum.
                </Text>
                <div className="flex flex-row gap-5 items-center justify-center w-auto">
                  <Text
                    className="text-center text-gray-800 text-xl w-auto"
                    size="txtRobotoRomanSemiBold20Gray800"
                  >
                    Lorem Ipsum
                  </Text>
                  <Img
                    className="h-[50px] md:h-auto rounded-[50%] w-[50px]"
                    src="images/img_rectangle1251.png"
                    alt="rectangle1251"
                  />
                </div>
              </div>
              <div className="bg-white-A700 flex flex-1 flex-col gap-5 items-end justify-center my-0 sm:px-5 px-6 py-4 rounded-[12px] shadow-bs1 w-full">
                <div className="flex flex-row gap-5 items-center justify-start w-full">
                  <div className="flex flex-row gap-3 items-center justify-start w-auto">
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal"
                    />
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal_One"
                    />
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal_Two"
                    />
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal_Three"
                    />
                    <Img
                      className="h-6 w-6"
                      src="images/img_signal.svg"
                      alt="signal_Four"
                    />
                  </div>
                  <Text
                    className="text-base text-black-900_99 text-center w-auto"
                    size="txtRobotoRomanRegular16Black90099"
                  >
                    02nd Dec 2023
                  </Text>
                </div>
                <Text
                  className="text-gray-900 text-xl w-full"
                  size="txtRobotoRomanBold20Gray900"
                >
                  Lorem Ipsum dolor sit amet
                </Text>
                <Text
                  className="max-w-[1191px] md:max-w-full text-base text-gray-600_01"
                  size="txtRobotoRomanMedium16"
                >
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco
                  laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                  irure dolor in reprehenderit in voluptate velit esse cillum
                  dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                  cupidatat non proident, sunt in culpa qui officia deserunt
                  mollit anim id est laborum.
                </Text>
                <div className="flex flex-row gap-5 items-center justify-center w-auto">
                  <Text
                    className="text-center text-gray-800 text-xl w-auto"
                    size="txtRobotoRomanSemiBold20Gray800"
                  >
                    Lorem Ipsum
                  </Text>
                  <Img
                    className="h-[50px] md:h-auto rounded-[50%] w-[50px]"
                    src="images/img_rectangle1251.png"
                    alt="rectangle1251"
                  />
                </div>
              </div>
            </List>
          </div>
          <Button
            className="cursor-pointer font-bold leading-[normal] min-w-[121px] rounded-[23px] text-center text-xl"
            color="light_blue_700"
            size="sm"
            variant="outline"
          >
            View All
          </Button>
        </div>
        <div className="bg-gray-100 flex flex-col font-roboto gap-5 h-[961px] md:h-auto items-start justify-start max-w-[1439px] md:px-10 sm:px-5 px-[100px] py-10 w-full">
          <div className="flex sm:flex-col flex-row gap-5 items-start justify-between max-w-[1239px] mx-auto w-full">
            <div className="flex flex-col items-start justify-start py-3 w-auto">
              <Text
                className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-auto"
                size="txtRobotoRomanBold24"
              >
                Similar Products
              </Text>
            </div>
            <Button
              className="cursor-pointer font-bold leading-[normal] min-w-[154px] rounded-[26px] text-2xl md:text-[22px] text-center sm:text-xl"
              color="light_blue_700"
              size="sm"
              variant="outline"
            >
              View Shop
            </Button>
          </div>
          <div className="font-raleway gap-5 grid sm:grid-cols-1 md:grid-cols-2 grid-cols-4 justify-center max-w-[1240px] min-h-[auto] mx-auto w-full">
            <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
              <Img
                className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                src="images/img_rectangle87.png"
                alt="rectangleEightySeven"
              />
              <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                <Text
                  className="text-gray-800_01 text-xl w-full"
                  size="txtRalewayRomanBold20"
                >
                  Lorem ipsum dolor sit amet
                </Text>
                <div className="flex flex-row font-roboto items-center justify-between w-full">
                  <div className="flex flex-row gap-2 items-center justify-start w-auto">
                    <Text
                      className="line-through text-base text-black-900_99 w-auto"
                      size="txtRobotoRomanSemiBold16"
                    >
                      $653
                    </Text>
                    <Text
                      className="text-gray-800_01 text-xl w-auto"
                      size="txtRobotoRomanSemiBold20"
                    >
                      $623
                    </Text>
                  </div>
                  <Img
                    className="h-6 w-[78px]"
                    src="images/img_user.svg"
                    alt="user"
                  />
                </div>
              </div>
            </div>
            <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
              <Img
                className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                src="images/img_rectangle87.png"
                alt="rectangleEightySeven"
              />
              <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                <Text
                  className="text-gray-800_01 text-xl w-full"
                  size="txtRalewayRomanBold20"
                >
                  Lorem ipsum dolor sit amet
                </Text>
                <div className="flex flex-row font-roboto items-center justify-between w-full">
                  <div className="flex flex-row gap-2 items-center justify-start w-auto">
                    <Text
                      className="line-through text-base text-black-900_99 w-auto"
                      size="txtRobotoRomanSemiBold16"
                    >
                      $653
                    </Text>
                    <Text
                      className="text-gray-800_01 text-xl w-auto"
                      size="txtRobotoRomanSemiBold20"
                    >
                      $623
                    </Text>
                  </div>
                  <Img
                    className="h-6 w-[78px]"
                    src="images/img_user.svg"
                    alt="user"
                  />
                </div>
              </div>
            </div>
            <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
              <Img
                className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                src="images/img_rectangle87.png"
                alt="rectangleEightySeven"
              />
              <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                <Text
                  className="text-gray-800_01 text-xl w-full"
                  size="txtRalewayRomanBold20"
                >
                  Lorem ipsum dolor sit amet
                </Text>
                <div className="flex flex-row font-roboto items-center justify-between w-full">
                  <div className="flex flex-row gap-2 items-center justify-start w-auto">
                    <Text
                      className="line-through text-base text-black-900_99 w-auto"
                      size="txtRobotoRomanSemiBold16"
                    >
                      $653
                    </Text>
                    <Text
                      className="text-gray-800_01 text-xl w-auto"
                      size="txtRobotoRomanSemiBold20"
                    >
                      $623
                    </Text>
                  </div>
                  <Img
                    className="h-6 w-[78px]"
                    src="images/img_user.svg"
                    alt="user"
                  />
                </div>
              </div>
            </div>
            <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
              <Img
                className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                src="images/img_rectangle87.png"
                alt="rectangleEightySeven"
              />
              <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                <Text
                  className="text-gray-800_01 text-xl w-full"
                  size="txtRalewayRomanBold20"
                >
                  Lorem ipsum dolor sit amet
                </Text>
                <div className="flex flex-row font-roboto items-center justify-between w-full">
                  <div className="flex flex-row gap-2 items-center justify-start w-auto">
                    <Text
                      className="line-through text-base text-black-900_99 w-auto"
                      size="txtRobotoRomanSemiBold16"
                    >
                      $653
                    </Text>
                    <Text
                      className="text-gray-800_01 text-xl w-auto"
                      size="txtRobotoRomanSemiBold20"
                    >
                      $623
                    </Text>
                  </div>
                  <Img
                    className="h-6 w-[78px]"
                    src="images/img_user.svg"
                    alt="user"
                  />
                </div>
              </div>
            </div>
            <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
              <Img
                className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                src="images/img_rectangle87.png"
                alt="rectangleEightySeven"
              />
              <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                <Text
                  className="text-gray-800_01 text-xl w-full"
                  size="txtRalewayRomanBold20"
                >
                  Lorem ipsum dolor sit amet
                </Text>
                <div className="flex flex-row font-roboto items-center justify-between w-full">
                  <div className="flex flex-row gap-2 items-center justify-start w-auto">
                    <Text
                      className="line-through text-base text-black-900_99 w-auto"
                      size="txtRobotoRomanSemiBold16"
                    >
                      $653
                    </Text>
                    <Text
                      className="text-gray-800_01 text-xl w-auto"
                      size="txtRobotoRomanSemiBold20"
                    >
                      $623
                    </Text>
                  </div>
                  <Img
                    className="h-6 w-[78px]"
                    src="images/img_user.svg"
                    alt="user"
                  />
                </div>
              </div>
            </div>
            <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
              <Img
                className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                src="images/img_rectangle87.png"
                alt="rectangleEightySeven"
              />
              <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                <Text
                  className="text-gray-800_01 text-xl w-full"
                  size="txtRalewayRomanBold20"
                >
                  Lorem ipsum dolor sit amet
                </Text>
                <div className="flex flex-row font-roboto items-center justify-between w-full">
                  <div className="flex flex-row gap-2 items-center justify-start w-auto">
                    <Text
                      className="line-through text-base text-black-900_99 w-auto"
                      size="txtRobotoRomanSemiBold16"
                    >
                      $653
                    </Text>
                    <Text
                      className="text-gray-800_01 text-xl w-auto"
                      size="txtRobotoRomanSemiBold20"
                    >
                      $623
                    </Text>
                  </div>
                  <Img
                    className="h-6 w-[78px]"
                    src="images/img_user.svg"
                    alt="user"
                  />
                </div>
              </div>
            </div>
            <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
              <Img
                className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                src="images/img_rectangle87.png"
                alt="rectangleEightySeven"
              />
              <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                <Text
                  className="text-gray-800_01 text-xl w-full"
                  size="txtRalewayRomanBold20"
                >
                  Lorem ipsum dolor sit amet
                </Text>
                <div className="flex flex-row font-roboto items-center justify-between w-full">
                  <div className="flex flex-row gap-2 items-center justify-start w-auto">
                    <Text
                      className="line-through text-base text-black-900_99 w-auto"
                      size="txtRobotoRomanSemiBold16"
                    >
                      $653
                    </Text>
                    <Text
                      className="text-gray-800_01 text-xl w-auto"
                      size="txtRobotoRomanSemiBold20"
                    >
                      $623
                    </Text>
                  </div>
                  <Img
                    className="h-6 w-[78px]"
                    src="images/img_user.svg"
                    alt="user"
                  />
                </div>
              </div>
            </div>
            <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
              <Img
                className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                src="images/img_rectangle87.png"
                alt="rectangleEightySeven"
              />
              <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                <Text
                  className="text-gray-800_01 text-xl w-full"
                  size="txtRalewayRomanBold20"
                >
                  Lorem ipsum dolor sit amet
                </Text>
                <div className="flex flex-row font-roboto items-center justify-between w-full">
                  <div className="flex flex-row gap-2 items-center justify-start w-auto">
                    <Text
                      className="line-through text-base text-black-900_99 w-auto"
                      size="txtRobotoRomanSemiBold16"
                    >
                      $653
                    </Text>
                    <Text
                      className="text-gray-800_01 text-xl w-auto"
                      size="txtRobotoRomanSemiBold20"
                    >
                      $623
                    </Text>
                  </div>
                  <Img
                    className="h-6 w-[78px]"
                    src="images/img_user.svg"
                    alt="user"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer className="bg-white-A700 border-gray-400_01 border-solid border-t flex gap-5 items-center justify-center md:px-5 px-[100px] py-10 w-full" />

      </div>
    </>
  );
};

export default SingleproductPage;
