import React from "react";

import { Button, Img, Input, Text } from "components";
import Footer from "components/Footer";
import Header1 from "components/Header1";

const AboutusPage = () => {
  const [frame115value, setFrame115value] = React.useState("");

  return (
    <>
      <div className="bg-white-A700 flex flex-col font-cardo items-center justify-start mx-auto w-full">
        <div
          className="bg-cover bg-no-repeat flex flex-col h-[800px] items-center justify-start pb-[181px] w-full"
          style={{ backgroundImage: "url('images/img_frame188.png')" }}
        >
          <Header1 className="flex flex-col font-cardo items-center justify-center md:px-5 w-full" />
          <div className="flex flex-col font-cardo items-center justify-center mt-[151px] md:px-5 w-auto sm:w-full">
            <Text
              className="md:text-5xl text-7xl text-center text-white-A700 tracking-[2.16px] uppercase w-auto"
              size="txtCardoBold72"
            >
              About us
            </Text>
          </div>
          <div className="flex flex-col font-raleway gap-3.5 items-center justify-start mt-4 md:px-5 px-[63px]">
            <a
              href="www.modernoffice.online"
              className="text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl"
              target="_blank"
              rel="noreferrer"
            >
              <Text size="txtRalewayRomanBold24">www.modernoffice.online</Text>
            </a>
            <Text
              className="capitalize text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl"
              size="txtRalewayRomanMedium24"
            >
              Largest and Best online office automation store in sri lanka
            </Text>
          </div>
          <Button
            className="cursor-pointer flex items-center justify-center min-w-[214px] mt-[60px] rounded-[21px]"
            leftIcon={
              <Img
                className="h-6 mt-px mb-1 mr-3"
                src="images/img_thumbsup.svg"
                alt="thumbs_up"
              />
            }
            color="white_A700"
            size="md"
            variant="fill"
          >
            <div className="font-bold font-raleway leading-[normal] md:text-[22px] sm:text-xl text-2xl text-center">
              Shop Now
            </div>
          </Button>
        </div>
        <div className="bg-gray-100 flex flex-col items-center justify-start max-w-[1439px] md:px-10 sm:px-5 px-[100px] py-[60px] w-full">
          <div className="flex flex-col items-start justify-start max-w-[1233px] mx-auto w-full">
            <div className="flex flex-col gap-2 items-start justify-start w-full">
            <Text 
                className="md:text-xl text-gray-830 w-max inset-x-[0]"
                size="txtCardoBold20"
              >
                <>
                Modern Office Automation
                </>
              </Text>
              <Text
                className="md:text-5xl text-7xl text-gray-800"
                size="txtCardoBold72Gray800"
              >
                <>
                  About Us
                </>
              </Text>
              <div className="relative w-full">
                <div className="absolute flex flex-col justify-start right-[1%] top-[15%] w-[154px]">
                  <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                  <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                  <div className="bg-light_blue-700 h-[15px] mr-[139px] mt-[71px] rounded-[3px] w-[15px]"></div>
                </div>
                <div className="flex flex-col items-center justify-start max-w-[1233px] mx-auto pb-[35px] relative w-full">
                  <Text
                    className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                    size="txtCardoRegular24Gray80001"
                  >
                    {" "}
                    We are an importer & distributor in all type of office
                    automation. The company was founded in year 2012, previously
                    known as MODERN OFFICE AUTOMATION. As a comprehensive one
                    stop supplier, our expertise are available to assist you in
                    making the optimal choice in your business with our 11
                    years’ experience (2012 – 2023) in the Office Automation.
                  </Text>
                </div>
                <div className="border-b-2 border-gray-800 border-solid flex flex-col items-center justify-start max-w-[1233px] mt-auto mx-auto pb-[35px] relative w-full">
                  <Text
                    className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                    size="txtCardoRegular24Gray80001"
                  >
                    <>
                      {" "}
                      A specialist in Time recorder attendance machine, Pass
                      Book Printers, Note Counting Machine, Safety Box, Paper
                      Shredder, Note Detector, Coin Sorter, Fingerprint Time
                      Attendance System, Guard tour system, Walkie Talkie,
                      Binding Machine, Cheque Writer, Laminator & etc. At the
                      same time, we have a series of home brand products, named
                      as BRAVO. It has established a certain degree of
                      reputation in the market and demand, it&#39;s also one of
                      the leading office
                    </>
                  </Text>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="bg-gray-50 flex flex-col items-center justify-end max-w-[1439px] md:px-10 sm:px-5 px-[100px] py-[60px] w-full">
          <div className="flex flex-col items-end justify-center max-w-[1233px] mx-auto w-full">
            <div className="flex flex-col gap-2 items-end justify-center w-full">
              <div className="flex sm:flex-col flex-row gap-2.5 items-start justify-start max-w-[1233px] md:px-10 sm:px-5 px-[100px] w-full">
                <Img
                  className="h-[103px] w-[77px]"
                  src="images/img_vuesaxboldquoteup.svg"
                  alt="vuesaxboldquote"
                />
                             <Text 
                className="md:text-xl text-gray-830 w-max inset-x-[0]"
                size="txtCardoBold20"
              >
                <>
                Modern Office Automation
                </>
              </Text>
              <br></br>
                <Text
                  className="md:text-5xl text-7xl text-gray-800"
                  size="txtCardoBold72Gray800"
                >
                  <>
                    Our Vision
                  </>
                </Text>
              </div>
              <div className="flex flex-col items-start justify-start max-w-[1127px] pb-3 w-full">
                <Text
                  className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-auto"
                  size="txtCardoRegular24Gray80001"
                >
                  The Largest One-Stop Office Equipment Supply Platform in Sri
                  Lanka.
                </Text>
              </div>
              <div className="relative w-[92%] md:w-full">
                <div className="absolute flex flex-col justify-start right-[1%] top-[0] w-[154px]">
                  <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                  <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                  <div className="bg-light_blue-700 h-[15px] mr-[139px] mt-[71px] rounded-[3px] w-[15px]"></div>
                </div>
                <div className="flex flex-col items-center justify-start max-w-[1127px] mt-0.5 mx-auto pb-3 relative w-full">
                  <Text
                    className="max-w-[1127px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                    size="txtCardoRegular24Gray80001"
                  >
                    <>
                      &quot;Providing a variety of office equipment for all
                      types of customers and dealers, to make it easier for them
                      to find their needs.&quot;
                    </>
                  </Text>
                </div>
                <div className="flex flex-col items-center justify-start max-w-[1127px] mt-auto mx-auto pb-3 relative w-full">
                  <Text
                    className="max-w-[1127px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                    size="txtCardoRegular24Gray80001"
                  >
                    <>
                      The First Choice for All Office Equipment Customers in The
                      Market “Provide all famous brands for office equipment,
                      and also add various types of office equipment categories
                      in sales, to provide a wide choice for customers.&quot;
                    </>
                  </Text>
                </div>
              </div>
              <div className="flex flex-col items-start justify-start max-w-[1127px] pb-3 w-full">
                <Text
                  className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-auto"
                  size="txtCardoRegular24Gray80001"
                >
                  A Platform for Employees to Pursue Their Dreams
                </Text>
              </div>
              <div className="border-b-2 border-gray-800 border-solid flex md:flex-col flex-row md:gap-5 items-end justify-end pb-[35px] w-full">
                <Text
                  className="max-w-[1051px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                  size="txtCardoRegular24Gray80001"
                >
                  <>
                    &quot;The future of the employee will be prioritized, thus
                    by providing a comfortable work place, a positive working
                    atmosphere, and long-term goals that are drawn up together
                    with the employee and employer, will make this goal
                    achieved.&quot;
                  </>
                </Text>
                <Img
                  className="h-[103px] w-[77px]"
                  src="images/img_vuesaxboldquoteup.svg"
                  alt="vuesaxboldquote_One"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="bg-gray-50 flex flex-col items-center justify-end max-w-[1439px] md:px-10 sm:px-5 px-[100px] py-[60px] w-full">
          <div className="flex flex-col items-end justify-center max-w-[1233px] mx-auto w-full">
            <div className="flex flex-col gap-2 items-end justify-center w-full">
              <div className="flex sm:flex-col flex-row gap-2.5 items-start justify-start max-w-[1233px] md:px-10 sm:px-5 px-[100px] w-full">
                <Img
                  className="h-[103px] w-[77px]"
                  src="images/img_vuesaxboldquoteup.svg"
                  alt="vuesaxboldquote_Two"
                />
                             <Text 
                className="md:text-xl text-gray-830 w-max inset-x-[0]"
                size="txtCardoBold20"
              >
                <>
                Modern Office Automation
                </>
              </Text>
                <Text
                  className="md:text-5xl text-7xl text-gray-800"
                  size="txtCardoBold72Gray800"
                >
                  <>
                    <br />
                    Our Mission
                  </>
                </Text>
              </div>
              <div className="relative w-[92%] md:w-full">
                <div className="absolute bottom-[3%] flex flex-col justify-start right-[1%] w-[154px]">
                  <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                  <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                  <div className="bg-light_blue-700 h-[15px] mr-[139px] mt-[71px] rounded-[3px] w-[15px]"></div>
                </div>
                <div className="flex flex-col items-center justify-start max-w-[1127px] mx-auto pb-3 relative w-full">
                  <Text
                    className="max-w-[1127px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                    size="txtCardoRegular24Gray80001"
                  >
                    1. One - stop platform: The most complete one-stop office
                    equipment and supplies platform, from Equipment Supply to
                    Customer Problem Solving.
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start m-auto max-w-[1127px] pb-3 relative w-full">
                  <Text
                    className="text-2xl md:text-[22px] text-gray-800_01 sm:text-xl w-auto"
                    size="txtCardoRegular24Gray80001"
                  >
                    2. For Suppliers: MOA will be one of the biggest bridges
                    that connect them to the market.
                  </Text>
                </div>
                <div className="flex flex-col items-center justify-start max-w-[1127px] mt-auto mx-auto pb-3 relative w-full">
                  <Text
                    className="max-w-[1127px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                    size="txtCardoRegular24Gray80001"
                  >
                    3. For Dealers: Create a sales network, through the MOA
                    ready supply platform to achieve a win-win situation.
                  </Text>
                </div>
              </div>
              <div className="flex flex-col items-start justify-start max-w-[1127px] pb-3 w-full">
                <Text
                  className="max-w-[1127px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                  size="txtCardoRegular24Gray80001"
                >
                  4. For Customers: Guarantee the best products, provide the
                  most professional product knowledge, solutions, and support to
                  customers in need.
                </Text>
              </div>
              <div className="border-b-2 border-gray-800 border-solid flex md:flex-col flex-row md:gap-5 items-start justify-center pb-[35px] w-full">
                <Text
                  className="max-w-[945px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                  size="txtCardoRegular24Gray80001"
                >
                  5. For MOA: Creating opportunities, attracting more talents
                  with the same ability & values, so that they can find their
                  dreams at Modern Office Automation.
                </Text>
                <Img
                  className="h-[103px] w-[77px]"
                  src="images/img_vuesaxboldquoteup.svg"
                  alt="vuesaxboldquote_Three"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="bg-gray-100 flex flex-col items-center justify-start max-w-[1439px] md:px-10 sm:px-5 px-[100px] py-[60px] w-full">
          <div className="flex flex-col items-start justify-start max-w-[1233px] mx-auto w-full">
            <div className="flex flex-col gap-2 items-start justify-start w-full">
            <Text 
                className="md:text-xl text-gray-830 w-max inset-x-[0]"
                size="txtCardoBold20"
              >
                <>
                Modern Office Automation
                </>
              </Text>
              <Text
                className="md:text-5xl text-7xl text-gray-800"
                size="txtCardoBold72Gray800"
              >
                <>
                  Our Story
                </>
              </Text>
              <div className="relative w-full">
                <div className="absolute flex flex-col justify-start right-[1%] top-[17%] w-[154px]">
                  <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                  <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                  <div className="bg-light_blue-700 h-[15px] mr-[139px] mt-[71px] rounded-[3px] w-[15px]"></div>
                </div>
                <div className="flex flex-col items-center justify-start max-w-[1233px] mx-auto pb-[35px] relative w-full">
                  <Text
                    className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                    size="txtCardoRegular24Gray80001"
                  >
                    {" "}
                    Every customer is our priority. Modern Office Automation
                    (MOA) was established to meet customer demand, in terms of
                    product quality, durability, modern design, user friendly
                    and others. Since then, there have been repeat customers who
                    are satisfied with their purchases.
                  </Text>
                </div>
                <div className="border-b-2 border-gray-800 border-solid flex flex-col items-center justify-start max-w-[1233px] mt-auto mx-auto pb-[35px] relative w-full">
                  <Text
                    className="max-w-[1233px] md:max-w-full text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                    size="txtCardoRegular24Gray80001"
                  >
                    <>
                      {" "}
                      In the view of our front line, we have an expertise sales
                      team on products guidance with their professional skills
                      to meet the various aspects of customer needs. They are
                      also the company&#39;s heart. On the other hand, there are
                      a group of well-trained technician for software support,
                      training, machine repair & QC in order to ensure product
                      quality before the delivery. In terms of price, we have a
                      vast price given in line with the needs of different
                      areas.
                    </>
                  </Text>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer className="bg-white-A700 border-gray-400_01 border-solid border-t flex font-raleway gap-5 items-center justify-center md:px-5 px-[100px] py-10 w-full" />
      </div>
    </>
  );
};

export default AboutusPage;
