import React from "react";

import { Button, Img, Input, Line, List, Text } from "components";
import AddCompanyFooter from "components/AddCompanyFooter";
import AddCompanyProfile from "components/AddCompanyProfile";
import Footer from "components/Footer";
import Header from "components/Header";


const AddcompanyPage = () => {
  const [frame115value, setFrame115value] = React.useState("");
  const [frame456value, setFrame456value] = React.useState("");

  return (
    <>
      <div className="bg-gray-100_01 flex flex-col items-start justify-start mx-auto w-full">
        <div className="flex flex-col font-raleway items-center w-full">
          <Header className="bg-gray-50_01 flex md:flex-col md:gap-5 items-center justify-center md:px-5 shadow-bs5 w-full" />
        </div>
        <Text
          className="md:ml-[0] ml-[100px] mt-[38px] md:text-5xl text-7xl text-gray-800"
          size="txtCardoBold72Gray800"
        >
          <span className="text-gray-800 font-inter text-left text-xl font-medium">
            Modern Office Automation /{" "}
          </span>
          <span className="text-light_blue-700 font-inter text-left text-xl font-medium">
            <>
              My Company
              <br />
            </>
          </span>
          <span className="text-gray-800 font-inter text-left font-bold">
            My{" "}
          </span>
          <span className="text-gray-800 font-inter text-left font-bold">
            Company
          </span>
        </Text>
        <div className="flex flex-col font-raleway gap-6 items-center mt-[22px] w-full">
          <div className="h-[1213px] md:px-5 relative w-full">
            <AddCompanyProfile className="bg-gray-100_01 flex md:flex-col flex-row font-roboto md:gap-10 h-[1152px] md:h-auto items-start justify-between max-w-[1440px] mb-[-415px] mx-auto md:px-10 sm:px-5 px-[100px] py-10 w-full z-[1]" />
            <AddCompanyFooter
              className="bg-white-A700 flex flex-col gap-5 items-end justify-center mt-auto mx-auto outline outline-gray-400_01 md:px-10 sm:px-5 px-[100px] py-10 w-auto md:w-full"
              price={
                <Text className="font-bold font-raleway sm:text-4xl md:text-[38px] text-[40px] text-gray-800">
                  <span className="md:text-[22px] sm:text-xl text-gray-800 font-cardo text-left text-2xl">
                    <>
                      MODERN OFFICE AUTOMATION (PVT) LTD
                      <br />
                    </>
                  </span>
                  <span className="text-gray-800 font-cardo text-left text-base font-normal">
                    ( Member of Modern Group of Companies )
                  </span>
                </Text>
              }
            />
          </div>
          <Footer className="bg-white-A700 border-gray-400_01 border-solid border-t flex gap-5 items-center justify-center md:px-5 px-[100px] py-10 w-full" />
        </div>
      </div>
    </>
  );
};

export default AddcompanyPage;
