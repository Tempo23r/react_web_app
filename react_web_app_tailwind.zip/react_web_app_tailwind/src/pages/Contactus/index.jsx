import React from "react";

import { Button, Img, Input, Text } from "components";
import Footer from "components/Footer";
import Header1 from "components/Header1";


const ContactusPage = () => {
  const [frame115value, setFrame115value] = React.useState("");

  return (
    <>
      <div className="bg-white-A700 flex flex-col font-cardo items-center justify-start mx-auto w-full">
        <div
          className="bg-cover bg-no-repeat flex flex-col h-[800px] items-center justify-start pb-[181px] w-full"
          style={{ backgroundImage: "url('images/img_frame188.png')" }}
        >
          <Header1 className="flex flex-col font-cardo items-center justify-center md:px-5 w-full" />
          <div className="flex flex-col font-cardo items-center justify-center mt-[177px] md:px-5 w-auto sm:w-full">
            <Text
              className="md:text-5xl text-7xl text-center text-white-A700 tracking-[2.16px] uppercase w-auto"
              size="txtCardoBold72"
            >
              contact us
            </Text>
          </div>
          <div className="flex flex-col font-raleway gap-3.5 items-center justify-start md:px-5 px-[63px]">
            <a
              href="www.modernoffice.online"
              className="text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl"
              target="_blank"
              rel="noreferrer"
            >
              <Text size="txtRalewayRomanBold24">www.modernoffice.online</Text>
            </a>
            <Text
              className="capitalize text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl"
              size="txtRalewayRomanMedium24"
            >
              Largest and Best online office automation store in sri lanka
            </Text>
          </div>
          <Button
            className="cursor-pointer flex items-center justify-center min-w-[214px] mt-[51px] rounded-[21px]"
            leftIcon={
              <Img
                className="h-6 mt-px mb-1 mr-3"
                src="images/img_thumbsup.svg"
                alt="thumbs_up"
              />
            }
            color="white_A700"
            size="md"
            variant="fill"
          >
            <div className="font-bold font-raleway leading-[normal] md:text-[22px] sm:text-xl text-2xl text-center">
              Shop Now
            </div>
          </Button>
        </div>
        <div className="bg-white-A700 flex md:flex-col flex-row gap-[21px] items-end justify-center max-w-[1440px] md:px-10 sm:px-5 px-[100px] py-10 w-full">
          <div className="flex md:flex-1 flex-col gap-[30px] items-start justify-center w-[611px] md:w-full">
            <Text
              className="capitalize md:text-3xl sm:text-[28px] text-[32px] text-gray-900_03"
              size="txtCardoBold32"
            >
              <span className="text-gray-900_03 font-cardo text-left text-xl font-bold">
                <>
                  Modern Office Automation
                  <br />
                </>
              </span>
              <span className="md:text-5xl text-gray-900_03 font-cardo text-left text-7xl font-bold">
                Contact Us
              </span>
            </Text>
            <div className="flex flex-col font-inter gap-[18px] items-start justify-start px-10 sm:px-5 w-[507px] sm:w-full">
              <div className="border-b border-gray-900_04 border-solid flex flex-row gap-5 items-center justify-start py-5 w-[393px] sm:w-full">
                <Img
                  className="h-10 w-10"
                  src="images/img_globe02.svg"
                  alt="globeTwo"
                />
                <a
                  href="www.moderoffice.online"
                  className="text-gray-900_04 text-xl w-auto"
                  target="_blank"
                  rel="noreferrer"
                >
                  <Text size="txtInterSemiBold20">www.moderoffice.online</Text>
                </a>
              </div>
              <div className="h-20 py-5 relative w-[408px] sm:w-full">
              <div className="border-b border-black-900 border-solid flex flex-row gap-5 items-start justify-start py-5 w-[393px] sm:w-full">
                <Img
                  className="h-[38px] w-[38px]"
                  src="images/img_lock.svg"
                  alt="lock"
                />
                <div className="flex flex-col gap-3 items-start justify-center w-auto">
                  <Text
                    className="text-black-900 text-center text-xl w-auto"
                    size="txtInterRegular20"
                  >
                    modernofficeautomation@gmail.com
                  </Text>
                </div>
                </div>
              </div>
              <div className="border-b border-black-900 border-solid flex flex-row gap-5 items-start justify-start py-5 w-[393px] sm:w-full">
                <Img
                  className="h-[38px] w-[38px]"
                  src="images/img_call.svg"
                  alt="call"
                />
                <div className="flex flex-col gap-3 items-start justify-center w-auto">
                  <Text
                    className="text-black-900 text-center text-xl w-auto"
                    size="txtInterRegular20"
                  >
                    Tel - 011-701 2343
                  </Text>
                  <Text
                    className="text-black-900 text-center text-xl w-auto"
                    size="txtInterRegular20"
                  >
                    Hot Line - +94 77 143 2007
                  </Text>
                  <Text
                    className="text-black-900 text-center text-xl w-auto"
                    size="txtInterRegular20"
                  >
                    Hot Line - +94 77 298 5099
                  </Text>
                </div>
              </div>
              <div className="border-b border-gray-900_04 border-solid flex sm:flex-col flex-row gap-5 items-start justify-start px-2 py-5 w-[393px] sm:w-full">
                <Img
                  className="h-8 w-[26px]"
                  src="images/img_linkedin.svg"
                  alt="linkedin"
                />
                <Text
                  className="flex-1 text-black-900 text-xl"
                  size="txtInterRegular20"
                >
                  <>
                    No. 501A, Level #1,
                    <br />
                    Thimbirigasyaya Road,
                    <br />
                    Colombo - 05,
                    <br />
                    Sri Lanka.
                  </>
                </Text>
              </div>
            </div>
          </div>
          <div className="bg-white-A700 flex md:flex-1 flex-col gap-6 h-[534px] md:h-auto items-start justify-between p-5 md:px-5 rounded-lg shadow-bs3 w-[608px] md:w-full">
            <div className="flex flex-col font-inter gap-0.5 items-start justify-center w-full">
              <Text
                className="text-base text-gray-900_04 w-full"
                size="txtInterMedium16"
              >
                Name
              </Text>
              <Input
                name="rectangleNinetyTwo"
                placeholder=""
                className="p-0 w-full"
                wrapClassName="border-b border-gray-900_04 border-solid flex h-11 w-full"
                shape="square"
                color="white_A700"
                variant="fill"
              ></Input>
            </div>
            <div className="flex flex-col font-inter gap-0.5 items-start justify-center w-full">
              <Text
                className="text-base text-gray-900_04 w-full"
                size="txtInterMedium16"
              >
                Email
              </Text>
              <Input
                name="rectangleNinetyTwo_One"
                placeholder=""
                className="p-0 w-full"
                wrapClassName="border-b border-gray-900_04 border-solid flex h-11 w-full"
                shape="square"
                color="white_A700"
                variant="fill"
              ></Input>
            </div>
            <div className="flex flex-col font-inter gap-0.5 items-start justify-center w-full">
              <Text
                className="text-base text-gray-900_04 w-full"
                size="txtInterMedium16"
              >
                Mobile
              </Text>
              <Input
                name="rectangleNinetyTwo_Two"
                placeholder=""
                className="p-0 w-full"
                wrapClassName="border-b border-gray-900_04 border-solid flex h-11 w-full"
                shape="square"
                color="white_A700"
                variant="fill"
              ></Input>
            </div>
            <div className="flex flex-col font-inter gap-0.5 items-start justify-center w-full">
              <Text
                className="text-base text-gray-900_04 w-full"
                size="txtInterMedium16"
              >
                Your Message
              </Text>
              <Input
                name="rectangleNinetyTwo_Three"
                placeholder=""
                className="p-0 w-full"
                wrapClassName="border-b border-gray-900_04 border-solid flex h-[35px] w-full"
                shape="square"
                color="white_A700"
                variant="fill"
              ></Input>
            </div>
            <Button
              className="cursor-pointer font-medium font-montserrat leading-[normal] rounded-[24px] text-center text-xl w-[271px]"
              color="light_blue_700"
              size="md"
              variant="fill"
            >
              Send Message
            </Button>
          </div>
        </div>
        <Footer className="bg-white-A700 border-gray-400_01 border-solid border-t flex font-raleway gap-5 items-center justify-center mt-[45px] md:px-5 px-[100px] py-10 w-full" />
      </div>
    </>
  );
};

export default ContactusPage;
