import React from "react";

import { Button, Img, Input, Line, List, Text } from "components";
import Header from "components/Header";
import MyOrdersProfile from "components/MyOrdersProfile";
import Footer from "components/Footer";



const MyordersPage = () => {
  const [frame115value, setFrame115value] = React.useState("");

  return (
    <>
      <div className="bg-gray-100_01 flex flex-col font-raleway items-center justify-start mx-auto pb-[494px] w-full">
        <div className="flex flex-col items-start justify-start w-full">
          <Header className="bg-gray-50_01 flex md:flex-col md:gap-5 items-center justify-center md:px-5 shadow-bs5 w-full" />
          <div className="flex sm:flex-col flex-row font-cardo sm:gap-10 items-start justify-between max-w-[953px] mt-14 mx-auto md:px-5 w-full">
            <Text
              className="mb-[18px] md:text-5xl text-7xl text-gray-800"
              size="txtCardoBold72Gray800"
            >
              <span className="text-gray-800 font-inter text-left text-xl font-medium">
                Modern Office Automation /{" "}
              </span>
              <span className="text-light_blue-700 font-inter text-left text-xl font-medium">
                <>
                  My Orders
                  <br />
                </>
              </span>
              <span className="text-gray-800 font-inter text-left font-bold">
                My{" "}
              </span>
              <span className="text-gray-800 font-inter text-left font-bold">
                Orders
              </span>
            </Text>
            
          </div>
          <MyOrdersProfile
            className="bg-gray-100_01 flex md:flex-col flex-row font-roboto md:gap-10 h-[805px] md:h-auto items-start justify-between max-w-[1440px] mt-[11px] md:px-10 sm:px-5 px-[100px] py-10 w-full"
            textorderid01235props={
              <Text className="text-base text-black-900 text-center w-auto">
                <span className="text-gray-800 font-roboto font-normal">
                  Order Id{" "}
                </span>
                <span className="text-black-900 font-roboto font-normal">
                  - #
                </span>
                <span className="text-gray-900_02 font-roboto font-medium">
                  01235
                </span>
              </Text>
            }
            textestimateddeliveryshippedprops={
              <Text className="text-base text-black-900 text-center w-auto">
                <span className="text-gray-800 font-roboto uppercase font-normal">
                  e
                </span>
                <span className="text-gray-800 font-roboto font-normal">
                  stimated D
                </span>
                <span className="text-gray-800 font-roboto lowercase font-normal">
                  ELIVERY
                </span>
                <span className="text-gray-800 font-roboto font-normal"> </span>
                <span className="text-black-900 font-roboto font-normal">
                  - Shipped
                </span>
              </Text>
            }
            textorderid01235oneprops={
              <Text className="text-base text-black-900 text-center w-auto">
                <span className="text-gray-800 font-roboto font-normal">
                  Order Id{" "}
                </span>
                <span className="text-black-900 font-roboto font-normal">
                  - #
                </span>
                <span className="text-gray-900_02 font-roboto font-medium">
                  01235
                </span>
              </Text>
            }
            textstatusdeliveredprops={
              <Text className="text-base text-black-900 text-center w-auto">
                <span className="text-gray-800 font-roboto font-normal">
                  Status{" "}
                </span>
                <span className="text-black-900 font-roboto font-normal">
                  -{" "}
                </span>
                <span className="text-light_blue-700 font-roboto font-medium">
                  Delivered
                </span>
                <span className="text-light_blue-700 font-roboto font-normal">
                  {" "}
                </span>
                <span className="text-gray-800 font-roboto font-normal">
                  ( 25th Dec 2023 )
                </span>
              </Text>
            }
          />
        </div>
      </div>
      <Footer className="bg-white-A700 flex font-raleway gap-5 items-center justify-center outline outline-gray-400_01 md:px-5 px-[100px] py-10 w-full" />

    </>
  );
};

export default MyordersPage;
