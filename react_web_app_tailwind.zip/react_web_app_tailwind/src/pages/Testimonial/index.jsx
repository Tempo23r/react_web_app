import React from "react";

import { Button, Img, Input, List, Text } from "components";
import Footer from "components/Footer";
import Header from "components/Header";

const TestimonialPage = () => {
  return (
    <>
      <div className="bg-white-A700 flex flex-col font-raleway items-center justify-start mx-auto w-full">
      <Header className="bg-gray-50_01 flex md:flex-col md:gap-5 items-center justify-center pb-1 md:px-5 w-full" />


        <div className="bg-gray-50_01 flex flex-col gap-10 items-center justify-start md:px-10 sm:px-5 px-[100px] py-10 w-auto md:w-full">
          <div className="flex flex-col items-center justify-start md:px-10 sm:px-5 px-[100px] w-auto md:w-full">
            <div className="flex flex-col items-center justify-start w-auto sm:w-full">
              <div className="h-[114px] md:h-[98px] relative w-[422px] sm:w-full">
                <Text
                  className="absolute inset-x-[0] mx-auto text-center text-gray-800 text-xl top-[0] w-max"
                  size="txtCardoBold20"
                >
                  Modern Office Automation
                </Text>
                <Text
                  className="absolute bottom-[0] inset-x-[0] mx-auto md:text-5xl text-7xl text-center text-gray-800 w-max"
                  size="txtCardoBold72Gray800"
                >
                  Our Partners
                </Text>
              </div>
            </div>
          </div>
          <List
            className="flex flex-col font-raleway gap-10 items-center max-w-[1240px] mx-auto w-full"
            orientation="vertical"
          >
            <div className="bg-white-A700 flex flex-1 flex-col gap-10 items-center justify-start max-w-[1240px] p-10 sm:px-5 rounded-[20px] shadow-bs2 w-full">
              <div className="flex flex-col gap-5 items-start justify-start w-full">
                <Img
                  className="h-[60px] md:h-auto object-cover rounded-[12px] w-[203px] sm:w-full"
                  src="images/img_rectangle109.png"
                  alt="rectangle109"
                />
                <div className="flex flex-col items-start justify-start w-full">
                  <Text
                    className="md:text-3xl sm:text-[28px] text-[32px] text-gray-800 w-auto"
                    size="txtRalewayRomanBold32"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                </div>
              </div>
              <div className="flex flex-col gap-5 items-center justify-center w-full">
                <Img
                  className="h-[460px] md:h-auto object-cover rounded-bl-[16px] rounded-br-[16px] w-full"
                  src="images/img_rectangle104.png"
                  alt="rectangle104"
                />
                <div className="gap-5 grid sm:grid-cols-1 md:grid-cols-2 grid-cols-4 items-center justify-start w-full">
                  <Img
                    className="flex-1 h-[150px] md:h-auto object-cover rounded-[12px] w-full"
                    src="images/img_rectangle107.png"
                    alt="rectangle107"
                  />
                  <Img
                    className="flex-1 h-[150px] md:h-auto object-cover rounded-[12px] w-full"
                    src="images/img_rectangle104_150x150.png"
                    alt="rectangle104_One"
                  />
                  <Img
                    className="flex-1 h-[150px] md:h-auto object-cover rounded-[12px] w-full"
                    src="images/img_rectangle105.png"
                    alt="rectangle105"
                  />
                  <Img
                    className="flex-1 h-[150px] md:h-auto object-cover rounded-[12px] w-full"
                    src="images/img_rectangle106.png"
                    alt="rectangle106"
                  />
                </div>
              </div>
              <div className="flex flex-col font-roboto gap-10 items-start justify-start w-full">
                <div className="flex flex-col items-start justify-start w-full">
                  <Text
                    className="max-w-[1160px] md:max-w-full text-gray-900_01 text-xl"
                    size="txtRobotoRomanRegular20"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Duis aute irure dolor in reprehenderit in voluptate velit
                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                    occaecat cupidatat non proident, sunt in culpa qui officia
                    deserunt mollit anim id est laborum.
                  </Text>
                </div>
                <div className="flex flex-row font-cardo gap-2 items-start justify-start w-auto">
                  <Img
                    className="h-[60px] md:h-auto rounded-[50%] w-[60px]"
                    src="images/img_rectangle108.png"
                    alt="rectangle108"
                  />
                  <div className="flex flex-col gap-[-2px] items-start justify-start w-auto">
                    <Text
                      className="text-gray-900 text-xl w-auto"
                      size="txtCardoBold20Gray900"
                    >
                      Ms. Miranda Cohen
                    </Text>
                    <Text
                      className="text-base text-gray-800_01 w-auto"
                      size="txtCardoBold16"
                    >
                      Founder & CEO
                    </Text>
                    <Text
                      className="text-base text-gray-800_01 w-auto"
                      size="txtCardoBold16"
                    >
                      Mary Kay PVT ltd.
                    </Text>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-white-A700 flex flex-1 flex-col gap-10 items-center justify-start max-w-[1240px] p-10 sm:px-5 rounded-[20px] shadow-bs2 w-full">
              <div className="flex flex-col gap-5 items-start justify-start w-full">
                <Img
                  className="h-[60px] md:h-auto object-cover rounded-[12px] w-[203px] sm:w-full"
                  src="images/img_rectangle109.png"
                  alt="rectangle109"
                />
                <div className="flex flex-col items-start justify-start w-full">
                  <Text
                    className="md:text-3xl sm:text-[28px] text-[32px] text-gray-800 w-auto"
                    size="txtRalewayRomanBold32"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                </div>
              </div>
              <div className="flex flex-col gap-5 items-center justify-center w-full">
                <Img
                  className="h-[460px] md:h-auto object-cover rounded-bl-[16px] rounded-br-[16px] w-full"
                  src="images/img_rectangle104.png"
                  alt="rectangle104"
                />
                <div className="gap-5 grid sm:grid-cols-1 md:grid-cols-2 grid-cols-4 items-center justify-start w-full">
                  <Img
                    className="flex-1 h-[150px] md:h-auto object-cover rounded-[12px] w-full"
                    src="images/img_rectangle107.png"
                    alt="rectangle107"
                  />
                  <Img
                    className="flex-1 h-[150px] md:h-auto object-cover rounded-[12px] w-full"
                    src="images/img_rectangle104_150x150.png"
                    alt="rectangle104_One"
                  />
                  <Img
                    className="flex-1 h-[150px] md:h-auto object-cover rounded-[12px] w-full"
                    src="images/img_rectangle105.png"
                    alt="rectangle105"
                  />
                  <Img
                    className="flex-1 h-[150px] md:h-auto object-cover rounded-[12px] w-full"
                    src="images/img_rectangle106.png"
                    alt="rectangle106"
                  />
                </div>
              </div>
              <div className="flex flex-col font-roboto gap-10 items-start justify-start w-full">
                <div className="flex flex-col items-start justify-start w-full">
                  <Text
                    className="max-w-[1160px] md:max-w-full text-gray-900_01 text-xl"
                    size="txtRobotoRomanRegular20"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation
                    ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    Duis aute irure dolor in reprehenderit in voluptate velit
                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
                    occaecat cupidatat non proident, sunt in culpa qui officia
                    deserunt mollit anim id est laborum.
                  </Text>
                </div>
                <div className="flex flex-row font-cardo gap-2 items-start justify-start w-auto">
                  <Img
                    className="h-[60px] md:h-auto rounded-[50%] w-[60px]"
                    src="images/img_rectangle108.png"
                    alt="rectangle108"
                  />
                  <div className="flex flex-col gap-[-2px] items-start justify-start w-auto">
                    <Text
                      className="text-gray-900 text-xl w-auto"
                      size="txtCardoBold20Gray900"
                    >
                      Ms. Miranda Cohen
                    </Text>
                    <Text
                      className="text-base text-gray-800_01 w-auto"
                      size="txtCardoBold16"
                    >
                      Founder & CEO
                    </Text>
                    <Text
                      className="text-base text-gray-800_01 w-auto"
                      size="txtCardoBold16"
                    >
                      Mary Kay PVT ltd.
                    </Text>
                  </div>
                </div>
              </div>
            </div>
          </List>
        </div>
        <Footer className="bg-white-A700 border-gray-400_01 border-solid border-t flex font-raleway gap-5 items-center justify-center md:px-5 px-[100px] py-10 w-full" />
      </div>
    </>
  );
};

export default TestimonialPage;
