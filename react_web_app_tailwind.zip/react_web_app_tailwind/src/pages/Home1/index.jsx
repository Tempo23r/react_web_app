import React from "react";

import { Button, Img, Input, Line, List, Text } from "components";
import Footer from "components/Footer";
import Header1 from "components/Header1";

import { CloseSVG } from "../../assets/images";

const Home1Page = () => {
  const [frame115value, setFrame115value] = React.useState("");

  return (
    <>
      <div className="bg-white-A700 flex flex-col font-cardo items-center justify-start mx-auto w-full">
        <div
          className="bg-cover bg-no-repeat flex flex-col h-[800px] items-center justify-start pb-[181px] w-full"
          style={{ backgroundImage: "url('images/img_frame188.png')" }}
        >
          <Header1 className="flex flex-col font-cardo items-center justify-center md:px-5 w-full" />
          <div className="flex flex-col font-cardo items-center justify-center max-w-[1283px] mt-[187px] mx-auto md:px-5 w-full">
            <Text
              className="md:text-5xl text-7xl text-center text-white-A700 tracking-[2.16px] uppercase w-auto"
              size="txtCardoBold70"
            >
              Modern Office Automation 
            </Text>
          </div>
          <Text
            className="capitalize mt-[7px] text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl"
            size="txtRalewayRomanBold24"
          >
            Largest and Best online office automation store in sri lanka
          </Text>
          <Button
            className="cursor-pointer flex items-center justify-center min-w-[214px] mt-[77px] rounded-[21px]"
            leftIcon={
              <Img
                className="h-6 mt-px mb-1 mr-3"
                src="images/img_thumbsup.svg"
                alt="thumbs_up"
              />
            }
            color="white_A700"
            size="md"
            variant="fill"
          >
            <div className="font-bold font-raleway leading-[normal] md:text-[22px] sm:text-xl text-2xl text-center">
              Shop Now
            </div>
          </Button>
        </div>


{/* ====================SECTION2================== */}
        <div className="bg-gray-100 flex md:flex-col flex-row md:gap-5 items-start justify-center md:px-10 sm:px-5 px-[100px] py-[60px] w-auto md:w-full">
          <div className="flex flex-col gap-10 items-start justify-start w-auto sm:w-full">
            <div className="flex flex-col gap-2 items-start justify-start w-auto sm:w-full">
              <Text 
                className="md:text-xl text-gray-830 w-max inset-x-[0]"
                size="txtCardoBold20"
              >
                <>
                Modern Office Automation
                </>
              </Text>
              <br></br>
              <Text
                className="md:text-5xl text-7xl text-gray-800"
                size="txtCardoBold72Gray800"
              >
                <>
                  Product<br></br>Categories
                </>
              </Text>
              <div className="border-b-2 border-gray-800 border-solid flex flex-col font-raleway items-start justify-start pb-[35px] w-full">
                <Text
                  className="max-w-[399px] md:max-w-full text-gray-800_01 text-xl"
                  size="txtRalewayRomanMedium20"
                >
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </Text>
              </div>
            </div>
            <div className="flex sm:flex-col flex-row font-raleway sm:gap-10 items-start justify-between w-[555px] sm:w-full">
              <Button
                className="cursor-pointer flex items-center justify-center min-w-[294px] rounded-[24px]"
                rightIcon={
                  <Img
                    className="h-6 mt-px mb-1 ml-2.5"
                    src="images/img_cart_light_blue_700_01.svg"
                    alt="cart"
                  />
                }
                color="light_blue_700"
                size="sm"
                variant="outline"
              >
                <div className="font-semibold leading-[normal] md:text-[22px] sm:text-xl text-2xl text-left">
                  View All Categories
                </div>
              </Button>
              <Img
                className="h-[155px] w-[154px]"
                src="images/img_frame195.svg"
                alt="frame195"
              />
            </div>
          </div>
          <div className="bg-gradient  flex flex-col items-start justify-start pl-10 pt-10 md:px-5 rounded-tl-[40px] w-auto md:w-full">
            <div className="flex flex-col items-center justify-start w-full">
              <div className="flex sm:flex-col flex-row sm:gap-10 items-center justify-between w-full">
                <Img
                  className="h-[300px] md:h-auto object-cover rounded-br-[30px] rounded-tr-[30px]"
                  src="images/img_rectangle82.png"
                  alt="rectangleEightyTwo"
                />
                <Img
                  className="h-[400px] md:h-auto object-cover rounded-[30px]"
                  src="images/img_rectangle80.png"
                  alt="rectangleEighty"
                />
                <Img
                  className="h-[300px] md:h-auto object-cover rounded-bl-[30px] rounded-tl-[30px]"
                  src="images/img_rectangle81.png"
                  alt="rectangleEightyOne"
                />
              </div>
              <Text
                className="mt-1 text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                size="txtCardoBold24"
              >
                Office Chairs
              </Text>
            </div>
          </div>
        </div>
        <div className="bg-gray-50 flex flex-col font-raleway gap-3 items-center justify-start md:px-10 sm:px-5 px-[100px] py-[60px] w-auto md:w-full">
          <div className="flex flex-col gap-3 items-center justify-start max-w-[970px] mx-auto w-full">
            <Button
              className="cursor-pointer font-semibold leading-[normal] min-w-[190px] rounded-[24px] text-2xl md:text-[22px] text-center sm:text-xl"
              color="light_blue_700"
              size="sm"
              variant="outline"
            >
              Our Products
            </Button>
            <div className="font-cardo h-[114px] md:h-[98px] relative w-[970px] md:w-full">
              <Text
                className="absolute inset-x-[0] mx-auto text-center text-gray-800 text-xl top-[0] w-max"
                size="txtCardoBold20"
              >
                Modern Office Automation
              </Text>
              <Text
                className="absolute bottom-[3%] inset-x-[0] mx-auto md:text-5xl text-7xl text-center text-gray-800 w-max"
                size="txtCardoBold72Gray800"
              >
                The Best Product We Provide
              </Text>
            </div>
          </div>
          <div className="flex flex-col gap-3 items-center justify-start max-w-[1240px] mx-auto w-full">
            <div className="gap-5 grid sm:grid-cols-1 md:grid-cols-2 grid-cols-4 justify-center min-h-[auto] w-full">
              <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                <Img
                  className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                  src="images/img_rectangle87.png"
                  alt="rectangleEightySeven"
                />
                <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                  <Text
                    className="text-gray-800_01 text-xl w-full"
                    size="txtRalewayRomanBold20"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                  <div className="flex flex-row font-roboto items-center justify-between w-full">
                    <div className="flex flex-row gap-2 items-center justify-start w-auto">
                      <Text
                        className="line-through text-base text-black-900_99 w-auto"
                        size="txtRobotoRomanSemiBold16"
                      >
                        $653
                      </Text>
                      <Text
                        className="text-gray-800_01 text-xl w-auto"
                        size="txtRobotoRomanSemiBold20"
                      >
                        $623
                      </Text>
                    </div>
                    <Img
                      className="h-6 w-[78px]"
                      src="images/img_user.svg"
                      alt="user"
                    />
                  </div>
                </div>
              </div>
              <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                <Img
                  className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                  src="images/img_rectangle87.png"
                  alt="rectangleEightySeven"
                />
                <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                  <Text
                    className="text-gray-800_01 text-xl w-full"
                    size="txtRalewayRomanBold20"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                  <div className="flex flex-row font-roboto items-center justify-between w-full">
                    <div className="flex flex-row gap-2 items-center justify-start w-auto">
                      <Text
                        className="line-through text-base text-black-900_99 w-auto"
                        size="txtRobotoRomanSemiBold16"
                      >
                        $653
                      </Text>
                      <Text
                        className="text-gray-800_01 text-xl w-auto"
                        size="txtRobotoRomanSemiBold20"
                      >
                        $623
                      </Text>
                    </div>
                    <Img
                      className="h-6 w-[78px]"
                      src="images/img_user.svg"
                      alt="user"
                    />
                  </div>
                </div>
              </div>
              <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                <Img
                  className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                  src="images/img_rectangle87.png"
                  alt="rectangleEightySeven"
                />
                <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                  <Text
                    className="text-gray-800_01 text-xl w-full"
                    size="txtRalewayRomanBold20"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                  <div className="flex flex-row font-roboto items-center justify-between w-full">
                    <div className="flex flex-row gap-2 items-center justify-start w-auto">
                      <Text
                        className="line-through text-base text-black-900_99 w-auto"
                        size="txtRobotoRomanSemiBold16"
                      >
                        $653
                      </Text>
                      <Text
                        className="text-gray-800_01 text-xl w-auto"
                        size="txtRobotoRomanSemiBold20"
                      >
                        $623
                      </Text>
                    </div>
                    <Img
                      className="h-6 w-[78px]"
                      src="images/img_user.svg"
                      alt="user"
                    />
                  </div>
                </div>
              </div>
              <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                <Img
                  className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                  src="images/img_rectangle87.png"
                  alt="rectangleEightySeven"
                />
                <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                  <Text
                    className="text-gray-800_01 text-xl w-full"
                    size="txtRalewayRomanBold20"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                  <div className="flex flex-row font-roboto items-center justify-between w-full">
                    <div className="flex flex-row gap-2 items-center justify-start w-auto">
                      <Text
                        className="line-through text-base text-black-900_99 w-auto"
                        size="txtRobotoRomanSemiBold16"
                      >
                        $653
                      </Text>
                      <Text
                        className="text-gray-800_01 text-xl w-auto"
                        size="txtRobotoRomanSemiBold20"
                      >
                        $623
                      </Text>
                    </div>
                    <Img
                      className="h-6 w-[78px]"
                      src="images/img_user.svg"
                      alt="user"
                    />
                  </div>
                </div>
              </div>
              <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                <Img
                  className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                  src="images/img_rectangle87.png"
                  alt="rectangleEightySeven"
                />
                <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                  <Text
                    className="text-gray-800_01 text-xl w-full"
                    size="txtRalewayRomanBold20"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                  <div className="flex flex-row font-roboto items-center justify-between w-full">
                    <div className="flex flex-row gap-2 items-center justify-start w-auto">
                      <Text
                        className="line-through text-base text-black-900_99 w-auto"
                        size="txtRobotoRomanSemiBold16"
                      >
                        $653
                      </Text>
                      <Text
                        className="text-gray-800_01 text-xl w-auto"
                        size="txtRobotoRomanSemiBold20"
                      >
                        $623
                      </Text>
                    </div>
                    <Img
                      className="h-6 w-[78px]"
                      src="images/img_user.svg"
                      alt="user"
                    />
                  </div>
                </div>
              </div>
              <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                <Img
                  className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                  src="images/img_rectangle87.png"
                  alt="rectangleEightySeven"
                />
                <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                  <Text
                    className="text-gray-800_01 text-xl w-full"
                    size="txtRalewayRomanBold20"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                  <div className="flex flex-row font-roboto items-center justify-between w-full">
                    <div className="flex flex-row gap-2 items-center justify-start w-auto">
                      <Text
                        className="line-through text-base text-black-900_99 w-auto"
                        size="txtRobotoRomanSemiBold16"
                      >
                        $653
                      </Text>
                      <Text
                        className="text-gray-800_01 text-xl w-auto"
                        size="txtRobotoRomanSemiBold20"
                      >
                        $623
                      </Text>
                    </div>
                    <Img
                      className="h-6 w-[78px]"
                      src="images/img_user.svg"
                      alt="user"
                    />
                  </div>
                </div>
              </div>
              <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                <Img
                  className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                  src="images/img_rectangle87.png"
                  alt="rectangleEightySeven"
                />
                <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                  <Text
                    className="text-gray-800_01 text-xl w-full"
                    size="txtRalewayRomanBold20"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                  <div className="flex flex-row font-roboto items-center justify-between w-full">
                    <div className="flex flex-row gap-2 items-center justify-start w-auto">
                      <Text
                        className="line-through text-base text-black-900_99 w-auto"
                        size="txtRobotoRomanSemiBold16"
                      >
                        $653
                      </Text>
                      <Text
                        className="text-gray-800_01 text-xl w-auto"
                        size="txtRobotoRomanSemiBold20"
                      >
                        $623
                      </Text>
                    </div>
                    <Img
                      className="h-6 w-[78px]"
                      src="images/img_user.svg"
                      alt="user"
                    />
                  </div>
                </div>
              </div>
              <div className="flex flex-1 flex-col gap-2 items-start justify-start w-full">
                <Img
                  className="h-[250px] sm:h-auto object-cover rounded-bl-[20px] rounded-br-[20px] w-[295px] md:w-full"
                  src="images/img_rectangle87.png"
                  alt="rectangleEightySeven"
                />
                <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
                  <Text
                    className="text-gray-800_01 text-xl w-full"
                    size="txtRalewayRomanBold20"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                  <div className="flex flex-row font-roboto items-center justify-between w-full">
                    <div className="flex flex-row gap-2 items-center justify-start w-auto">
                      <Text
                        className="line-through text-base text-black-900_99 w-auto"
                        size="txtRobotoRomanSemiBold16"
                      >
                        $653
                      </Text>
                      <Text
                        className="text-gray-800_01 text-xl w-auto"
                        size="txtRobotoRomanSemiBold20"
                      >
                        $623
                      </Text>
                    </div>
                    <Img
                      className="h-6 w-[78px]"
                      src="images/img_user.svg"
                      alt="user"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="flex sm:flex-col flex-row gap-5 items-center justify-center w-auto sm:w-full">
              <Line className="bg-gray-800 h-0.5 w-[24%]" />
              <Button
                className="cursor-pointer font-semibold leading-[normal] min-w-[239px] rounded-[24px] text-2xl md:text-[22px] text-center sm:text-xl"
                color="light_blue_700"
                size="sm"
                variant="outline"
              >
                View All Products
              </Button>
              <Line className="bg-gray-800 h-0.5 w-[24%]" />
            </div>
          </div>
        </div>


{/*====================SECTION3==================*/}
        <div className="bg-gray-100 flex md:flex-col flex-row font-cardo md:gap-[54px] items-center justify-between max-w-[1440px] md:px-10 sm:px-5 px-[100px] py-[60px] w-full">
          <div className="bg-gradient  flex md:flex-1 flex-col items-start justify-start pl-10 pt-10 md:px-5 rounded-tl-[40px] w-auto md:w-full">
            <div className="flex flex-col items-center justify-start w-full">
              <div className="flex sm:flex-col flex-row sm:gap-10 items-center justify-between w-full">
                <Img
                  className="h-[300px] md:h-auto object-cover rounded-br-[30px] rounded-tr-[30px]"
                  src="images/img_rectangle82.png"
                  alt="rectangleEightyTwo_One"
                />
                <Img
                  className="h-[400px] md:h-auto object-cover rounded-[30px]"
                  src="images/img_rectangle80.png"
                  alt="rectangleEighty_One"
                />
                <Img
                  className="h-[300px] md:h-auto object-cover rounded-bl-[30px] rounded-tl-[30px]"
                  src="images/img_rectangle81.png"
                  alt="rectangleEightyOne_One"
                />
              </div>
              <Text
                className="mt-1 text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                size="txtCardoBold24"
              >
                Office Chairs
              </Text>
            </div>
          </div>
          
          <div className="flex sm:flex-1 flex-col gap-10 items-end justify-start w-auto sm:w-full">
            <div className="flex flex-col gap-2 items-end justify-start w-[503px] sm:w-full">
            <Text 
                className="md:text-xl text-gray-830 w-max text self-stretch"
                size="txtCardoBold20"
              >
                <>
                Modern Office Automation
                </>
              </Text>
              <br></br>
              <Text
                className="md:text-5xl text-7xl text-gray-800 self-stretch"
                size="txtCardoBold72Gray800"
              >
                <>
                New <br></br>Arrivals

                </>
              </Text>
              <div className="border-b-2 border-gray-800 border-solid flex flex-col font-raleway items-start justify-start pb-[35px] w-full">
                <Text
                  className="max-w-[503px] md:max-w-full text-gray-800_01 text-xl"
                  size="txtRalewayRomanMedium20"
                >
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </Text>
              </div>
            </div>
            <div className="flex sm:flex-col flex-row font-raleway sm:gap-10 items-start justify-between w-full">
              <Button
                className="cursor-pointer flex items-center justify-center min-w-[277px] rounded-[24px]"
                rightIcon={
                  <Img
                    className="h-6 mt-[3px] mb-px ml-2.5"
                    src="images/img_thumbsup_light_blue_700.svg"
                    alt="thumbs_up"
                  />
                }
                color="light_blue_700"
                size="sm"
                variant="outline"
              >
                <div className="font-semibold leading-[normal] md:text-[22px] sm:text-xl text-2xl text-left">
                  View New Arrivals
                </div>
              </Button>
              <div className="flex sm:flex-1 flex-col justify-start w-[154px] sm:w-full">
                <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                <div className="bg-light_blue-700 h-[15px] mr-[139px] mt-[71px] rounded-[3px] w-[15px]"></div>
              </div>
            </div>
          </div>
        </div>

{/*==============================SECTION4==================================*/}
        <div
          className="bg-gray-900 bg-cover  bg-no-repeat flex flex-col md:gap-10 gap-[87px] h-[682px] items-center justify-end p-[103px] md:px-10 sm:px-5 w-full"
          style={{ backgroundImage: "url('images/img_frame284.png')"  }}
        >
          <div className="flex flex-col font-cardo gap-2.5 h-[252px] md:h-auto items-start justify-start max-w-[1093px] mt-[89px] mx-auto w-full">
            <div className="h-[116px] md:h-[98px] relative w-[1074px] md:w-full">
              <Text
                className="absolute inset-x-[0] mx-auto text-center text-white-A700 text-xl top-[0] w-max"
                size="txtCardoBold20WhiteA700"
              >
                Modern Office Automation
              </Text>
              <Text
                className="absolute bottom-[-1%] inset-x-[0] mx-auto md:text-5xl text-7xl text-center text-white-A700 w-max"
                size="txtCardoBold72"
              >
                Get a Quotation For Your Office
              </Text>
            </div>
            <div className="flex flex-col font-raleway items-center justify-center max-w-[1093px] w-full">
              <Text
                className="max-w-[1093px] md:max-w-full text-center text-white-A700 text-xl"
                size="txtRalewayRomanMedium20WhiteA700"
              >
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris
                nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor
                in reprehenderit in voluptate velit esse cillum dolore eu fugiat
                nulla pariatur. Excepteur sint occaecat cupidatat non proident,
                sunt in culpa qui officia deserunt mollit anim id est laborum.
              </Text>
            </div>
          </div>
          <Button
            className="!text-gray-800 cursor-pointer font-bold font-raleway leading-[normal] min-w-[199px] rounded-[22px] text-center text-xl"
            color="white_A700"
            size="sm"
            variant="fill"
          >
            Get a Quotation
          </Button>
        </div>



{/*==============================SECTION5==================================*/}
        <div className="bg-deep_purple-50 flex flex-col font-cardo gap-5 items-center justify-start max-w-[1440px] md:px-10 sm:px-5 px-[100px] py-[60px] w-full">
          <div className="md:h-[1068px] sm:h-[594px] h-[758px] max-w-[1240px] mx-auto relative w-full">
            <div className="absolute flex flex-col inset-x-[0] items-center justify-start max-w-[1233px] mx-auto top-[0] w-full">
              <div className="flex md:flex-col flex-row gap-2 items-start justify-start w-full">
                <Text
                  className="md:text-5xl text-7xl text-gray-800"
                  size="txtCardoBold72Gray800"
                >
                  <span className="text-gray-800 font-cardo text-left text-xl font-bold">
                    <>
                      Modern Office Automation
                      <br />
                    </>
                  </span>
                  <span className="text-gray-800 font-cardo text-left font-bold">
                    Get{" "}
                  </span>
                  <span className="text-light_blue-700 font-cardo text-left font-bold">
                    50% OFF
                  </span>
                </Text>
                <div className="flex md:flex-1 flex-col justify-start mx-auto w-[154px] md:w-full">
                  <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                  <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                  <div className="bg-light_blue-700 h-[15px] mr-[139px] mt-[71px] rounded-[3px] w-[15px]"></div>
                </div>
              </div>
            </div>
            <div className="absolute bg-gradient1  bottom-[0] flex flex-col inset-x-[0] items-center justify-end max-w-[1240px] mx-auto pl-10 sm:pl-5 pt-10 rounded-tl-[40px] w-full">
              <div className="flex flex-col items-center justify-start pb-3 w-[89%] md:w-full">
                <div className="flex md:flex-col flex-row md:gap-10 items-start justify-between w-full">
                  <div className="flex md:flex-1 flex-col justify-start w-[65%] md:w-full">
                    <div className="flex sm:flex-col flex-row font-roboto sm:gap-10 items-start justify-between w-full">
                      <div className="flex flex-col sm:mt-0 mt-[78px] relative w-[39%] sm:w-full">
                        <div className="font-roboto h-[400px] mx-auto w-full">
                          <Img
                            className="h-[400px] m-auto object-cover rounded-[30px] w-full"
                            src="images/img_rectangle82_400x260.png"
                            alt="rectangleEightyTwo_Two"
                          />
                          <Button
                            className="absolute cursor-pointer font-bold leading-[normal] left-[0] min-w-[88px] text-center text-xs top-[8%]"
                            shape="square"
                            color="light_blue_700_99"
                            size="sm"
                            variant="fill"
                          >
                            50% OFF
                          </Button>
                        </div>
                        <Text
                          className="mt-[-2.82px] mx-auto text-2xl md:text-[22px] text-gray-800_01 sm:text-xl z-[1]"
                          size="txtCardoBold24"
                        >
                          Printers
                        </Text>
                      </div>
                      <div className="h-[500px] md:h-[508px] mb-2 relative w-[44%] sm:w-full">
                        <Img
                          className="h-[500px] m-auto object-cover rounded-[30px] w-full"
                          src="images/img_rectangle80.png"
                          alt="rectangleEighty_Two"
                        />
                        <Button
                          className="absolute cursor-pointer font-bold leading-[normal] left-[0] min-w-[103px] text-base text-center top-[7%]"
                          shape="square"
                          color="light_blue_700"
                          size="sm"
                          variant="fill"
                        >
                          50% OFF
                        </Button>
                      </div>
                    </div>
                    <Text
                      className="md:ml-[0] ml-[459px] text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                      size="txtCardoBold24"
                    >
                      Office Chairs
                    </Text>
                  </div>
                  <div className="flex md:flex-1 flex-col items-center justify-start md:mt-0 mt-[78px] w-1/4 md:w-full">
                    <div className="font-roboto h-[400px] relative w-full">
                      <Img
                        className="h-[400px] m-auto object-cover rounded-[30px] w-full"
                        src="images/img_rectangle81_400x259.png"
                        alt="rectangleEightyOne_Two"
                      />
                      <Button
                        className="absolute cursor-pointer font-bold leading-[normal] left-[0] min-w-[88px] text-center text-xs top-[7%]"
                        shape="square"
                        color="light_blue_700_99"
                        size="sm"
                        variant="fill"
                      >
                        50% OFF
                      </Button>
                    </div>
                    <Text
                      className="mt-0.5 text-2xl md:text-[22px] text-gray-800_01 sm:text-xl"
                      size="txtCardoBold24"
                    >
                      Laptops
                    </Text>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="flex flex-col font-raleway items-start justify-start max-w-[1204px] mx-auto w-full">
            <div className="flex flex-col gap-2 items-start justify-start w-full">
              <Text
                className="text-gray-800_01 text-xl w-full"
                size="txtRalewayRomanMedium20"
              >
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </Text>
              <div className="relative w-full">
                <div className="border-b-2 border-gray-800 border-solid flex flex-col items-start justify-start max-w-[1197px] mx-auto pb-[35px] w-full">
                  <Text
                    className="text-gray-900 text-xl w-auto"
                    size="txtRalewayRomanBold20Gray900"
                  >
                    *Until 31st December 2023
                  </Text>
                </div>
                <div className="absolute bottom-[0] flex flex-col justify-start right-[0] w-[154px]">
                  <div className="bg-light_blue-700 h-5 md:ml-[0] ml-[134px] rounded w-5"></div>
                  <div className="bg-light_blue-700_5e h-10 md:ml-[0] ml-[37px] mr-[77px] mt-[9px] rounded-lg w-10"></div>
                  <div className="bg-light_blue-700 h-[13px] mr-[139px] mt-[71px] rounded-[3px] w-[10%]"></div>
                </div>
                <div className="flex flex-col items-start justify-start mb-[35px] mt-auto relative w-[555px] sm:w-full">
                  <br></br>
                  <Button
                    className="cursor-pointer flex items-center justify-center min-w-[283px] rounded-[24px]"
                    rightIcon={
                      <Img
                        className="h-6 mt-[3px] mb-px ml-2.5"
                        src="images/img_play.svg"
                        alt="play"
                      />
                    }
                    color="light_blue_700"
                    size="sm"
                    variant="outline"
                  >
                    <div className="font-semibold leading-[normal] md:text-[22px] sm:text-xl text-2xl text-left">
                      View All Discounts
                    </div>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <List
          className="bg-gray-50 sm:flex-col flex-row font-raleway md:gap-10 grid sm:grid-cols-1 md:grid-cols-2 grid-cols-4 justify-between max-w-[1440px] md:px-10 sm:px-5 px-[100px] py-10 w-full"
          orientation="horizontal"
        >
          <div className="flex flex-col gap-2 items-start justify-start sm:ml-[0] w-auto">
            <Img
              className="h-[250px] sm:h-auto object-cover rounded-[20px] w-[280px] md:w-full"
              src="images/img_rectangle87.png"
              alt="rectangleEightySeven"
            />
            <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
              <Text
                className="text-gray-800_01 text-xl w-full"
                size="txtRalewayRomanBold20"
              >
                Lorem ipsum dolor sit amet
              </Text>
              <div className="flex flex-row font-roboto items-center justify-between w-full">
                <div className="flex flex-row gap-2 items-center justify-start w-auto">
                  <Text
                    className="line-through text-base text-black-900_99 w-auto"
                    size="txtRobotoRomanSemiBold16"
                  >
                    $653
                  </Text>
                  <Text
                    className="text-gray-800_01 text-xl w-auto"
                    size="txtRobotoRomanSemiBold20"
                  >
                    $623
                  </Text>
                </div>
                <Img
                  className="h-6 w-[78px]"
                  src="images/img_user.svg"
                  alt="user"
                />
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-2 items-start justify-start sm:ml-[0] w-auto">
            <Img
              className="h-[250px] sm:h-auto object-cover rounded-[20px] w-[280px] md:w-full"
              src="images/img_rectangle87.png"
              alt="rectangleEightySeven"
            />
            <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
              <Text
                className="text-gray-800_01 text-xl w-full"
                size="txtRalewayRomanBold20"
              >
                Lorem ipsum dolor sit amet
              </Text>
              <div className="flex flex-row font-roboto items-center justify-between w-full">
                <div className="flex flex-row gap-2 items-center justify-start w-auto">
                  <Text
                    className="line-through text-base text-black-900_99 w-auto"
                    size="txtRobotoRomanSemiBold16"
                  >
                    $653
                  </Text>
                  <Text
                    className="text-gray-800_01 text-xl w-auto"
                    size="txtRobotoRomanSemiBold20"
                  >
                    $623
                  </Text>
                </div>
                <Img
                  className="h-6 w-[78px]"
                  src="images/img_user.svg"
                  alt="user"
                />
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-2 items-start justify-start sm:ml-[0] w-auto">
            <Img
              className="h-[250px] sm:h-auto object-cover rounded-[20px] w-[280px] md:w-full"
              src="images/img_rectangle87.png"
              alt="rectangleEightySeven"
            />
            <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
              <Text
                className="text-gray-800_01 text-xl w-full"
                size="txtRalewayRomanBold20"
              >
                Lorem ipsum dolor sit amet
              </Text>
              <div className="flex flex-row font-roboto items-center justify-between w-full">
                <div className="flex flex-row gap-2 items-center justify-start w-auto">
                  <Text
                    className="line-through text-base text-black-900_99 w-auto"
                    size="txtRobotoRomanSemiBold16"
                  >
                    $653
                  </Text>
                  <Text
                    className="text-gray-800_01 text-xl w-auto"
                    size="txtRobotoRomanSemiBold20"
                  >
                    $623
                  </Text>
                </div>
                <Img
                  className="h-6 w-[78px]"
                  src="images/img_user.svg"
                  alt="user"
                />
              </div>
            </div>
          </div>
          <div className="flex flex-col gap-2 items-start justify-start sm:ml-[0] w-auto">
            <Img
              className="h-[250px] sm:h-auto object-cover rounded-[20px] w-[280px] md:w-full"
              src="images/img_rectangle87.png"
              alt="rectangleEightySeven"
            />
            <div className="flex flex-col gap-2 items-start justify-center pl-1 w-full">
              <Text
                className="text-gray-800_01 text-xl w-full"
                size="txtRalewayRomanBold20"
              >
                Lorem ipsum dolor sit amet
              </Text>
              <div className="flex flex-row font-roboto items-center justify-between w-full">
                <div className="flex flex-row gap-2 items-center justify-start w-auto">
                  <Text
                    className="line-through text-base text-black-900_99 w-auto"
                    size="txtRobotoRomanSemiBold16"
                  >
                    $653
                  </Text>
                  <Text
                    className="text-gray-800_01 text-xl w-auto"
                    size="txtRobotoRomanSemiBold20"
                  >
                    $623
                  </Text>
                </div>
                <Img
                  className="h-6 w-[78px]"
                  src="images/img_user.svg"
                  alt="user"
                />
              </div>
            </div>
          </div>
        </List>
        <div
          className="bg-cover bg-no-repeat flex flex-col h-[560px] items-start justify-start p-[100px] md:px-10 sm:px-5 w-full"
          style={{ backgroundImage: "url('images/img_frame289.png')" }}
        >
          <div className="flex flex-col gap-5 items-start justify-start mb-[113px] mt-[47px] w-auto md:w-full">
            <Text
              className="text-5xl sm:text-[38px] md:text-[44px] text-white-A700 w-auto"
              size="txtCardoBold48"
            >
              Lorem ipsum dolor sit amet
            </Text>
            <Text
              className="max-w-[893px] md:max-w-full text-white-A700 text-xl"
              size="txtRalewayRomanMedium20WhiteA700"
            >
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
              reprehenderit in voluptate velit esse cillum dolore eu fugiat
              nulla pariatur. Excepteur sint occaecat cupidatat non proident,
              sunt in culpa qui officia deserunt mollit anim id est laborum.
            </Text>
          </div>
        </div>
        <div className="bg-white-A700 gap-10 grid sm:grid-cols-1 md:grid-cols-4 grid-cols-8 items-start justify-start max-w-[1440px] md:px-10 px-20 sm:px-5 py-10 w-full">
          <Img
            className="h-[120px] md:h-auto object-cover rounded-[16px] w-[120px]"
            src="images/img_rectangle93.png"
            alt="rectangleNinetyThree"
          />
          <Img
            className="h-[120px] md:h-auto object-cover rounded-[16px] w-[120px]"
            src="images/img_rectangle94.png"
            alt="rectangleNinetyFour"
          />
          <Img
            className="h-[120px] md:h-auto object-cover rounded-[16px] w-[120px]"
            src="images/img_rectangle95.png"
            alt="rectangleNinetyFive"
          />
          <Img
            className="h-[120px] md:h-auto object-cover rounded-[16px] w-[120px]"
            src="images/img_rectangle96.png"
            alt="rectangleNinetySix"
          />
          <Img
            className="h-[120px] md:h-auto object-cover rounded-[16px] w-[120px]"
            src="images/img_rectangle97.png"
            alt="rectangleNinetySeven"
          />
          <Img
            className="h-[120px] md:h-auto object-cover rounded-[16px] w-[120px]"
            src="images/img_rectangle93.png"
            alt="rectangleNinetyEight"
          />
          <Img
            className="h-[120px] md:h-auto object-cover rounded-[16px] w-[120px]"
            src="images/img_rectangle94.png"
            alt="rectangle101"
          />
          <Img
            className="h-[120px] md:h-auto object-cover rounded-[16px] w-[120px]"
            src="images/img_rectangle95.png"
            alt="rectangle102"
          />
        </div>
        <div className="bg-gray-100 flex flex-col font-raleway items-center justify-start md:px-10 sm:px-5 px-[100px] py-10 w-auto md:w-full">
          <div className="flex flex-col items-center justify-start md:px-10 sm:px-5 px-[100px] py-10 w-auto md:w-full">
            <div className="flex flex-col gap-3 items-center justify-start w-auto sm:w-full">
              <Button
                className="cursor-pointer font-semibold leading-[normal] min-w-[190px] rounded-[24px] text-2xl md:text-[22px] text-center sm:text-xl"
                color="light_blue_700"
                size="sm"
                variant="outline"
              >
                Our Products
              </Button>
              <div className="font-cardo h-[114px] md:h-[98px] relative w-[422px] sm:w-full">
                <Text
                  className="absolute inset-x-[0] mx-auto text-center text-gray-800 text-xl top-[0] w-max"
                  size="txtCardoBold20"
                >
                  Modern Office Automation
                </Text>
                <Text
                  className="absolute bottom-[0] inset-x-[0] mx-auto md:text-5xl text-7xl text-center text-gray-800 w-max"
                  size="txtCardoBold72Gray800"
                >
                  Our Partners
                </Text>
              </div>
            </div>
          </div>
          <div className="bg-gray-100 flex md:flex-col flex-row font-cardo gap-10 items-center justify-center max-w-[1240px] mx-auto p-10 md:px-5 rounded-[20px] shadow-bs2 w-full">
            <div className="flex sm:flex-1 flex-col gap-10 items-start justify-start w-auto sm:w-full">
              <Img
                className="h-[60px] md:h-auto object-cover rounded-[19px] w-[190px] sm:w-full"
                src="images/img_rectangle109.png"
                alt="rectangle109"
              />
              <div className="flex flex-col gap-5 items-start justify-start w-auto sm:w-full">
                <Text
                  className="md:text-3xl sm:text-[28px] text-[32px] text-gray-800 w-auto"
                  size="txtRalewayRomanBold32"
                >
                  Lorem ipsum dolor sit amet
                </Text>
                <Text
                  className="max-w-[480px] md:max-w-full text-gray-900_01 text-xl"
                  size="txtRobotoRomanRegular20"
                >
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                  Ut enim ad minim veniam, quis nostrud exercitation ullamco
                  laboris nisi ut aliquip ex ea commodo consequat. Duis aute
                  irure dolor in reprehenderit in voluptate velit esse cillum
                  dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                  cupidatat non proident, sunt in culpa qui officia deserunt
                  mollit anim id est laborum.
                </Text>
              </div>
              <div className="flex flex-row gap-2 items-start justify-start w-auto">
                <Img
                  className="h-[60px] md:h-auto rounded-[50%] w-[60px]"
                  src="images/img_rectangle108.png"
                  alt="rectangle108"
                />
                <div className="flex flex-col gap-[-2px] items-start justify-start w-auto">
                  <Text
                    className="text-gray-900 text-xl w-auto"
                    size="txtCardoBold20Gray900"
                  >
                    Ms. Miranda Cohen
                  </Text>
                  <Text
                    className="text-base text-gray-800_01 w-auto"
                    size="txtCardoBold16"
                  >
                    Founder & CEO
                  </Text>
                  <Text
                    className="text-base text-gray-800_01 w-auto"
                    size="txtCardoBold16"
                  >
                    Mary Kay PVT ltd.
                  </Text>
                </div>
              </div>
              <div className="flex flex-row gap-5 items-center justify-center w-auto">
                <Button
                  className="flex h-[58px] items-center justify-center w-[58px]"
                  shape="circle"
                  color="gray_800"
                  size="md"
                  variant="outline"
                >
                  <Img
                    className="h-[34px]"
                    src="images/img_arrowleft.svg"
                    alt="arrowleft"
                  />
                </Button>
                <Button
                  className="flex h-[58px] items-center justify-center w-[58px]"
                  shape="circle"
                  color="gray_800"
                  size="md"
                  variant="outline"
                >
                  <Img
                    className="h-[34px]"
                    src="images/img_arrowright.svg"
                    alt="arrowright"
                  />
                </Button>
              </div>
            </div>
            <div className="flex md:flex-1 flex-col gap-2.5 items-center justify-center w-auto md:w-full">
              <Img
                className="h-[460px] sm:h-auto object-cover rounded-bl-[16px] rounded-br-[16px] w-[640px] md:w-full"
                src="images/img_rectangle104.png"
                alt="rectangle104"
              />
              <div className="gap-2.5 grid sm:grid-cols-1 md:grid-cols-2 grid-cols-4 items-center justify-between w-full">
                <Img
                  className="h-[150px] md:h-auto object-cover rounded-[12px] w-[150px]"
                  src="images/img_rectangle107.png"
                  alt="rectangle107"
                />
                <Img
                  className="h-[150px] md:h-auto object-cover rounded-[12px] w-[150px]"
                  src="images/img_rectangle104_150x150.png"
                  alt="rectangle104_One"
                />
                <Img
                  className="h-[150px] md:h-auto object-cover rounded-[12px] w-[150px]"
                  src="images/img_rectangle105.png"
                  alt="rectangle105"
                />
                <Img
                  className="h-[150px] md:h-auto object-cover rounded-[12px] w-[150px]"
                  src="images/img_rectangle106.png"
                  alt="rectangle106"
                />
              </div>
            </div>
          </div>
        </div>
        <div className="bg-white-A700 flex flex-col font-cardo gap-10 items-center justify-start max-w-[1440px] md:px-10 sm:px-5 px-[100px] py-20 w-full">
          <div className="h-[104px] md:h-[87px] relative w-[369px]">
            <Text
              className="absolute inset-x-[0] mx-auto text-center text-gray-800 text-xl top-[0] w-max"
              size="txtCardoBold20"
            >
              Modern Office Automation
            </Text>
            <Text
              className="absolute bottom-[0] inset-x-[0] mx-auto md:text-5xl text-[64px] text-center text-gray-800 w-max"
              size="txtCardoBold64"
            >
              Our Services
            </Text>
          </div>
          <div className="flex flex-col items-center justify-start max-w-[1120px] mx-auto pb-[9px] w-full">
            <div className="flex md:flex-col flex-row md:gap-10 gap-[68px] items-center justify-start w-auto md:w-full">
              <List
                className="sm:flex-col flex-row md:gap-10 gap-[68px] grid sm:grid-cols-1 grid-cols-2 w-[47%] md:w-full"
                orientation="horizontal"
              >
                <div className="bg-white-A700 border border-gray-800 border-solid flex flex-col gap-5 items-center justify-start sm:px-5 px-6 py-5 rounded-[20px] w-auto">
                  <div className="flex flex-col gap-1.5 items-center justify-center w-[181px]">
                    <Img
                      className="h-[146px] md:h-auto object-cover w-[156px] sm:w-full"
                      src="images/img_rectangle1249.png"
                      alt="rectangle1249"
                    />
                    <Text
                      className="text-2xl md:text-[22px] text-center text-gray-900_02 sm:text-xl w-auto"
                      size="txtCardoBold24Gray90002"
                    >
                      Site Visiting
                    </Text>
                    <div className="flex flex-col font-roboto items-center justify-start w-full">
                      <Line className="bg-black-900 h-px w-full" />
                      <Text
                        className="mt-[5px] text-blue_gray-400 text-center text-xl w-full"
                        size="txtRobotoRomanRegular20Bluegray400"
                      >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit
                      </Text>
                    </div>
                  </div>
                  <Text
                    className="bg-gray-900_02 border border-solid border-white-A700 justify-center px-4 py-[3px] rounded-[16px] text-center text-lg text-white-A700 w-auto"
                    size="txtCardoBold18"
                  >
                    Explore Now
                  </Text>
                </div>
                <div className="bg-white-A700 border border-gray-800 border-solid flex flex-col gap-5 items-center justify-start sm:px-5 px-6 py-5 rounded-[20px] w-auto">
                  <div className="flex flex-col gap-1.5 items-center justify-center w-[193px]">
                    <Img
                      className="h-[146px] md:h-auto object-cover w-[156px] sm:w-full"
                      src="images/img_rectangle1249_146x156.png"
                      alt="rectangle1249"
                    />
                    <Text
                      className="text-2xl md:text-[22px] text-center text-gray-900_02 sm:text-xl w-auto"
                      size="txtCardoBold24Gray90002"
                    >
                      Product Training
                    </Text>
                    <div className="flex flex-col font-roboto items-center justify-start w-[94%] md:w-full">
                      <Line className="bg-black-900 h-px w-full" />
                      <Text
                        className="mt-[5px] text-blue_gray-400 text-center text-xl w-full"
                        size="txtRobotoRomanRegular20Bluegray400"
                      >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit
                      </Text>
                    </div>
                  </div>
                  <Text
                    className="bg-gray-900_02 border border-solid border-white-A700 justify-center px-4 py-[3px] rounded-[16px] text-center text-lg text-white-A700 w-auto"
                    size="txtCardoBold18"
                  >
                    Explore Now
                  </Text>
                </div>
              </List>
              <List
                className="sm:flex-col flex-row md:gap-10 gap-[68px] grid sm:grid-cols-1 grid-cols-2 w-[47%] md:w-full"
                orientation="horizontal"
              >
                <div className="bg-white-A700 border border-gray-800 border-solid flex flex-col gap-5 items-center justify-start sm:px-5 px-6 py-5 rounded-[20px] w-auto">
                  <div className="flex flex-col gap-1.5 items-center justify-center w-[181px]">
                    <Img
                      className="h-[146px] md:h-auto object-cover w-[156px] sm:w-full"
                      src="images/img_rectangle1249_1.png"
                      alt="rectangle1249"
                    />
                    <div className="flex flex-col gap-[5px] items-center justify-start w-full">
                      <div className="flex flex-col font-cardo items-center justify-start w-full">
                        <Text
                          className="text-2xl md:text-[22px] text-center text-gray-900_02 sm:text-xl w-auto"
                          size="txtCardoBold24Gray90002"
                        >
                          Machine Repair
                        </Text>
                        <Line className="bg-black-900 h-px mt-[3px] w-full" />
                      </div>
                      <Text
                        className="text-blue_gray-400 text-center text-xl w-full"
                        size="txtRobotoRomanRegular20Bluegray400"
                      >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit
                      </Text>
                    </div>
                  </div>
                  <Text
                    className="bg-gray-900_02 border border-solid border-white-A700 justify-center px-4 py-[3px] rounded-[16px] text-center text-lg text-white-A700 w-auto"
                    size="txtCardoBold18"
                  >
                    Explore Now
                  </Text>
                </div>
                <div className="bg-white-A700 border border-gray-800 border-solid flex flex-col gap-5 items-center justify-start sm:px-5 px-6 py-5 rounded-[20px] w-auto">
                  <div className="flex flex-col gap-1.5 items-center justify-center w-[189px]">
                    <Img
                      className="h-[146px] md:h-auto object-cover w-[156px] sm:w-full"
                      src="images/img_rectangle1249_2.png"
                      alt="rectangle1249"
                    />
                    <div className="flex flex-col items-center justify-start w-full">
                      <Text
                        className="text-2xl md:text-[22px] text-center text-gray-900_02 sm:text-xl w-auto"
                        size="txtCardoBold24Gray90002"
                      >
                        Software Support
                      </Text>
                      <Line className="bg-black-900 h-px mt-[3px] w-[96%]" />
                      <Text
                        className="mt-[5px] text-blue_gray-400 text-center text-xl w-[96%] sm:w-full"
                        size="txtRobotoRomanRegular20Bluegray400"
                      >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit
                      </Text>
                    </div>
                  </div>
                  <Text
                    className="bg-gray-900_02 border border-solid border-white-A700 justify-center px-4 py-[3px] rounded-[16px] text-center text-lg text-white-A700 w-auto"
                    size="txtCardoBold18"
                  >
                    Explore Now
                  </Text>
                </div>
              </List>
            </div>
          </div>
        </div>



        <div className=" items-center justify-center max-w-[1240px] mx-auto p-10 md:px-5  w-full">
            <Text
              className="md:text-5xl text-7xl text-gray-800 w-auto"
              size="txtCardoBold70Gray800"
            >
              Why Choose Us ?
            </Text>
            <br></br>
            <Text
              className="max-w-[746px] md:max-w-full text-2xl md:text-[22px] text-gray-900 sm:text-xl"
              size="txtCardoRegular24"
            >
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </Text>
          </div>
        <div className=" flex md:flex-col flex-row font-cardo gap-10 items-center justify-center max-w-[1240px] mx-auto p-10 md:px-5  w-full">
          <div className="flex md:flex-col flex-row gap-5 items-start justify-start max-w-[1240px] mx-auto w-full">
            <div className="flex md:flex-1 flex-col items-start justify-start w-[610px] md:w-full">
              <div className="flex flex-col items-center justify-start w-full">
                <div className="gap-5 grid sm:grid-cols-1 grid-cols-2 justify-center min-h-[auto] w-full">
                  <div className="flex flex-1 flex-col gap-3 items-start justify-start w-full">
                    <Button
                      className="flex h-[60px] items-center justify-center w-[60px]"
                      shape="square"
                      color="blue_gray_100"
                      size="xs"
                      variant="fill"
                    >
                      <Img
                        className="h-12"
                        src="images/img_thumbsup_cyan_800.svg"
                        alt="thumbsup"
                      />
                    </Button>
                    <div className="flex flex-col gap-2 items-start justify-start w-[295px]">
                      <Text
                        className="text-2xl md:text-[22px] text-gray-900 sm:text-xl w-auto"
                        size="txtCardoBold24Gray900"
                      >
                        Easy to Shop
                      </Text>
                      <Text
                        className="max-w-[295px] md:max-w-full text-gray-900 text-xl"
                        size="txtCardoRegular20"
                      >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore
                        magna aliqua.
                      </Text>
                    </div>
                  </div>
                  <div className="flex flex-1 flex-col gap-3 items-start justify-start w-full">
                    <Button
                      className="flex h-[60px] items-center justify-center w-[60px]"
                      shape="square"
                      color="blue_gray_100"
                      size="xs"
                      variant="fill"
                    >
                      <Img
                        className="h-12"
                        src="images/img_clock.svg"
                        alt="clock"
                      />
                    </Button>
                    <div className="flex flex-col gap-2 items-start justify-start w-[295px]">
                      <Text
                        className="text-2xl md:text-[22px] text-gray-900 sm:text-xl w-auto"
                        size="txtCardoBold24Gray900"
                      >
                        24/7 Support
                      </Text>
                      <Text
                        className="max-w-[295px] md:max-w-full text-gray-900 text-xl"
                        size="txtCardoRegular20"
                      >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore
                        magna aliqua.
                      </Text>
                    </div>
                  </div>
                  <div className="flex flex-1 flex-col gap-3 items-start justify-start w-full">
                    <Button
                      className="flex h-[60px] items-center justify-center w-[60px]"
                      shape="square"
                      color="blue_gray_100"
                      size="xs"
                      variant="fill"
                    >
                      <Img
                        className="h-12"
                        src="images/img_airplane.svg"
                        alt="airplane"
                      />
                    </Button>
                    <div className="flex flex-col gap-2 items-start justify-start w-[295px]">
                      <Text
                        className="text-2xl md:text-[22px] text-gray-900 sm:text-xl w-auto"
                        size="txtCardoBold24Gray900"
                      >
                        Fast Delivery
                      </Text>
                      <Text
                        className="max-w-[295px] md:max-w-full text-gray-900 text-xl"
                        size="txtCardoRegular20"
                      >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore
                        magna aliqua.
                      </Text>
                    </div>
                  </div>
                  <div className="flex flex-1 flex-col gap-3 items-start justify-start w-full">
                    <Button
                      className="flex h-[60px] items-center justify-center w-[60px]"
                      shape="square"
                      color="blue_gray_100"
                      size="xs"
                      variant="fill"
                    >
                      <Img
                        className="h-12"
                        src="images/img_truck02.svg"
                        alt="truckTwo"
                      />
                    </Button>
                    <div className="flex flex-col gap-2 items-start justify-start w-[295px]">
                      <Text
                        className="text-2xl md:text-[22px] text-gray-900 sm:text-xl w-auto"
                        size="txtCardoBold24Gray900"
                      >
                        Easy Return
                      </Text>
                      <Text
                        className="max-w-[295px] md:max-w-full text-gray-900 text-xl"
                        size="txtCardoRegular20"
                      >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore
                        magna aliqua.
                      </Text>
                    </div>
                  </div>
                </div>
              </div>
            </div>



            
            <div className="md:h-[408px] h-[480px] relative w-1/2 md:w-full">
              <Img
                className="absolute h-[408px] object-cover right-[0] rounded-[20px] top-[0] w-3/5"
                src="images/img_rectangle76.png"
                alt="rectangleSeventySix"
              />
              <Img
                className="absolute bottom-[0] h-[317px] left-[10%] object-cover rounded-[20px] w-[45%]"
                src="images/img_rectangle77.png"
                alt="rectangleSeventySeven"
              />
              <Img
                className="absolute h-[143px] left-[0] object-cover rounded-[20px] top-[0] w-[38%]"
                src="images/img_rectangle79.png"
                alt="rectangleSeventyNine"
              />
            </div>
          </div>
        </div>
        <Footer className="bg-gray-50_01 border-gray-400_01 border-solid border-t flex font-raleway gap-5 items-center justify-center md:px-5 px-[100px] py-10 w-full" />
      </div>
    </>
  );
};

export default Home1Page;
