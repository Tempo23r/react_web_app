import React from "react";

import { Button, Img, Input, Line, List, Text } from "components";
import Footer from "components/Footer";
import Header1 from "components/Header1";

import { CloseSVG } from "../../assets/images";

const CartPage = () => {
  const [frame115value, setFrame115value] = React.useState("");

  return (
    <>
      <div className="bg-white-A700 flex flex-col font-inter items-start justify-start mx-auto w-full">
        <div className="flex flex-col gap-[11px] items-center w-full">
          <div
            className="bg-cover bg-no-repeat flex flex-col h-[800px] items-center justify-start pb-[181px] w-full"
            style={{ backgroundImage: "url('images/img_frame188.png')" }}
          >
            <Header1 className="flex flex-col font-cardo items-center justify-center md:px-5 w-full" />
            <div className="font-raleway h-[154px] mt-[177px] md:px-5 relative w-[56%] md:w-full">
              <div className="flex flex-col font-cardo items-center justify-center mb-[-16.21px] mx-auto w-auto z-[1]">
                <Text
                  className="md:text-5xl text-7xl text-center text-white-A700 tracking-[2.16px] uppercase w-auto"
                  size="txtCardoBold72"
                >
                  cart
                </Text>
              </div>
              <div className="flex flex-col gap-3.5 items-center justify-start mt-auto mx-auto md:px-10 sm:px-5 px-[63px] w-full">
                <a
                  href="www.modernoffice.online"
                  className="text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl"
                  target="_blank"
                  rel="noreferrer"
                >
                  <Text size="txtRalewayRomanBold24">
                    www.modernoffice.online
                  </Text>
                </a>
                <Text
                  className="capitalize text-2xl md:text-[22px] text-center text-white-A700 sm:text-xl"
                  size="txtRalewayRomanMedium24"
                >
                  Largest and Best online office automation store in sri lanka
                </Text>
              </div>
            </div>
            <Button
              className="cursor-pointer flex items-center justify-center min-w-[214px] mt-[67px] rounded-[21px]"
              leftIcon={
                <Img
                  className="h-6 mt-px mb-1 mr-3"
                  src="images/img_thumbsup.svg"
                  alt="thumbs_up"
                />
              }
              color="white_A700"
              size="md"
              variant="fill"
            >
              <div className="font-bold font-raleway leading-[normal] md:text-[22px] sm:text-xl text-2xl text-center">
                Shop Now
              </div>
            </Button>
          </div>
          <div className="flex flex-col gap-3 items-start justify-center max-w-[1440px] md:px-10 sm:px-5 px-[100px] py-5 w-full">
            <Text
              className="text-2xl md:text-[22px] text-black-900 sm:text-xl w-auto"
              size="txtInterBold24"
            >
              Cart
            </Text>
            <Line className="bg-black-900 h-px max-w-[1240px] mx-auto w-full" />
          </div>
        </div>
        <div className="flex md:flex-col flex-row font-roboto md:gap-10 gap-[90px] items-start justify-center max-w-[1179px] mt-[11px] mx-auto md:px-5 w-full">
          <List
            className="flex flex-col gap-[34px] items-start w-auto"
            orientation="vertical"
          >
            <div className="bg-white-A700 border-b border-black-900_33 border-solid flex md:flex-col flex-row gap-2.5 items-center justify-start max-w-[771px] my-0 pb-[15px] pt-3 px-2 w-full">
              <Img
                className="sm:flex-1 md:h-auto h-full object-cover w-[150px] sm:w-full"
                src="images/img_rectangle1244.png"
                alt="rectangle1244"
              />
              <div className="flex md:flex-1 flex-col gap-[22px] items-start justify-start w-[603px] md:w-full">
                <div className="flex flex-col gap-[15px] items-start justify-start w-full">
                  <Text
                    className="text-center text-gray-800_04 text-xl w-auto"
                    size="txtRobotoRomanMedium20Gray80004"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                  <Text
                    className="text-black-900 text-center text-xl w-auto"
                    size="txtRobotoRomanBold20Black900"
                  >
                    12,500.00 LKR
                  </Text>
                </div>
                <div className="flex flex-row font-inter gap-5 items-center justify-center w-auto">
                  <Text
                    className="text-gray-800 text-xl w-auto"
                    size="txtInterRegular20Gray800"
                  >
                    Quantity :
                  </Text>
                  <div className="flex flex-row font-cardo gap-3 items-center justify-start outline outline-[1px] outline-gray-800_7f w-auto">
                    <Text
                      className="bg-gray-300 justify-center pt-[5px] px-2.5 text-2xl md:text-[22px] text-gray-800 sm:text-xl w-auto"
                      size="txtCardoBold24Gray800"
                    >
                      -
                    </Text>
                    <Text
                      className="text-2xl md:text-[22px] text-gray-800 sm:text-xl w-auto"
                      size="txtCardoBold24Gray800"
                    >
                      2
                    </Text>
                    <Text
                      className="bg-gray-300 justify-center px-2.5 py-[3px] text-2xl md:text-[22px] text-gray-800 sm:text-xl w-auto"
                      size="txtCardoBold24Gray800"
                    >
                      +
                    </Text>
                  </div>
                </div>
                <Text
                  className="text-base text-center text-gray-800_04 w-auto"
                  size="txtRobotoRomanRegular16Gray80004"
                >
                  *Lorem ipsum dolor sit amet
                </Text>
                <div className="flex flex-row font-roboto gap-[22px] items-start justify-start w-auto">
                  <Button
                    className="cursor-pointer font-bold leading-[normal] min-w-[144px] outline-[1px] rounded text-base text-center"
                    color="light_blue_700"
                    size="sm"
                    variant="outline"
                  >
                    Move to Wishlist
                  </Button>
                  <Button
                    className="flex h-[35px] items-center justify-center rounded w-[35px]"
                    color="gray_800"
                    size="sm"
                    variant="outline"
                  >
                    <Img
                      className="h-[19px]"
                      src="images/img_trash01.svg"
                      alt="trashOne"
                    />
                  </Button>
                </div>
              </div>
            </div>
            <div className="bg-white-A700 border-b border-black-900_33 border-solid flex md:flex-col flex-row gap-2.5 items-center justify-start max-w-[771px] my-0 pb-[15px] pt-3 px-2 w-full">
              <Img
                className="sm:flex-1 md:h-auto h-full object-cover w-[150px] sm:w-full"
                src="images/img_rectangle1244.png"
                alt="rectangle1244"
              />
              <div className="flex md:flex-1 flex-col gap-[22px] items-start justify-start w-[603px] md:w-full">
                <div className="flex flex-col gap-[15px] items-start justify-start w-full">
                  <Text
                    className="text-center text-gray-800_04 text-xl w-auto"
                    size="txtRobotoRomanMedium20Gray80004"
                  >
                    Lorem ipsum dolor sit amet
                  </Text>
                  <Text
                    className="text-black-900 text-center text-xl w-auto"
                    size="txtRobotoRomanBold20Black900"
                  >
                    12,500.00 LKR
                  </Text>
                </div>
                <div className="flex flex-row font-inter gap-5 items-center justify-center w-auto">
                  <Text
                    className="text-gray-800 text-xl w-auto"
                    size="txtInterRegular20Gray800"
                  >
                    Quantity :
                  </Text>
                  <div className="flex flex-row font-cardo gap-3 items-center justify-start outline outline-[1px] outline-gray-800_7f w-auto">
                    <Text
                      className="bg-gray-300 justify-center pt-[5px] px-2.5 text-2xl md:text-[22px] text-gray-800 sm:text-xl w-auto"
                      size="txtCardoBold24Gray800"
                    >
                      -
                    </Text>
                    <Text
                      className="text-2xl md:text-[22px] text-gray-800 sm:text-xl w-auto"
                      size="txtCardoBold24Gray800"
                    >
                      2
                    </Text>
                    <Text
                      className="bg-gray-300 justify-center px-2.5 py-[3px] text-2xl md:text-[22px] text-gray-800 sm:text-xl w-auto"
                      size="txtCardoBold24Gray800"
                    >
                      +
                    </Text>
                  </div>
                </div>
                <Text
                  className="text-base text-center text-gray-800_04 w-auto"
                  size="txtRobotoRomanRegular16Gray80004"
                >
                  *Lorem ipsum dolor sit amet
                </Text>
                <div className="flex flex-row font-roboto gap-[22px] items-start justify-start w-auto">
                  <Button
                    className="cursor-pointer font-bold leading-[normal] min-w-[144px] outline-[1px] rounded text-base text-center"
                    color="light_blue_700"
                    size="sm"
                    variant="outline"
                  >
                    Move to Wishlist
                  </Button>
                  <Button
                    className="flex h-[35px] items-center justify-center rounded w-[35px]"
                    color="gray_800"
                    size="sm"
                    variant="outline"
                  >
                    <Img
                      className="h-[19px]"
                      src="images/img_trash01.svg"
                      alt="trashOne"
                    />
                  </Button>
                </div>
              </div>
            </div>
          </List>
          <div className="bg-gray-100_02 flex flex-col gap-5 items-center justify-center p-4 w-auto">
            <div className="bg-light_blue-700 flex flex-col gap-2 items-start justify-center px-4 py-3 w-full">
              <Text
                className="text-base text-center text-white-A700 w-auto"
                size="txtRobotoRomanRegular16WhiteA700"
              >
                Have a coupon?
              </Text>
              <Input
                name="frame529"
                placeholder="Enter Coupon Code"
                className="!placeholder:text-light_blue-700 !text-light_blue-700 leading-[normal] md:h-auto p-0 sm:h-auto text-center text-sm w-full"
                wrapClassName="border border-solid border-white-A700 w-full"
                shape="square"
                color="white_A700"
                size="lg"
                variant="fill"
              ></Input>
              <Button
                className="cursor-pointer font-bold leading-[normal] rounded text-base text-center w-full"
                color="white_A700"
                size="sm"
                variant="outline"
              >
                APPLY
              </Button>
            </div>
            <div className="flex flex-col gap-5 items-start justify-start w-auto">
              <div className="flex flex-col gap-5 items-start justify-start w-full">
                <div className="flex flex-row items-center justify-between w-full">
                  <Text
                    className="text-base text-black-900 w-auto"
                    size="txtRobotoRomanRegular16Black900"
                  >
                    Total Price
                  </Text>
                  <Text
                    className="text-base text-black-900 text-right w-auto"
                    size="txtRobotoRomanMedium16Black900"
                  >
                    123,400.00 LKR
                  </Text>
                </div>
                <div className="flex flex-row items-center justify-between w-full">
                  <Text
                    className="text-base text-black-900 w-auto"
                    size="txtRobotoRomanRegular16Black900"
                  >
                    Discount
                  </Text>
                  <Text
                    className="text-base text-light_blue-700 text-right w-auto"
                    size="txtRobotoRomanMedium16Lightblue700"
                  >
                    20,000.00 LKR
                  </Text>
                </div>
                <div className="flex flex-row items-center justify-between w-full">
                  <Text
                    className="text-base text-black-900 w-auto"
                    size="txtRobotoRomanRegular16Black900"
                  >
                    Coupon
                  </Text>
                  <Text
                    className="text-base text-black-900 text-right w-auto"
                    size="txtRobotoRomanMedium16Black900"
                  >
                    3,400.00 LKR
                  </Text>
                </div>
                <div className="flex flex-row items-center justify-between w-full">
                  <Text
                    className="text-base text-black-900 w-auto"
                    size="txtRobotoRomanRegular16Black900"
                  >
                    Taxes
                  </Text>
                  <Text
                    className="text-base text-black-900 text-right w-auto"
                    size="txtRobotoRomanMedium16Black900"
                  >
                    5,000.00 LKR
                  </Text>
                </div>
              </div>
              <div className="flex flex-col gap-4 items-start justify-start w-auto">
                <div className="border-black-900_33 border-solid border-t flex flex-row gap-[73px] items-start justify-start pt-5 w-auto">
                  <Text
                    className="text-base text-black-900 w-auto"
                    size="txtRobotoRomanMedium16Black900"
                  >
                    Total Amount
                  </Text>
                  <Text
                    className="text-base text-black-900 text-right w-auto"
                    size="txtRobotoRomanBold16"
                  >
                    105,000.00 LKR
                  </Text>
                </div>
                <Button
                  className="border border-solid border-white-A700 cursor-pointer font-bold leading-[normal] rounded text-base text-center w-full"
                  color="light_blue_700"
                  size="md"
                  variant="fill"
                >
                  Place Order
                </Button>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col font-raleway items-center mt-[103px] w-full">
          <Footer className="bg-white-A700 border-gray-400_01 border-solid border-t flex gap-5 items-center justify-center md:px-5 px-[100px] py-10 w-full" />
        </div>
      </div>
    </>
  );
};

export default CartPage;
